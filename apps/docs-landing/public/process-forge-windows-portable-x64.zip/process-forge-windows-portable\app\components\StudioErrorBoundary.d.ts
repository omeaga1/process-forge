import { Component, type ErrorInfo, type ReactNode } from 'react';
interface Props {
    children: ReactNode;
}
interface State {
    hasError: boolean;
    error: Error | null;
}
export declare class StudioErrorBoundary extends Component<Props, State> {
    state: State;
    static getDerivedStateFromError(error: Error): State;
    componentDidCatch(error: Error, errorInfo: ErrorInfo): void;
    private handleReset;
    private handleReturnToLanding;
    render(): ReactNode;
}
export {};
//# sourceMappingURL=StudioErrorBoundary.d.ts.map