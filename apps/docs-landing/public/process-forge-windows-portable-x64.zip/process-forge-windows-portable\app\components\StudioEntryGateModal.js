import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Cloud, HardDrive, ShieldAlert, ArrowRight, UserPlus, X, CheckCircle2 } from 'lucide-react';
import { useTheme } from '@process-forge/canvas-ui';
export const StudioEntryGateModal = ({ isOpen, onClose, onOpenAccountModal, onContinueGuest }) => {
    const { palette } = useTheme();
    const OsakaJadePalette = palette;
    if (!isOpen)
        return null;
    return (_jsx("div", { style: {
            position: 'fixed',
            inset: 0,
            backgroundColor: 'rgba(5, 10, 12, 0.88)',
            backdropFilter: 'blur(10px)',
            zIndex: 10000,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: 20
        }, children: _jsxs("div", { style: {
                width: 640,
                maxWidth: '100%',
                maxHeight: 'min(92vh, 700px)',
                backgroundColor: OsakaJadePalette.background.surface,
                border: `1px solid ${OsakaJadePalette.border.default}`,
                borderRadius: 14,
                boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.85)',
                overflow: 'hidden',
                display: 'flex',
                flexDirection: 'column'
            }, children: [_jsxs("div", { style: {
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        padding: '18px 24px',
                        backgroundColor: OsakaJadePalette.background.canvas,
                        borderBottom: `1px solid ${OsakaJadePalette.border.subtle}`
                    }, children: [_jsxs("div", { children: [_jsx("h3", { style: { margin: 0, fontSize: 18, fontWeight: 800, color: OsakaJadePalette.text.primary, letterSpacing: '-0.02em' }, children: "Welcome to ProcessForge Studio" }), _jsx("span", { style: { fontSize: 13, color: OsakaJadePalette.text.secondary }, children: "Select your session mode before opening your flowsheet canvas" })] }), _jsx("button", { onClick: onClose, style: {
                                background: 'none',
                                border: 'none',
                                color: OsakaJadePalette.text.muted,
                                cursor: 'pointer',
                                padding: 6,
                                borderRadius: 6,
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center'
                            }, title: "Close", children: _jsx(X, { size: 18 }) })] }), _jsxs("div", { style: { padding: '24px', display: 'flex', flexDirection: 'column', gap: 16, overflowY: 'auto' }, children: [_jsxs("div", { style: {
                                padding: '18px 20px',
                                borderRadius: 10,
                                backgroundColor: OsakaJadePalette.background.surfaceElevated,
                                border: `1px solid ${OsakaJadePalette.jade[600]}`,
                                display: 'flex',
                                flexDirection: 'column',
                                gap: 12,
                                boxShadow: `0 0 16px ${OsakaJadePalette.jade.glow}18`,
                                position: 'relative'
                            }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between' }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 10 }, children: [_jsx("div", { style: {
                                                        width: 36,
                                                        height: 36,
                                                        borderRadius: 8,
                                                        backgroundColor: 'rgba(16, 185, 129, 0.15)',
                                                        display: 'flex',
                                                        alignItems: 'center',
                                                        justifyContent: 'center',
                                                        color: OsakaJadePalette.jade[400]
                                                    }, children: _jsx(Cloud, { size: 20 }) }), _jsxs("div", { children: [_jsx("h4", { style: { margin: 0, fontSize: 15, fontWeight: 700, color: OsakaJadePalette.text.primary }, children: "Sign Up or Sign In" }), _jsx("span", { style: { fontSize: 12, color: OsakaJadePalette.text.secondary }, children: "Recommended for engineering teams and persistent projects" })] })] }), _jsx("span", { style: {
                                                fontSize: 11,
                                                fontWeight: 700,
                                                padding: '3px 8px',
                                                borderRadius: 4,
                                                backgroundColor: 'rgba(16, 185, 129, 0.2)',
                                                color: OsakaJadePalette.jade[300],
                                                border: `1px solid ${OsakaJadePalette.jade[500]}66`
                                            }, children: "Cloud Storage Enabled" })] }), _jsxs("div", { style: { display: 'flex', flexDirection: 'column', gap: 6, fontSize: 12, color: OsakaJadePalette.text.secondary }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 8 }, children: [_jsx(CheckCircle2, { size: 13, color: OsakaJadePalette.jade[400] }), _jsx("span", { children: "Automatic cloud backups of flowsheets and dynamic ODE states" })] }), _jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 8 }, children: [_jsx(CheckCircle2, { size: 13, color: OsakaJadePalette.jade[400] }), _jsx("span", { children: "Seamlessly access and resume your digital twin across desktop & web" })] }), _jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 8 }, children: [_jsx(CheckCircle2, { size: 13, color: OsakaJadePalette.jade[400] }), _jsx("span", { children: "Unlimited project revisions and shared community unit operations" })] })] }), _jsxs("button", { onClick: () => {
                                        onClose();
                                        onOpenAccountModal();
                                    }, style: {
                                        marginTop: 4,
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        gap: 8,
                                        padding: '10px 16px',
                                        borderRadius: 6,
                                        backgroundColor: OsakaJadePalette.jade[500],
                                        color: OsakaJadePalette.text.inverse,
                                        border: 'none',
                                        fontSize: 13,
                                        fontWeight: 700,
                                        cursor: 'pointer',
                                        boxShadow: `0 2px 10px ${OsakaJadePalette.jade.glow}44`,
                                        transition: 'all 0.15s ease'
                                    }, children: [_jsx(UserPlus, { size: 15 }), _jsx("span", { children: "Sign In / Create Free Account" }), _jsx(ArrowRight, { size: 14 })] })] }), _jsxs("div", { style: {
                                padding: '18px 20px',
                                borderRadius: 10,
                                backgroundColor: OsakaJadePalette.background.surfaceElevated,
                                border: `1px solid ${OsakaJadePalette.border.default}`,
                                display: 'flex',
                                flexDirection: 'column',
                                gap: 12
                            }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between' }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 10 }, children: [_jsx("div", { style: {
                                                        width: 36,
                                                        height: 36,
                                                        borderRadius: 8,
                                                        backgroundColor: 'rgba(245, 158, 11, 0.12)',
                                                        display: 'flex',
                                                        alignItems: 'center',
                                                        justifyContent: 'center',
                                                        color: OsakaJadePalette.status.blocked
                                                    }, children: _jsx(HardDrive, { size: 20 }) }), _jsxs("div", { children: [_jsx("h4", { style: { margin: 0, fontSize: 15, fontWeight: 700, color: OsakaJadePalette.text.primary }, children: "Continue in Guest Mode" }), _jsx("span", { style: { fontSize: 12, color: OsakaJadePalette.text.secondary }, children: "Quick scratchpad session without creating an account" })] })] }), _jsx("span", { style: {
                                                fontSize: 11,
                                                fontWeight: 700,
                                                padding: '3px 8px',
                                                borderRadius: 4,
                                                backgroundColor: 'rgba(245, 158, 11, 0.15)',
                                                color: OsakaJadePalette.status.blocked,
                                                border: '1px solid rgba(245, 158, 11, 0.3)'
                                            }, children: "Cloud Storage Disabled" })] }), _jsxs("div", { style: { display: 'flex', flexDirection: 'column', gap: 6, fontSize: 12, color: OsakaJadePalette.text.secondary }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 8 }, children: [_jsx(ShieldAlert, { size: 13, color: OsakaJadePalette.status.blocked }), _jsx("span", { children: "Flowsheets are saved only in this browser's temporary local cache" })] }), _jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 8 }, children: [_jsx(ShieldAlert, { size: 13, color: OsakaJadePalette.status.blocked }), _jsx("span", { children: "Clearing browser cookies/history will reset your local data" })] }), _jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 8 }, children: [_jsx(CheckCircle2, { size: 13, color: OsakaJadePalette.text.muted }), _jsxs("span", { children: ["You can export manual ", _jsx("code", { style: { color: OsakaJadePalette.jade[400] }, children: ".processforge" }), " project files to your disk at any time"] })] })] }), _jsxs("button", { onClick: () => {
                                        onClose();
                                        onContinueGuest();
                                    }, style: {
                                        marginTop: 4,
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        gap: 8,
                                        padding: '10px 16px',
                                        borderRadius: 6,
                                        backgroundColor: OsakaJadePalette.background.surface,
                                        color: OsakaJadePalette.text.primary,
                                        border: `1px solid ${OsakaJadePalette.border.strong}`,
                                        fontSize: 13,
                                        fontWeight: 600,
                                        cursor: 'pointer',
                                        transition: 'all 0.15s ease'
                                    }, children: [_jsx("span", { children: "Enter Guest Studio (Blank Canvas)" }), _jsx(ArrowRight, { size: 14, color: OsakaJadePalette.text.muted })] })] })] })] }) }));
};
//# sourceMappingURL=StudioEntryGateModal.js.map