import { type SimulationProject } from '@process-forge/protocol';
export interface ProjectMetadataHeader {
    id: string;
    name: string;
    description: string;
    updatedAt: string;
    isGuestProject: boolean;
    nodeCount: number;
}
/**
 * Saves project to browser localStorage and updates the recent projects index.
 */
export declare function saveLocalProject(project: SimulationProject): void;
/**
 * Loads the current active project from localStorage, or null if none is saved.
 */
export declare function loadCurrentLocalProject(): SimulationProject | null;
/**
 * Lists metadata headers for all locally stored simulations.
 */
export declare function listLocalProjects(): ProjectMetadataHeader[];
/**
 * Triggers a browser download of the entire simulation as a `.pfg.json` bundle.
 */
export declare function downloadProjectFile(project: SimulationProject): void;
/**
 * Reads and validates an uploaded `.pfg.json` file from the user's filesystem.
 */
export declare function readProjectFromFile(file: File): Promise<SimulationProject>;
//# sourceMappingURL=localStorageAdapter.d.ts.map