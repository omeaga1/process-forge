import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useRef } from 'react';
import { Layers, Cpu, ShieldCheck, ChevronDown, Save, FolderOpen, AlertCircle, Sun, Moon, RotateCw, Sparkles, User, LayoutDashboard } from 'lucide-react';
import { useMobileViewport, useTheme, ProcessForgeLogo } from '@process-forge/canvas-ui';
import { useAccount } from '../auth/useAccount.js';
import { isTauriEnvironment } from './UpdateNotificationBanner.js';
export const HeaderBar = ({ currentTemplate, isGuestMode, activeAiProvider: _activeAiProvider = 'mcp', onNavigateHome, onSelectTemplate, onOpenAiModal, onOpenForgeHub, onOpenSaveModal, onOpenGuestModal, onImportFile, onOpenAccountModal, onOpenCloudProjects, onCheckForUpdates, isCheckingUpdates = false, hasUpdateAvailable = false }) => {
    const fileInputRef = useRef(null);
    const { isMobile } = useMobileViewport();
    const { theme, toggleTheme, palette } = useTheme();
    const OsakaJadePalette = palette;
    const { user, isAuthenticated, openAccountModal } = useAccount();
    const handleFileChange = (e) => {
        const file = e.target.files?.[0];
        if (file) {
            onImportFile(file);
            e.target.value = ''; // reset so same file can be reopened
        }
    };
    if (isMobile) {
        return (_jsxs("header", { style: {
                height: 48,
                backgroundColor: OsakaJadePalette.background.surface,
                borderBottom: `1px solid ${OsakaJadePalette.border.default}`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '0 12px',
                zIndex: 100,
                position: 'relative'
            }, children: [_jsx("input", { ref: fileInputRef, type: "file", accept: ".json,.pfg,.pfg.json", style: { display: 'none' }, onChange: handleFileChange }), _jsx("div", { onClick: onNavigateHome, style: { display: 'flex', alignItems: 'center', cursor: onNavigateHome ? 'pointer' : 'default' }, title: onNavigateHome ? 'Return to Studio Dashboard & Projects Hub' : undefined, children: _jsx(ProcessForgeLogo, { size: 24, wordmarkSize: 14 }) }), _jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 6 }, children: [_jsx("button", { onClick: onOpenAccountModal || openAccountModal, style: {
                                display: 'inline-flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                width: 32,
                                height: 32,
                                borderRadius: 6,
                                backgroundColor: isAuthenticated ? 'rgba(16, 185, 129, 0.15)' : 'rgba(255, 255, 255, 0.04)',
                                border: `1px solid ${isAuthenticated ? OsakaJadePalette.jade[600] : OsakaJadePalette.border.default}`,
                                color: isAuthenticated ? OsakaJadePalette.jade.glow : OsakaJadePalette.text.secondary,
                                cursor: 'pointer'
                            }, title: isAuthenticated ? `Account: ${user?.name}` : 'Sign In', children: _jsx(User, { size: 15 }) }), _jsx("button", { onClick: onOpenSaveModal, style: {
                                display: 'inline-flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                width: 32,
                                height: 32,
                                borderRadius: 6,
                                backgroundColor: 'rgba(16, 185, 129, 0.15)',
                                border: `1px solid ${OsakaJadePalette.jade[600]}`,
                                color: OsakaJadePalette.text.accent,
                                cursor: 'pointer'
                            }, title: "Save Simulation to Cloud", children: _jsx(Save, { size: 15 }) }), _jsx("button", { onClick: onOpenAiModal, style: {
                                display: 'inline-flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                width: 32,
                                height: 32,
                                borderRadius: 6,
                                backgroundColor: 'rgba(16, 185, 129, 0.15)',
                                border: `1px solid ${OsakaJadePalette.jade.glow}`,
                                color: OsakaJadePalette.jade.glow,
                                cursor: 'pointer'
                            }, title: "AI & MCP Engineering Tools", children: _jsx(Cpu, { size: 15 }) }), onCheckForUpdates && (_jsx("button", { onClick: onCheckForUpdates, disabled: isCheckingUpdates, style: {
                                display: 'inline-flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                width: 32,
                                height: 32,
                                borderRadius: 6,
                                backgroundColor: hasUpdateAvailable ? 'rgba(16, 185, 129, 0.2)' : 'rgba(255, 255, 255, 0.04)',
                                border: `1px solid ${hasUpdateAvailable ? OsakaJadePalette.jade.glow : OsakaJadePalette.border.default}`,
                                color: hasUpdateAvailable ? OsakaJadePalette.jade.glow : OsakaJadePalette.text.primary,
                                cursor: 'pointer'
                            }, title: hasUpdateAvailable ? 'Update Available — Click to Apply' : 'Check for Updates', children: _jsx(RotateCw, { size: 14, className: isCheckingUpdates ? 'animate-spin' : '' }) })), _jsx("button", { onClick: toggleTheme, style: {
                                display: 'inline-flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                width: 32,
                                height: 32,
                                borderRadius: 6,
                                backgroundColor: 'rgba(255, 255, 255, 0.04)',
                                border: `1px solid ${OsakaJadePalette.border.default}`,
                                color: theme === 'dark' ? OsakaJadePalette.jade.glow : OsakaJadePalette.text.primary,
                                cursor: 'pointer'
                            }, title: theme === 'dark' ? 'Switch to Light Theme' : 'Switch to Dark Theme', children: theme === 'dark' ? _jsx(Sun, { size: 15 }) : _jsx(Moon, { size: 15 }) })] })] }));
    }
    return (_jsxs("header", { style: {
            height: 50,
            backgroundColor: OsakaJadePalette.background.surface,
            borderBottom: `1px solid ${OsakaJadePalette.border.default}`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '0 16px',
            zIndex: 100,
            position: 'relative',
            flexWrap: 'nowrap',
            minWidth: 0,
            gap: 12
        }, children: [_jsx("input", { ref: fileInputRef, type: "file", accept: ".json,.pfg,.pfg.json", style: { display: 'none' }, onChange: handleFileChange }), _jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 8, flexShrink: 1, minWidth: 0 }, children: [_jsx("div", { onClick: onNavigateHome, style: { display: 'flex', alignItems: 'center', cursor: onNavigateHome ? 'pointer' : 'default', flexShrink: 0 }, title: onNavigateHome ? 'Return to Studio Dashboard & Projects Hub' : undefined, children: _jsx(ProcessForgeLogo, { size: 26, wordmarkSize: 14 }) }), onNavigateHome && (_jsxs("button", { onClick: onNavigateHome, style: {
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: 5,
                            height: 32,
                            padding: '0 9px',
                            borderRadius: 6,
                            backgroundColor: 'rgba(255, 255, 255, 0.04)',
                            border: `1px solid ${OsakaJadePalette.border.default}`,
                            color: OsakaJadePalette.text.secondary,
                            fontSize: 12,
                            fontWeight: 600,
                            cursor: 'pointer',
                            whiteSpace: 'nowrap',
                            boxSizing: 'border-box',
                            flexShrink: 0
                        }, title: "Studio Hub, Cloud Projects & Templates", children: [_jsx(LayoutDashboard, { size: 13, color: OsakaJadePalette.jade[400] }), _jsx("span", { children: "Studio Hub" })] })), _jsx("div", { style: { width: 1, height: 16, backgroundColor: OsakaJadePalette.border.subtle, margin: '0 2px', flexShrink: 0 } }), _jsxs("div", { style: { position: 'relative', width: 220, minWidth: 150, flexShrink: 1 }, children: [_jsxs("select", { value: currentTemplate, onChange: (e) => onSelectTemplate(e.target.value), style: {
                                    appearance: 'none',
                                    width: '100%',
                                    height: 32,
                                    boxSizing: 'border-box',
                                    backgroundColor: OsakaJadePalette.background.canvas,
                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                    borderRadius: 6,
                                    padding: '0 26px 0 10px',
                                    color: OsakaJadePalette.text.primary,
                                    fontSize: 12,
                                    fontWeight: 500,
                                    cursor: 'pointer',
                                    outline: 'none',
                                    textOverflow: 'ellipsis',
                                    overflow: 'hidden',
                                    whiteSpace: 'nowrap'
                                }, title: "Switch Process Flowsheet Template", children: [_jsx("option", { value: "blank", children: "Custom Blank Canvas" }), _jsx("option", { value: "sherwin-williams-paint-line", children: "Sherwin-Williams Paint Canning Line" }), _jsx("option", { value: "beverage-bottling-line", children: "High-Speed Beverage Bottling Line" })] }), _jsx(ChevronDown, { size: 13, color: OsakaJadePalette.text.secondary, style: { position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none' } })] }), _jsx("div", { style: { width: 1, height: 16, backgroundColor: OsakaJadePalette.border.subtle, margin: '0 2px', flexShrink: 0 } }), _jsxs("div", { style: {
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: 6,
                            height: 32,
                            padding: '0 8px',
                            borderRadius: 6,
                            backgroundColor: 'rgba(16, 185, 129, 0.08)',
                            border: '1px solid rgba(16, 185, 129, 0.25)',
                            fontSize: 11,
                            color: OsakaJadePalette.text.accent,
                            fontWeight: 600,
                            whiteSpace: 'nowrap',
                            boxSizing: 'border-box',
                            flexShrink: 0
                        }, title: "Deterministic Simulation Core: Active & Synchronized", children: [_jsx("span", { style: {
                                    width: 6,
                                    height: 6,
                                    borderRadius: '50%',
                                    backgroundColor: OsakaJadePalette.jade[400],
                                    boxShadow: `0 0 6px ${OsakaJadePalette.jade[400]}`,
                                    flexShrink: 0
                                } }), _jsx("span", { children: "Core Active" })] }), isGuestMode && (_jsxs("button", { onClick: onOpenGuestModal, style: {
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: 5,
                            height: 32,
                            padding: '0 8px',
                            borderRadius: 6,
                            backgroundColor: 'rgba(245, 158, 11, 0.10)',
                            border: '1px solid rgba(245, 158, 11, 0.35)',
                            fontSize: 11,
                            color: OsakaJadePalette.border.glowAmber,
                            fontWeight: 600,
                            cursor: 'pointer',
                            whiteSpace: 'nowrap',
                            boxSizing: 'border-box',
                            flexShrink: 0
                        }, title: "Guest Mode: Storage is local to this browser session. Click to view backup options.", children: [_jsx(AlertCircle, { size: 12 }), _jsx("span", { children: "Guest" })] }))] }), _jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 6, flexShrink: 0 }, children: [_jsxs("button", { onClick: onOpenCloudProjects || (() => fileInputRef.current?.click()), style: {
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: 5,
                            height: 32,
                            backgroundColor: 'transparent',
                            border: `1px solid ${OsakaJadePalette.border.default}`,
                            borderRadius: 6,
                            padding: '0 10px',
                            color: OsakaJadePalette.text.secondary,
                            fontSize: 12,
                            fontWeight: 500,
                            cursor: 'pointer',
                            whiteSpace: 'nowrap',
                            boxSizing: 'border-box'
                        }, title: "Open or browse Cloud Simulation Projects", children: [_jsx(FolderOpen, { size: 14 }), _jsx("span", { children: "Projects" })] }), _jsxs("button", { onClick: onOpenSaveModal, style: {
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: 5,
                            height: 32,
                            backgroundColor: 'rgba(16, 185, 129, 0.15)',
                            border: `1px solid ${OsakaJadePalette.jade[600]}`,
                            borderRadius: 6,
                            padding: '0 12px',
                            color: OsakaJadePalette.text.accent,
                            fontSize: 12,
                            fontWeight: 600,
                            cursor: 'pointer',
                            whiteSpace: 'nowrap',
                            boxSizing: 'border-box'
                        }, title: "Save simulation to Cloud Storage", children: [_jsx(Save, { size: 14 }), _jsx("span", { children: "Save" })] }), _jsx("div", { style: { width: 1, height: 16, backgroundColor: OsakaJadePalette.border.subtle, margin: '0 2px' } }), _jsxs("button", { onClick: onOpenAiModal, style: {
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: 5,
                            height: 32,
                            backgroundColor: 'rgba(16, 185, 129, 0.10)',
                            border: `1px solid ${OsakaJadePalette.jade[600]}`,
                            borderRadius: 6,
                            padding: '0 10px',
                            color: OsakaJadePalette.text.accent,
                            fontSize: 12,
                            fontWeight: 600,
                            cursor: 'pointer',
                            whiteSpace: 'nowrap',
                            boxSizing: 'border-box'
                        }, title: "AI & MCP Engineering Tools (Claude, Gemini, Cursor)", children: [_jsx(Cpu, { size: 14, color: OsakaJadePalette.jade.glow }), _jsx("span", { children: "AI Tools" })] }), _jsxs("button", { onClick: onOpenForgeHub, style: {
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: 5,
                            height: 32,
                            backgroundColor: 'rgba(255, 255, 255, 0.04)',
                            border: `1px solid ${OsakaJadePalette.border.default}`,
                            borderRadius: 6,
                            padding: '0 10px',
                            color: OsakaJadePalette.text.secondary,
                            fontSize: 12,
                            fontWeight: 500,
                            cursor: 'pointer',
                            whiteSpace: 'nowrap',
                            boxSizing: 'border-box'
                        }, title: "Community UnitOp Library \u2014 Browse & publish unit-op plugins", children: [_jsx(Layers, { size: 14 }), _jsx("span", { children: "UnitOps" })] }), _jsx("div", { style: { width: 1, height: 16, backgroundColor: OsakaJadePalette.border.subtle, margin: '0 2px' } }), _jsxs("button", { onClick: onOpenAccountModal || openAccountModal, style: {
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: 6,
                            height: 32,
                            backgroundColor: isAuthenticated ? 'rgba(16, 185, 129, 0.10)' : 'rgba(255, 255, 255, 0.04)',
                            border: `1px solid ${isAuthenticated ? OsakaJadePalette.jade[600] : OsakaJadePalette.border.default}`,
                            borderRadius: 6,
                            padding: '0 10px',
                            color: isAuthenticated ? OsakaJadePalette.text.primary : OsakaJadePalette.text.secondary,
                            fontSize: 12,
                            fontWeight: 600,
                            cursor: 'pointer',
                            whiteSpace: 'nowrap',
                            boxSizing: 'border-box'
                        }, title: isAuthenticated && user ? `Account: ${user.name} (${user.email}) • Cloud Storage Connected` : 'Sign In to enable Cloud Storage', children: [user?.avatarUrl ? (_jsx("img", { src: user.avatarUrl, alt: user.name, style: { width: 16, height: 16, borderRadius: '50%', objectFit: 'cover' } })) : (_jsx(User, { size: 13, color: isAuthenticated ? OsakaJadePalette.jade[400] : OsakaJadePalette.text.muted })), _jsx("span", { children: isAuthenticated && user ? user.name.split(' ')[0] : 'Sign In' }), isAuthenticated && (_jsx("span", { style: {
                                    width: 6,
                                    height: 6,
                                    borderRadius: '50%',
                                    backgroundColor: OsakaJadePalette.jade[400],
                                    boxShadow: `0 0 6px ${OsakaJadePalette.jade.glow}`
                                }, title: "Cloud Sync Active" }))] }), _jsx("div", { style: {
                            display: 'inline-flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            width: 32,
                            height: 32,
                            borderRadius: 6,
                            backgroundColor: 'rgba(255, 255, 255, 0.03)',
                            border: `1px solid ${OsakaJadePalette.border.subtle}`,
                            color: OsakaJadePalette.jade[500],
                            boxSizing: 'border-box',
                            cursor: 'help'
                        }, title: "Zero Raw Keys: 100% Local Math & DPAPI Vault Protection", children: _jsx(ShieldCheck, { size: 16 }) }), isTauriEnvironment() && onCheckForUpdates && (_jsxs("button", { onClick: onCheckForUpdates, disabled: isCheckingUpdates, style: {
                            display: 'inline-flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            gap: 5,
                            height: 32,
                            padding: hasUpdateAvailable ? '0 10px' : '0',
                            width: hasUpdateAvailable ? 'auto' : 32,
                            backgroundColor: hasUpdateAvailable ? 'rgba(16, 185, 129, 0.15)' : 'rgba(255, 255, 255, 0.04)',
                            border: `1px solid ${hasUpdateAvailable ? OsakaJadePalette.jade.glow : OsakaJadePalette.border.default}`,
                            borderRadius: 6,
                            color: hasUpdateAvailable ? OsakaJadePalette.jade.glow : OsakaJadePalette.text.secondary,
                            fontSize: 12,
                            fontWeight: hasUpdateAvailable ? 600 : 500,
                            cursor: isCheckingUpdates ? 'wait' : 'pointer',
                            whiteSpace: 'nowrap',
                            boxSizing: 'border-box',
                            boxShadow: hasUpdateAvailable ? `0 0 10px ${OsakaJadePalette.jade.glow}33` : 'none'
                        }, title: hasUpdateAvailable ? 'Update Available — Click to Apply' : 'Check for Updates', children: [hasUpdateAvailable ? (_jsx(Sparkles, { size: 14, color: OsakaJadePalette.jade.glow })) : (_jsx(RotateCw, { size: 14, className: isCheckingUpdates ? 'animate-spin' : '' })), hasUpdateAvailable && _jsx("span", { children: "Update Ready" })] })), _jsx("button", { onClick: toggleTheme, style: {
                            display: 'inline-flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            width: 32,
                            height: 32,
                            backgroundColor: 'rgba(255, 255, 255, 0.04)',
                            border: `1px solid ${OsakaJadePalette.border.default}`,
                            borderRadius: 6,
                            color: theme === 'dark' ? OsakaJadePalette.jade.glow : OsakaJadePalette.text.accent,
                            cursor: 'pointer',
                            boxSizing: 'border-box'
                        }, title: theme === 'dark' ? 'Switch to Light Theme (Bamboo Ivory)' : 'Switch to Dark Theme (Osaka Jade)', children: theme === 'dark' ? _jsx(Sun, { size: 15 }) : _jsx(Moon, { size: 15 }) })] })] }));
};
//# sourceMappingURL=HeaderBar.js.map