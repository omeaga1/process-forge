import React from 'react';
import type { SimulationProject } from '@process-forge/protocol';
interface OmnipresentAgentWidgetProps {
    currentProject: SimulationProject;
    onOpenStudio?: () => void;
    onOpenAiModal: () => void;
    isInStudioView?: boolean;
}
export declare const OmnipresentAgentWidget: React.FC<OmnipresentAgentWidgetProps>;
export {};
//# sourceMappingURL=OmnipresentAgentWidget.d.ts.map