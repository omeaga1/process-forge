import { jsx as _jsx } from "react/jsx-runtime";
import { createContext, useContext, useState, useEffect } from 'react';
import { getUserSession, loginUser, registerUser, loginWithPassword, loginWithGoogleCredential as doLoginWithGoogleCredential, logoutUser, updateUserProfile } from './accountManager.js';
const AccountContext = createContext(undefined);
export const AccountProvider = ({ children }) => {
    const [user, setUser] = useState(() => getUserSession());
    const [isAccountModalOpen, setIsAccountModalOpen] = useState(false);
    useEffect(() => {
        const session = getUserSession();
        if (session) {
            setUser(session);
        }
    }, []);
    const openAccountModal = () => setIsAccountModalOpen(true);
    const closeAccountModal = () => setIsAccountModalOpen(false);
    const register = async (credentials) => {
        const session = await registerUser(credentials);
        setUser(session);
        return session;
    };
    const login = async (credentials) => {
        const session = await loginWithPassword(credentials);
        setUser(session);
        return session;
    };
    const signIn = async (provider, details) => {
        const session = await loginUser(provider, details);
        setUser(session);
        return session;
    };
    const signInWithGoogleCredential = async (credentialToken) => {
        const session = await doLoginWithGoogleCredential(credentialToken);
        if (session) {
            setUser(session);
        }
        return session;
    };
    const signOut = () => {
        logoutUser();
        setUser(null);
    };
    const updateProfile = (updates) => {
        const updated = updateUserProfile(updates);
        if (updated) {
            setUser(updated);
        }
    };
    return (_jsx(AccountContext.Provider, { value: {
            user,
            isAuthenticated: !!user,
            isAccountModalOpen,
            openAccountModal,
            closeAccountModal,
            register,
            login,
            signIn,
            signInWithGoogleCredential,
            signOut,
            updateProfile
        }, children: children }));
};
export function useAccount() {
    const context = useContext(AccountContext);
    if (!context) {
        throw new Error('useAccount must be used within an AccountProvider');
    }
    return context;
}
//# sourceMappingURL=useAccount.js.map