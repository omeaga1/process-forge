export {};
//# sourceMappingURL=mcpConfig.test.d.ts.map