@echo off
setlocal
title ProcessForge 1-Click Setup and Purge
echo ========================================================
echo   ProcessForge Industrial Digital Twin Studio Setup
echo ========================================================
echo Stopping any running ProcessForge processes...
taskkill /F /IM ProcessForge.exe /T > nul 2>&1
ping 127.0.0.1 -n 2 > nul

set "TARGET=%LOCALAPPDATA%\ProcessForge"
echo Purging existing installation at %TARGET%...
if exist "%TARGET%" (
  rd /s /q "%TARGET%" > nul 2>&1
)

echo Creating fresh directory structure...
mkdir "%TARGET%" > nul 2>&1
mkdir "%TARGET%\app" > nul 2>&1

echo Copying updated studio application files...
xcopy /E /I /Y "%~dp0app" "%TARGET%\app" > nul
if exist "%~dp0icon.ico" copy /Y "%~dp0icon.ico" "%TARGET%\" > nul
if exist "%~dp0ProcessForge.exe" copy /Y "%~dp0ProcessForge.exe" "%TARGET%\" > nul
if exist "%~dp0Start-ProcessForge.bat" copy /Y "%~dp0Start-ProcessForge.bat" "%TARGET%\" > nul
if exist "%~dp0Update-ProcessForge.cmd" copy /Y "%~dp0Update-ProcessForge.cmd" "%TARGET%\" > nul
if exist "%~dp0README.md" copy /Y "%~dp0README.md" "%TARGET%\" > nul

echo Setting up Desktop shortcut...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([Environment]::GetFolderPath('Desktop') + '\ProcessForge.lnk'); $s.TargetPath = '%TARGET%\ProcessForge.exe'; $s.WorkingDirectory = '%TARGET%'; $s.IconLocation = '%TARGET%\icon.ico,0'; $s.Description = 'ProcessForge Industrial Twin Studio'; $s.Save()"

echo Setting up Start Menu shortcut...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([Environment]::GetFolderPath('StartMenu') + '\Programs\ProcessForge.lnk'); $s.TargetPath = '%TARGET%\ProcessForge.exe'; $s.WorkingDirectory = '%TARGET%'; $s.IconLocation = '%TARGET%\icon.ico,0'; $s.Description = 'ProcessForge Industrial Twin Studio'; $s.Save()"

echo ========================================================
echo   Installation Complete! Launching ProcessForge...
echo ========================================================
start "" "%TARGET%\ProcessForge.exe"
ping 127.0.0.1 -n 2 > nul
exit
