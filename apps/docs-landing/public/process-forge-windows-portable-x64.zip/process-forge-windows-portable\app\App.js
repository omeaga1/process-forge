import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import { useState, useCallback, useEffect } from 'react';
import { ProcessCanvas, SHERWIN_WILLIAMS_PAINT_LINE, BEVERAGE_BOTTLING_LINE, BLANK_LINE, AiModelModal, CommunityUnitOpLibraryModal, getAiConfig, ThemeProvider } from '@process-forge/canvas-ui';
import { createSimulationProject } from '@process-forge/protocol';
import { HeaderBar } from './components/HeaderBar.js';
import { GuestAcknowledgementModal } from './components/GuestAcknowledgementModal.js';
import { StudioEntryGateModal } from './components/StudioEntryGateModal.js';
import { SaveProjectModal } from './components/SaveProjectModal.js';
import { UpdateNotificationBanner } from './components/UpdateNotificationBanner.js';
import { AccountModal } from './components/AccountModal.js';
import { CloudProjectsModal } from './components/CloudProjectsModal.js';
import { StudioErrorBoundary } from './components/StudioErrorBoundary.js';
import { LandingPageHub } from './components/LandingPageHub.js';
import { ProductLandingPage } from './components/ProductLandingPage.js';
import { OmnipresentAgentWidget } from './components/OmnipresentAgentWidget.js';
import { AccountProvider, useAccount } from './auth/useAccount.js';
import { saveProjectToCloud } from './storage/cloudStorageAdapter.js';
import { useAppUpdater } from './hooks/useAppUpdater.js';
import { saveLocalProject, loadCurrentLocalProject, downloadProjectFile, readProjectFromFile } from './storage/localStorageAdapter.js';
function inferTemplateKeyFromProject(proj) {
    if (!proj || !proj.graph)
        return 'blank';
    const name = (proj.name || '').toLowerCase();
    const graphId = (proj.graph.id || '').toLowerCase();
    if (graphId === 'beverage-bottling-line' || name.includes('beverage')) {
        return 'beverage-bottling-line';
    }
    if (graphId === 'blank' || proj.graph.nodes.length === 0 || name.includes('custom')) {
        return 'blank';
    }
    if (graphId === 'sherwin-williams-paint-line' || name.includes('paint') || name.includes('sherwin')) {
        return 'sherwin-williams-paint-line';
    }
    return 'blank';
}
const AppInner = () => {
    const updater = useAppUpdater();
    const { isAccountModalOpen, openAccountModal, closeAccountModal, isAuthenticated } = useAccount();
    const [isEntryGateOpen, setIsEntryGateOpen] = useState(false);
    const [isCloudProjectsModalOpen, setIsCloudProjectsModalOpen] = useState(false);
    const [isAiModalOpen, setIsAiModalOpen] = useState(false);
    const [aiConfig, setAiConfig] = useState(() => getAiConfig());
    const [isGuestModalOpen, setIsGuestModalOpen] = useState(false);
    const [isSaveModalOpen, setIsSaveModalOpen] = useState(false);
    const [isCommunityLibraryOpen, setIsCommunityLibraryOpen] = useState(false);
    // App navigation state:
    // - 'landing': Clean Product Showcase Landing Page (what is ProcessForge, animated PFD tutorial, download .exe)
    // - 'portal': Engineering Project Portal & Hub (cloud projects, orchestrator, templates, quotas)
    // - 'studio': Interactive Flowsheet Canvas Studio (ReactFlow, equipment palette, live simulation)
    const [viewMode, setViewMode] = useState('landing');
    // Initialize or restore active project
    const [project, setProject] = useState(() => {
        const cached = loadCurrentLocalProject();
        if (cached)
            return cached;
        return createSimulationProject('Custom Process Forge', BLANK_LINE, {
            description: 'Clean slate industrial process flowsheet',
            isGuest: true
        });
    });
    const [templateKey, setTemplateKey] = useState(() => inferTemplateKeyFromProject(project));
    // Persist project changes to local browser cache
    useEffect(() => {
        saveLocalProject(project);
    }, [project]);
    const [isDockCollapsed, setIsDockCollapsed] = useState(() => {
        if (typeof window === 'undefined')
            return false;
        return window.innerWidth < 960;
    });
    // Hotkey support: Alt+D or Ctrl+B toggles the Software Engineer dock
    useEffect(() => {
        const handleKeyDown = (e) => {
            if ((e.altKey && (e.key === 'd' || e.key === 'D')) || (e.ctrlKey && (e.key === 'b' || e.key === 'B'))) {
                e.preventDefault();
                setIsDockCollapsed((prev) => !prev);
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, []);
    const handleSelectTemplate = useCallback((key) => {
        setTemplateKey(key);
        let targetGraph = SHERWIN_WILLIAMS_PAINT_LINE;
        let targetName = 'Sherwin-Williams Paint Canning Line';
        let targetDesc = 'Industrial paint blending, filling, labeling, and palletizing line';
        if (key === 'beverage-bottling-line') {
            targetGraph = BEVERAGE_BOTTLING_LINE;
            targetName = 'High-Speed Beverage Bottling Line';
            targetDesc = 'High-speed carbonated beverage bottling and packaging line';
        }
        else if (key === 'blank') {
            targetGraph = BLANK_LINE;
            targetName = 'Custom Process Flow';
            targetDesc = 'Custom industrial process line';
        }
        const updated = createSimulationProject(targetName, targetGraph, {
            description: targetDesc,
            isGuest: project.isGuestProject
        });
        setProject(updated);
        saveLocalProject(updated);
    }, [project.isGuestProject]);
    const handleGraphChange = useCallback((updatedGraph) => {
        setProject((prev) => {
            const updated = {
                ...prev,
                graph: updatedGraph,
                updatedAt: new Date().toISOString()
            };
            saveLocalProject(updated);
            return updated;
        });
    }, []);
    const handleSaveLocal = useCallback((name, description) => {
        setProject((prev) => {
            const updated = {
                ...prev,
                name,
                description,
                updatedAt: new Date().toISOString()
            };
            saveLocalProject(updated);
            return updated;
        });
    }, []);
    const handleDownloadFile = useCallback((name, description) => {
        const updated = {
            ...project,
            name,
            description,
            updatedAt: new Date().toISOString()
        };
        setProject(updated);
        saveLocalProject(updated);
        downloadProjectFile(updated);
    }, [project]);
    const handleSaveCloud = useCallback(async (name, description) => {
        const updated = {
            ...project,
            name,
            description,
            isGuestProject: false,
            updatedAt: new Date().toISOString()
        };
        setProject(updated);
        saveLocalProject(updated);
        await saveProjectToCloud(updated);
    }, [project]);
    const handleSelectCloudProject = useCallback((loaded) => {
        setProject(loaded);
        setTemplateKey(inferTemplateKeyFromProject(loaded));
        saveLocalProject(loaded);
        setIsCloudProjectsModalOpen(false);
    }, []);
    const handleUploadLocalFile = useCallback(async (file) => {
        try {
            const imported = await readProjectFromFile(file);
            setProject(imported);
            setTemplateKey(inferTemplateKeyFromProject(imported));
            saveLocalProject(imported);
            await saveProjectToCloud(imported);
            setIsCloudProjectsModalOpen(false);
            alert(`Imported "${imported.name}" and synced to ProcessForge Cloud.`);
        }
        catch (err) {
            alert(`Error importing file: ${err?.message || String(err)}`);
        }
    }, []);
    const handleImportFile = useCallback(async (file) => {
        try {
            const imported = await readProjectFromFile(file);
            setProject(imported);
            setTemplateKey(inferTemplateKeyFromProject(imported));
            saveLocalProject(imported);
            alert(`Successfully loaded project: "${imported.name}" with ${imported.graph.nodes.length} machines.`);
        }
        catch (err) {
            alert(`Error loading project file: ${err?.message || String(err)}`);
        }
    }, []);
    const handleInsertCommunityNode = useCallback((newNode) => {
        setProject((prev) => {
            const updated = {
                ...prev,
                graph: {
                    ...prev.graph,
                    nodes: [...prev.graph.nodes, newNode]
                },
                updatedAt: new Date().toISOString()
            };
            saveLocalProject(updated);
            return updated;
        });
    }, []);
    const handleCreateBlank = useCallback(() => {
        const blank = createSimulationProject('Custom Process Forge', BLANK_LINE, {
            description: 'Clean slate industrial process flowsheet',
            isGuest: project.isGuestProject
        });
        setTemplateKey('blank');
        setProject(blank);
        saveLocalProject(blank);
        setViewMode('studio');
    }, [project.isGuestProject]);
    const handleSelectTemplateAndLaunch = useCallback((key) => {
        handleSelectTemplate(key);
        setViewMode('studio');
    }, [handleSelectTemplate]);
    const handleSelectCloudProjectAndLaunch = useCallback((loaded) => {
        handleSelectCloudProject(loaded);
        setViewMode('studio');
    }, [handleSelectCloudProject]);
    const handleImportFileAndLaunch = useCallback(async (file) => {
        await handleImportFile(file);
        setViewMode('studio');
    }, [handleImportFile]);
    const handleEnterStudioWithBlankCanvas = useCallback((asGuest = false) => {
        const blank = createSimulationProject('Custom Process Flow', BLANK_LINE, {
            description: 'Clean slate industrial process flowsheet',
            isGuest: asGuest
        });
        setTemplateKey('blank');
        setProject(blank);
        saveLocalProject(blank);
        setViewMode('studio');
    }, []);
    const handleOpenStudio = useCallback(() => {
        if (isAuthenticated) {
            handleEnterStudioWithBlankCanvas(false);
        }
        else {
            setIsEntryGateOpen(true);
        }
    }, [isAuthenticated, handleEnterStudioWithBlankCanvas]);
    const handleNavigateHome = useCallback(() => {
        saveLocalProject(project);
        setViewMode('landing');
    }, [project]);
    const handleOpenPortal = useCallback(() => {
        saveLocalProject(project);
        setViewMode('portal');
    }, [project]);
    const handleLaunchStudioFromLanding = useCallback(() => {
        if (isAuthenticated) {
            handleEnterStudioWithBlankCanvas(false);
        }
        else {
            setIsEntryGateOpen(true);
        }
    }, [isAuthenticated, handleEnterStudioWithBlankCanvas]);
    const handleContinueGuest = useCallback(() => {
        handleEnterStudioWithBlankCanvas(true);
    }, [handleEnterStudioWithBlankCanvas]);
    return (_jsxs("div", { style: { display: 'flex', flexDirection: 'column', width: '100%', height: '100%', maxWidth: '100vw', maxHeight: '100vh', overflow: viewMode === 'landing' ? 'auto' : 'hidden', position: 'relative' }, children: [viewMode === 'landing' ? (_jsx(ProductLandingPage, { onLaunchStudio: handleLaunchStudioFromLanding, onOpenPortal: handleOpenPortal, onSelectTemplate: handleSelectTemplateAndLaunch })) : viewMode === 'portal' ? (_jsx(LandingPageHub, { currentProject: project, onNavigateLanding: handleNavigateHome, onCreateBlank: handleCreateBlank, onSelectTemplate: handleSelectTemplateAndLaunch, onOpenProject: handleSelectCloudProjectAndLaunch, onImportFile: handleImportFileAndLaunch, onOpenStudio: handleOpenStudio, onOpenForgeHub: () => setIsCommunityLibraryOpen(true), onOpenAiModal: () => setIsAiModalOpen(true), onOpenAccountModal: openAccountModal, onOpenCloudProjectsModal: () => setIsCloudProjectsModalOpen(true) })) : (_jsxs(_Fragment, { children: [_jsx(HeaderBar, { currentTemplate: templateKey, isGuestMode: project.isGuestProject, activeAiProvider: aiConfig.provider, onNavigateHome: handleOpenPortal, onSelectTemplate: handleSelectTemplate, onOpenAiModal: () => setIsAiModalOpen(true), onOpenForgeHub: () => setIsCommunityLibraryOpen(true), onOpenSaveModal: () => setIsSaveModalOpen(true), onOpenGuestModal: () => setIsGuestModalOpen(true), onImportFile: handleImportFile, onOpenAccountModal: openAccountModal, onOpenCloudProjects: () => setIsCloudProjectsModalOpen(true), onCheckForUpdates: () => updater.checkForUpdates(true), isCheckingUpdates: updater.isChecking, hasUpdateAvailable: updater.hasUpdate }), _jsx(UpdateNotificationBanner, { status: updater.status, updateInfo: updater.updateInfo, statusMessage: updater.statusMessage, onDismiss: updater.dismissNotification, onCheckForUpdates: () => updater.checkForUpdates(true), onRestartAndApply: updater.restartAndApplyUpdate, onHardReload: updater.hardReloadApp }), _jsx("div", { style: { flex: 1, position: 'relative', overflow: 'hidden', minWidth: 0, minHeight: 0 }, children: _jsx(ProcessCanvas, { graph: project.graph, onGraphChange: handleGraphChange, isDockCollapsed: isDockCollapsed, onToggleDockCollapse: () => setIsDockCollapsed((prev) => !prev) }) })] })), viewMode === 'studio' && (_jsx(OmnipresentAgentWidget, { currentProject: project, isInStudioView: false, onOpenStudio: handleOpenStudio, onOpenAiModal: () => setIsAiModalOpen(true) })), _jsx(AiModelModal, { isOpen: isAiModalOpen, onClose: () => setIsAiModalOpen(false), onConfigChanged: (cfg) => setAiConfig(cfg) }), _jsx(StudioEntryGateModal, { isOpen: isEntryGateOpen, onClose: () => setIsEntryGateOpen(false), onOpenAccountModal: () => {
                    setIsEntryGateOpen(false);
                    openAccountModal();
                }, onContinueGuest: handleContinueGuest }), _jsx(GuestAcknowledgementModal, { isOpen: isGuestModalOpen, onClose: () => setIsGuestModalOpen(false), onExportFile: () => downloadProjectFile(project), onOpenAccountModal: openAccountModal }), _jsx(SaveProjectModal, { isOpen: isSaveModalOpen, project: project, onClose: () => setIsSaveModalOpen(false), onSaveLocal: handleSaveLocal, onDownloadFile: handleDownloadFile, onSaveCloud: handleSaveCloud }), _jsx(CommunityUnitOpLibraryModal, { isOpen: isCommunityLibraryOpen, onClose: () => setIsCommunityLibraryOpen(false), onInsertNode: handleInsertCommunityNode }), _jsx(AccountModal, { isOpen: isAccountModalOpen, onClose: closeAccountModal, onOpenCloudProjects: () => {
                    closeAccountModal();
                    setIsCloudProjectsModalOpen(true);
                } }), _jsx(CloudProjectsModal, { isOpen: isCloudProjectsModalOpen, onClose: () => setIsCloudProjectsModalOpen(false), onSelectProject: handleSelectCloudProject, onUploadLocalFile: handleUploadLocalFile })] }));
};
export const App = () => {
    return (_jsx(ThemeProvider, { children: _jsx(AccountProvider, { children: _jsx(StudioErrorBoundary, { children: _jsx(AppInner, {}) }) }) }));
};
export default App;
//# sourceMappingURL=App.js.map