import React from 'react';
export interface ProductLandingPageProps {
    onLaunchStudio: () => void;
    onOpenPortal: () => void;
    onSelectTemplate: (templateKey: string) => void;
}
export declare const ProductLandingPage: React.FC<ProductLandingPageProps>;
export default ProductLandingPage;
//# sourceMappingURL=ProductLandingPage.d.ts.map