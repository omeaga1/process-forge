import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useState, useEffect, useRef } from 'react';
import { Plus, Cloud, Cpu, User, ArrowRight, Upload, Trash2, ExternalLink, Send, Loader2, Sun, Moon, ChevronRight, Database, Workflow, Lock, KeyRound, Terminal, Sliders, Download, Check, Copy } from 'lucide-react';
import { useTheme, getLlmCredentials, getAiConnection, isAgentChatUnlocked, dispatchMasterOrchestratorMessage, ProcessForgeLogo, ProcessForgeEmblem } from '@process-forge/canvas-ui';
import { useAccount } from '../auth/useAccount.js';
import { listUserCloudProjects, deleteProjectFromCloud } from '../storage/cloudStorageAdapter.js';
export const LandingPageHub = ({ currentProject, onNavigateLanding, onCreateBlank, onSelectTemplate, onOpenProject, onImportFile, onOpenStudio, onOpenForgeHub, onOpenAiModal, onOpenAccountModal, onOpenCloudProjectsModal }) => {
    const { palette, theme, toggleTheme } = useTheme();
    const OsakaJadePalette = palette;
    const { user, isAuthenticated } = useAccount();
    const fileInputRef = useRef(null);
    const [cloudProjects, setCloudProjects] = useState([]);
    const [isLoadingProjects, setIsLoadingProjects] = useState(true);
    const [creds, setCreds] = useState(() => getLlmCredentials());
    const [aiConn, setAiConn] = useState(() => getAiConnection());
    const lockStatus = isAgentChatUnlocked(aiConn, creds);
    const hasKey = lockStatus.unlocked;
    // Agent Chat State on Landing Page
    const [agentInput, setAgentInput] = useState('');
    const [isAgentThinking, setIsAgentThinking] = useState(false);
    const [agentConversation, setAgentConversation] = useState([]);
    const [copiedSnippet, setCopiedSnippet] = useState(false);
    const copyToClipboard = (text) => {
        navigator.clipboard.writeText(text);
        setCopiedSnippet(true);
        setTimeout(() => setCopiedSnippet(false), 2000);
    };
    // Fetch Cloud Projects
    useEffect(() => {
        setIsLoadingProjects(true);
        listUserCloudProjects(user)
            .then((items) => {
            setCloudProjects(items);
            setIsLoadingProjects(false);
        })
            .catch(() => setIsLoadingProjects(false));
    }, [user]);
    // Sync credentials and connection on storage updates
    useEffect(() => {
        const handleStorage = () => {
            const newCreds = getLlmCredentials();
            const newConn = getAiConnection();
            setCreds(newCreds);
            setAiConn(newConn);
        };
        window.addEventListener('storage', handleStorage);
        return () => window.removeEventListener('storage', handleStorage);
    }, []);
    const handleFileChange = (e) => {
        const file = e.target.files?.[0];
        if (file) {
            onImportFile(file);
            e.target.value = '';
        }
    };
    const handleAgentSend = async (promptToSend) => {
        if (!lockStatus.unlocked) {
            onOpenAiModal();
            return;
        }
        const text = promptToSend || agentInput;
        if (!text.trim() || isAgentThinking)
            return;
        const userMsg = {
            id: `usr-${Date.now()}`,
            sender: 'user',
            senderTitle: user?.name || 'Process Engineer',
            text,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
        setAgentConversation((prev) => [...prev, userMsg]);
        if (!promptToSend)
            setAgentInput('');
        setIsAgentThinking(true);
        try {
            const res = await dispatchMasterOrchestratorMessage(text, {
                graphName: currentProject.graph.name,
                nodeCount: currentProject.graph.nodes.length,
                totalPackaged: 0,
                averageRatePerMin: 0
            });
            const agentMsg = {
                id: `orch-${Date.now()}`,
                sender: 'master_orchestrator',
                senderTitle: 'Plant Orchestrator',
                text: res.text,
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                modelBadge: res.senderBadge
            };
            setAgentConversation((prev) => [...prev, agentMsg]);
        }
        catch (err) {
            setAgentConversation((prev) => [
                ...prev,
                {
                    id: `err-${Date.now()}`,
                    sender: 'master_orchestrator',
                    senderTitle: 'Error',
                    text: `[Error]: ${err.message || 'Failed to call model provider'}`,
                    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                }
            ]);
        }
        finally {
            setIsAgentThinking(false);
        }
    };
    const handleDeleteCloudProject = async (e, recordId) => {
        e.stopPropagation();
        if (!user)
            return;
        if (window.confirm('Delete this project from your cloud storage?')) {
            await deleteProjectFromCloud(recordId, user);
            setCloudProjects((prev) => prev.filter((p) => p.id !== recordId));
        }
    };
    return (_jsxs("div", { style: {
            display: 'flex',
            flexDirection: 'column',
            width: '100%',
            height: '100%',
            overflowY: 'auto',
            backgroundColor: OsakaJadePalette.background.base,
            backgroundImage: theme === 'dark'
                ? `
            radial-gradient(ellipse at 50% 0%, rgba(45, 213, 183, 0.12) 0%, transparent 60%),
            radial-gradient(circle at 10% 40%, rgba(84, 158, 106, 0.08) 0%, transparent 40%),
            linear-gradient(rgba(113, 206, 173, 0.05) 1px, transparent 1px),
            linear-gradient(90deg, rgba(113, 206, 173, 0.05) 1px, transparent 1px),
            repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0, 0, 0, 0.2) 3px, transparent 4px)
          `
                : `
            radial-gradient(ellipse at 50% 0%, rgba(35, 148, 104, 0.08) 0%, transparent 60%),
            linear-gradient(rgba(35, 148, 104, 0.06) 1px, transparent 1px),
            linear-gradient(90deg, rgba(35, 148, 104, 0.06) 1px, transparent 1px)
          `,
            backgroundSize: theme === 'dark'
                ? '100% 100%, 100% 100%, 32px 32px, 32px 32px, 100% 4px'
                : '100% 100%, 28px 28px, 28px 28px',
            color: OsakaJadePalette.text.primary,
            fontFamily: 'Inter, system-ui, sans-serif'
        }, children: [_jsx("input", { ref: fileInputRef, type: "file", accept: ".json,.pfg,.pfg.json", style: { display: 'none' }, onChange: handleFileChange }), _jsxs("header", { style: {
                    height: 56,
                    backgroundColor: OsakaJadePalette.background.surface,
                    borderBottom: `1px solid ${OsakaJadePalette.border.default}`,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: '0 24px',
                    flexShrink: 0
                }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 12 }, children: [_jsx("div", { onClick: onNavigateLanding, style: { display: 'flex', alignItems: 'center', cursor: onNavigateLanding ? 'pointer' : 'default' }, title: onNavigateLanding ? 'Return to Product Showcase & Landing Page' : undefined, children: _jsx(ProcessForgeLogo, { size: 32, wordmarkSize: 17 }) }), _jsx("span", { style: {
                                    fontSize: 10,
                                    fontWeight: 700,
                                    padding: '2px 8px',
                                    borderRadius: 4,
                                    backgroundColor: 'rgba(45, 213, 183, 0.12)',
                                    border: `1px solid ${OsakaJadePalette.border.strong}`,
                                    color: OsakaJadePalette.jade[400],
                                    fontFamily: '"JetBrains Mono", monospace'
                                }, children: "PROJECT PORTAL" }), onNavigateLanding && (_jsx("button", { onClick: onNavigateLanding, style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: 5,
                                    padding: '4px 10px',
                                    borderRadius: 4,
                                    backgroundColor: 'rgba(255, 255, 255, 0.04)',
                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                    color: OsakaJadePalette.text.secondary,
                                    fontSize: 11,
                                    fontWeight: 600,
                                    fontFamily: '"JetBrains Mono", monospace',
                                    cursor: 'pointer'
                                }, title: "Return to Product Showcase Landing Page", children: _jsx("span", { children: "\u2190 SHOWCASE" }) }))] }), _jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 10 }, children: [_jsxs("a", { href: "/ProcessForge-Setup-x64.exe", download: "ProcessForge-Setup-x64.exe", style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: 6,
                                    padding: '6px 12px',
                                    borderRadius: 4,
                                    backgroundColor: OsakaJadePalette.jade[600],
                                    border: `1px solid ${OsakaJadePalette.jade[400]}`,
                                    color: '#ffffff',
                                    fontSize: 11,
                                    fontWeight: 700,
                                    fontFamily: '"JetBrains Mono", monospace',
                                    textDecoration: 'none',
                                    cursor: 'pointer',
                                    boxShadow: `0 0 10px ${OsakaJadePalette.jade.glow}44`,
                                    transition: 'all 0.12s ease'
                                }, title: "Download ProcessForge for Windows (Native .exe Setup)", children: [_jsx(Download, { size: 13, strokeWidth: 2.5 }), _jsx("span", { children: "DOWNLOAD (.EXE)" })] }), _jsxs("button", { onClick: onOpenAiModal, style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: 7,
                                    padding: '6px 12px',
                                    borderRadius: 4,
                                    backgroundColor: hasKey
                                        ? (theme === 'dark' ? 'rgba(45, 213, 183, 0.08)' : 'rgba(35, 148, 104, 0.08)')
                                        : (theme === 'dark' ? 'rgba(255, 83, 69, 0.08)' : 'rgba(220, 38, 38, 0.08)'),
                                    border: `1px solid ${hasKey ? OsakaJadePalette.border.strong : OsakaJadePalette.status.failed}66`,
                                    color: hasKey ? OsakaJadePalette.text.primary : OsakaJadePalette.status.failed,
                                    fontSize: 11,
                                    fontWeight: 600,
                                    fontFamily: '"JetBrains Mono", monospace',
                                    cursor: 'pointer',
                                    transition: 'all 0.12s ease'
                                }, title: "Configure AI Model Providers (Claude, Gemini, OpenAI, Ollama)", children: [_jsx("span", { style: {
                                            width: 7,
                                            height: 7,
                                            borderRadius: '50%',
                                            backgroundColor: hasKey ? OsakaJadePalette.jade.glow : OsakaJadePalette.status.failed,
                                            boxShadow: hasKey ? `0 0 6px ${OsakaJadePalette.jade.glow}` : undefined
                                        } }), _jsx("span", { children: hasKey ? `AI: ${creds.provider.toUpperCase()}` : 'LINK AI MODEL' }), _jsx(Sliders, { size: 12, style: { opacity: 0.7, marginLeft: 2 } })] }), _jsxs("button", { onClick: onOpenAccountModal, style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: 6,
                                    padding: '6px 12px',
                                    borderRadius: 4,
                                    backgroundColor: OsakaJadePalette.background.surface,
                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                    color: OsakaJadePalette.text.primary,
                                    fontSize: 11,
                                    fontWeight: 600,
                                    fontFamily: '"JetBrains Mono", monospace',
                                    cursor: 'pointer',
                                    transition: 'all 0.12s ease'
                                }, title: isAuthenticated ? `Signed in as ${user?.name}` : 'Sign In / Account', children: [user?.avatarUrl ? (_jsx("img", { src: user.avatarUrl, alt: "Avatar", style: { width: 16, height: 16, borderRadius: '50%' } })) : (_jsx(User, { size: 13, color: OsakaJadePalette.text.secondary })), _jsx("span", { children: isAuthenticated ? (user?.name?.split(' ')[0]?.toUpperCase() || 'ACCOUNT') : 'SIGN IN' })] }), _jsx("button", { onClick: toggleTheme, style: {
                                    width: 32,
                                    height: 32,
                                    borderRadius: 4,
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    backgroundColor: OsakaJadePalette.background.surface,
                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                    color: OsakaJadePalette.text.secondary,
                                    cursor: 'pointer',
                                    transition: 'all 0.12s ease'
                                }, title: theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode', children: theme === 'dark' ? _jsx(Sun, { size: 14 }) : _jsx(Moon, { size: 14 }) })] })] }), _jsxs("section", { style: {
                    padding: '40px 32px 32px 32px',
                    maxWidth: 1280,
                    width: '100%',
                    margin: '0 auto',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 16
                }, children: [_jsx("div", { style: { display: 'flex', alignItems: 'center', gap: 8 }, children: _jsxs("span", { style: {
                                padding: '4px 10px',
                                borderRadius: 16,
                                backgroundColor: 'rgba(16, 185, 129, 0.12)',
                                border: `1px solid ${OsakaJadePalette.jade[600]}`,
                                color: OsakaJadePalette.text.accent,
                                fontSize: 11,
                                fontWeight: 700,
                                display: 'flex',
                                alignItems: 'center',
                                gap: 6
                            }, children: [_jsx("span", { style: {
                                        width: 6,
                                        height: 6,
                                        borderRadius: '50%',
                                        backgroundColor: OsakaJadePalette.jade[500],
                                        boxShadow: `0 0 8px ${OsakaJadePalette.jade.glow}`
                                    } }), "CONTINUOUS & DISCRETE PROCESS SIMULATION"] }) }), _jsx("h1", { style: {
                            fontSize: 32,
                            fontWeight: 800,
                            letterSpacing: '-0.03em',
                            margin: 0,
                            lineHeight: 1.2,
                            color: OsakaJadePalette.text.primary
                        }, children: "Design, Simulate & Orchestrate Industrial Plants" }), _jsx("p", { style: {
                            fontSize: 15,
                            lineHeight: 1.5,
                            color: OsakaJadePalette.text.secondary,
                            maxWidth: 720,
                            margin: 0
                        }, children: "Continuous fluid mechanics, discrete line flow contracts, automated ASME equipment solvers, and real-time process optimization." }), _jsxs("div", { style: { display: 'flex', flexWrap: 'wrap', gap: 10, marginTop: 8 }, children: [_jsxs("a", { href: "/ProcessForge-Setup-x64.exe", download: "ProcessForge-Setup-x64.exe", style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: 8,
                                    padding: '11px 16px',
                                    borderRadius: 4,
                                    backgroundColor: OsakaJadePalette.background.surface,
                                    border: `1px solid ${OsakaJadePalette.border.strong}`,
                                    color: OsakaJadePalette.text.primary,
                                    fontSize: 13,
                                    fontWeight: 600,
                                    cursor: 'pointer',
                                    fontFamily: '"JetBrains Mono", monospace',
                                    letterSpacing: '0.02em',
                                    textDecoration: 'none',
                                    transition: 'all 0.12s ease'
                                }, title: "Download ProcessForge Windows Setup (.exe Installer)", children: [_jsx(Download, { size: 14 }), _jsx("span", { children: "Desktop App (.exe)" })] }), _jsxs("button", { onClick: onOpenStudio, style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: 8,
                                    padding: '11px 20px',
                                    borderRadius: 4,
                                    backgroundColor: OsakaJadePalette.jade[600],
                                    border: `1px solid ${OsakaJadePalette.jade[400]}`,
                                    color: '#ffffff',
                                    fontSize: 13,
                                    fontWeight: 700,
                                    cursor: 'pointer',
                                    boxShadow: theme === 'dark'
                                        ? `inset 0 1px 0 rgba(255,255,255,0.25), 0 3px 12px ${OsakaJadePalette.jade.glow}44`
                                        : '0 2px 4px rgba(0,0,0,0.1)',
                                    fontFamily: '"JetBrains Mono", monospace',
                                    textTransform: 'uppercase',
                                    letterSpacing: '0.04em',
                                    transition: 'all 0.12s ease'
                                }, title: "Launch Interactive Canvas Studio", children: [_jsx(Terminal, { size: 16, strokeWidth: 2.5 }), _jsx("span", { children: "Open Studio" }), _jsx(ArrowRight, { size: 14 })] }), _jsxs("button", { onClick: onCreateBlank, style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: 8,
                                    padding: '11px 16px',
                                    borderRadius: 4,
                                    backgroundColor: OsakaJadePalette.background.surface,
                                    border: `1px solid ${OsakaJadePalette.border.strong}`,
                                    color: OsakaJadePalette.text.primary,
                                    fontSize: 13,
                                    fontWeight: 600,
                                    cursor: 'pointer',
                                    fontFamily: '"JetBrains Mono", monospace',
                                    letterSpacing: '0.02em',
                                    transition: 'all 0.12s ease'
                                }, title: "Create clean slate industrial flowsheet", children: [_jsx(Plus, { size: 15, strokeWidth: 2.5, color: OsakaJadePalette.jade.glow }), _jsx("span", { children: "Blank Canvas" })] }), _jsxs("button", { onClick: () => onSelectTemplate('sherwin-williams-paint-line'), style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: 8,
                                    padding: '11px 16px',
                                    borderRadius: 4,
                                    backgroundColor: OsakaJadePalette.background.surface,
                                    border: `1px solid ${OsakaJadePalette.border.strong}`,
                                    color: OsakaJadePalette.text.primary,
                                    fontSize: 13,
                                    fontWeight: 600,
                                    cursor: 'pointer',
                                    fontFamily: '"JetBrains Mono", monospace',
                                    letterSpacing: '0.02em',
                                    transition: 'all 0.12s ease'
                                }, title: "Load reference 6-machine industrial packaging line", children: [_jsx(Workflow, { size: 15, color: OsakaJadePalette.jade.glow }), _jsx("span", { children: "Paint Canning Line" })] }), onOpenForgeHub && (_jsxs("button", { onClick: onOpenForgeHub, style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: 8,
                                    padding: '11px 16px',
                                    borderRadius: 4,
                                    backgroundColor: theme === 'dark' ? 'rgba(45, 213, 183, 0.08)' : 'rgba(35, 148, 104, 0.08)',
                                    border: `1px solid ${OsakaJadePalette.border.glow}`,
                                    color: OsakaJadePalette.text.accent,
                                    fontSize: 13,
                                    fontWeight: 600,
                                    cursor: 'pointer',
                                    fontFamily: '"JetBrains Mono", monospace',
                                    letterSpacing: '0.02em',
                                    transition: 'all 0.12s ease'
                                }, children: [_jsx(ProcessForgeEmblem, { size: 15, glow: false }), _jsx("span", { children: "ProcessForge Hub" })] })), _jsxs("button", { onClick: () => fileInputRef.current?.click(), style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: 8,
                                    padding: '11px 14px',
                                    borderRadius: 4,
                                    backgroundColor: OsakaJadePalette.background.surface,
                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                    color: OsakaJadePalette.text.secondary,
                                    fontSize: 12,
                                    fontWeight: 500,
                                    cursor: 'pointer',
                                    fontFamily: '"JetBrains Mono", monospace',
                                    letterSpacing: '0.02em',
                                    transition: 'all 0.12s ease'
                                }, children: [_jsx(Upload, { size: 14 }), _jsx("span", { children: "Import .pfg" })] }), _jsxs("button", { onClick: onOpenCloudProjectsModal, style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: 8,
                                    padding: '11px 14px',
                                    borderRadius: 4,
                                    backgroundColor: OsakaJadePalette.background.surface,
                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                    color: OsakaJadePalette.text.secondary,
                                    fontSize: 12,
                                    fontWeight: 500,
                                    cursor: 'pointer',
                                    fontFamily: '"JetBrains Mono", monospace',
                                    letterSpacing: '0.02em',
                                    transition: 'all 0.12s ease'
                                }, children: [_jsx(Cloud, { size: 14 }), _jsxs("span", { children: ["Cloud Projects (", cloudProjects.length, ")"] })] })] }), _jsxs("div", { style: {
                            display: 'flex',
                            alignItems: 'center',
                            gap: 12,
                            flexWrap: 'wrap',
                            marginTop: 4,
                            paddingTop: 14,
                            borderTop: `1px solid ${OsakaJadePalette.border.subtle}`
                        }, children: [_jsxs("div", { style: {
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: 8,
                                    backgroundColor: OsakaJadePalette.background.surface,
                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                    borderRadius: 6,
                                    padding: '6px 12px',
                                    fontSize: '0.8rem',
                                    fontFamily: 'monospace'
                                }, children: [_jsx(Terminal, { size: 14, color: OsakaJadePalette.jade[400] }), _jsx("span", { style: { color: OsakaJadePalette.text.secondary }, children: "irm https://process-forge.pages.dev/install.ps1 | iex" }), _jsx("button", { onClick: () => copyToClipboard('irm https://process-forge.pages.dev/install.ps1 | iex'), title: "Copy PowerShell 1-Click Install Command", style: {
                                            background: 'none',
                                            border: 'none',
                                            cursor: 'pointer',
                                            color: OsakaJadePalette.jade[400],
                                            display: 'flex',
                                            alignItems: 'center',
                                            padding: '2px',
                                            marginLeft: '4px'
                                        }, children: copiedSnippet ? _jsx(Check, { size: 14 }) : _jsx(Copy, { size: 14 }) })] }), _jsxs("a", { href: "/install.cmd", download: "install.cmd", style: {
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: 5,
                                    padding: '6px 12px',
                                    borderRadius: 6,
                                    backgroundColor: OsakaJadePalette.background.surface,
                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                    color: OsakaJadePalette.text.secondary,
                                    fontSize: '0.78rem',
                                    fontWeight: 600,
                                    textDecoration: 'none',
                                    fontFamily: '"JetBrains Mono", monospace'
                                }, title: "Download 1-Click Install Script (.cmd)", children: [_jsx(Download, { size: 12 }), _jsx("span", { children: "1-Click Script (.cmd)" })] }), _jsxs("a", { href: "https://github.com/omeaga1/process-forge/releases/tag/v0.1.1", target: "_blank", rel: "noreferrer", style: {
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: 5,
                                    padding: '6px 12px',
                                    borderRadius: 6,
                                    backgroundColor: OsakaJadePalette.background.surface,
                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                    color: OsakaJadePalette.text.muted,
                                    fontSize: '0.78rem',
                                    textDecoration: 'none'
                                }, children: [_jsx("span", { children: "All Releases (.exe, macOS, Linux)" }), _jsx(ExternalLink, { size: 12 })] }), _jsx("span", { style: { fontSize: '0.72rem', color: OsakaJadePalette.text.muted }, children: "1-Click automated setup \u2022 Antivirus-safe \u2022 Offline native desktop support \u2022 Zero login required" })] })] }), _jsxs("main", { style: {
                    maxWidth: 1280,
                    width: '100%',
                    margin: '0 auto',
                    padding: '0 32px 48px 32px',
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))',
                    gap: 24
                }, children: [_jsxs("div", { style: { display: 'flex', flexDirection: 'column', gap: 24 }, children: [_jsxs("div", { style: {
                                    backgroundColor: OsakaJadePalette.background.surface,
                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                    borderRadius: 12,
                                    padding: 20
                                }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 8 }, children: [_jsx(Cloud, { size: 18, color: OsakaJadePalette.jade[400] }), _jsx("h2", { style: { fontSize: 16, fontWeight: 700, margin: 0, color: OsakaJadePalette.text.primary }, children: "Cloud Storage Projects" })] }), _jsxs("button", { onClick: onOpenCloudProjectsModal, style: {
                                                    background: 'none',
                                                    border: 'none',
                                                    color: OsakaJadePalette.text.accent,
                                                    fontSize: 12,
                                                    fontWeight: 600,
                                                    cursor: 'pointer',
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    gap: 4
                                                }, children: [_jsxs("span", { children: ["View All (", cloudProjects.length, ")"] }), _jsx(ChevronRight, { size: 14 })] })] }), isLoadingProjects ? (_jsxs("div", { style: { padding: '24px 0', textAlign: 'center', color: OsakaJadePalette.text.muted, fontSize: 13 }, children: [_jsx(Loader2, { size: 18, className: "animate-spin", style: { margin: '0 auto 8px auto' } }), _jsx("span", { children: "Loading your cloud flowsheets..." })] })) : cloudProjects.length === 0 ? (_jsxs("div", { style: {
                                            padding: 24,
                                            textAlign: 'center',
                                            backgroundColor: OsakaJadePalette.background.canvas,
                                            borderRadius: 8,
                                            border: `1px dashed ${OsakaJadePalette.border.default}`
                                        }, children: [_jsx(Database, { size: 24, color: OsakaJadePalette.text.muted, style: { margin: '0 auto 8px auto' } }), _jsx("div", { style: { fontSize: 13, fontWeight: 600, color: OsakaJadePalette.text.primary }, children: "No Cloud Projects Yet" }), _jsx("div", { style: { fontSize: 12, color: OsakaJadePalette.text.muted, marginTop: 4 }, children: "Create a new process forge and save it to the cloud to access it from any browser." })] })) : (_jsx("div", { style: { display: 'flex', flexDirection: 'column', gap: 10 }, children: cloudProjects.slice(0, 3).map((cp) => (_jsxs("div", { onClick: () => onOpenProject(cp.bundle), style: {
                                                padding: '12px 14px',
                                                backgroundColor: OsakaJadePalette.background.canvas,
                                                border: `1px solid ${OsakaJadePalette.border.default}`,
                                                borderRadius: 8,
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'space-between',
                                                cursor: 'pointer',
                                                transition: 'all 0.15s ease'
                                            }, onMouseEnter: (e) => {
                                                e.currentTarget.style.borderColor = OsakaJadePalette.jade[600];
                                            }, onMouseLeave: (e) => {
                                                e.currentTarget.style.borderColor = OsakaJadePalette.border.default;
                                            }, children: [_jsxs("div", { style: { minWidth: 0, flex: 1, marginRight: 12 }, children: [_jsx("div", { style: { fontSize: 13, fontWeight: 700, color: OsakaJadePalette.text.primary, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }, children: cp.name }), _jsxs("div", { style: { fontSize: 11, color: OsakaJadePalette.text.muted, marginTop: 2 }, children: [cp.nodeCount, " Unit-Ops \u2022 ", cp.streamCount, " Streams \u2022 ", new Date(cp.updatedAt).toLocaleDateString()] })] }), _jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }, children: [_jsx("span", { style: {
                                                                fontSize: 10,
                                                                padding: '2px 6px',
                                                                borderRadius: 4,
                                                                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                                                                border: `1px solid rgba(16, 185, 129, 0.25)`,
                                                                color: OsakaJadePalette.text.accent,
                                                                fontWeight: 600
                                                            }, children: "Cloud Synced" }), _jsx("button", { onClick: (e) => handleDeleteCloudProject(e, cp.id), style: {
                                                                background: 'none',
                                                                border: 'none',
                                                                color: OsakaJadePalette.text.muted,
                                                                cursor: 'pointer',
                                                                padding: 4
                                                            }, title: "Delete project", children: _jsx(Trash2, { size: 13 }) }), _jsx("span", { style: { color: OsakaJadePalette.jade.glow }, children: _jsx(ArrowRight, { size: 14 }) })] })] }, cp.id))) }))] }), _jsxs("div", { style: {
                                    backgroundColor: OsakaJadePalette.background.surface,
                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                    borderRadius: 12,
                                    padding: 20
                                }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }, children: [_jsx(Workflow, { size: 18, color: OsakaJadePalette.jade[400] }), _jsx("h2", { style: { fontSize: 16, fontWeight: 700, margin: 0, color: OsakaJadePalette.text.primary }, children: "Industrial Templates & Line Examples" })] }), _jsxs("div", { style: { display: 'flex', flexDirection: 'column', gap: 12 }, children: [_jsxs("div", { onClick: () => onSelectTemplate('sherwin-williams-paint-line'), style: {
                                                    padding: 14,
                                                    backgroundColor: OsakaJadePalette.background.canvas,
                                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                                    borderRadius: 8,
                                                    cursor: 'pointer',
                                                    transition: 'border-color 0.15s ease'
                                                }, onMouseEnter: (e) => {
                                                    e.currentTarget.style.borderColor = OsakaJadePalette.jade[600];
                                                }, onMouseLeave: (e) => {
                                                    e.currentTarget.style.borderColor = OsakaJadePalette.border.default;
                                                }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between' }, children: [_jsx("div", { style: { fontSize: 14, fontWeight: 700, color: OsakaJadePalette.text.primary }, children: "Sherwin-Williams Architectural Paint Canning Line" }), _jsx("span", { style: {
                                                                    fontSize: 10,
                                                                    fontWeight: 700,
                                                                    padding: '2px 6px',
                                                                    borderRadius: 4,
                                                                    backgroundColor: 'rgba(16, 185, 129, 0.15)',
                                                                    color: OsakaJadePalette.text.accent
                                                                }, children: "6 Machines \u2022 120 CPM" })] }), _jsxs("div", { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 10 }, children: [_jsx("span", { style: { fontSize: 10, fontFamily: '"JetBrains Mono", monospace', color: OsakaJadePalette.text.muted }, children: "SYS // LINE-CAN-01" }), _jsxs("div", { style: {
                                                                    display: 'inline-flex',
                                                                    alignItems: 'center',
                                                                    gap: 6,
                                                                    padding: '4px 10px',
                                                                    borderRadius: 3,
                                                                    backgroundColor: theme === 'dark' ? 'rgba(45, 213, 183, 0.08)' : 'rgba(35, 148, 104, 0.08)',
                                                                    border: `1px solid ${OsakaJadePalette.border.strong}`,
                                                                    fontSize: 11,
                                                                    fontFamily: '"JetBrains Mono", monospace',
                                                                    color: OsakaJadePalette.text.accent,
                                                                    fontWeight: 600,
                                                                    letterSpacing: '0.02em'
                                                                }, children: [_jsx("span", { children: "LAUNCH STUDIO" }), _jsx(ArrowRight, { size: 12 })] })] })] }), _jsxs("div", { onClick: () => onSelectTemplate('beverage-bottling-line'), style: {
                                                    padding: 14,
                                                    backgroundColor: OsakaJadePalette.background.canvas,
                                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                                    borderRadius: 8,
                                                    cursor: 'pointer',
                                                    transition: 'border-color 0.15s ease'
                                                }, onMouseEnter: (e) => {
                                                    e.currentTarget.style.borderColor = OsakaJadePalette.jade[600];
                                                }, onMouseLeave: (e) => {
                                                    e.currentTarget.style.borderColor = OsakaJadePalette.border.default;
                                                }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between' }, children: [_jsx("div", { style: { fontSize: 14, fontWeight: 700, color: OsakaJadePalette.text.primary }, children: "High-Speed Beverage Bottling & Packaging Line" }), _jsx("span", { style: {
                                                                    fontSize: 10,
                                                                    fontWeight: 700,
                                                                    padding: '2px 6px',
                                                                    borderRadius: 4,
                                                                    backgroundColor: 'rgba(14, 165, 233, 0.15)',
                                                                    color: '#38bdf8'
                                                                }, children: "5 Machines \u2022 300 BPM" })] }), _jsx("p", { style: { fontSize: 12, color: OsakaJadePalette.text.secondary, margin: '6px 0 10px 0', lineHeight: 1.4 }, children: "Continuous carbonation vessel, high-speed rotary rinser/filler, crown capper, accumulation conveyor, and case tray shrink-packager." }), _jsxs("div", { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 10 }, children: [_jsx("span", { style: { fontSize: 10, fontFamily: '"JetBrains Mono", monospace', color: OsakaJadePalette.text.muted }, children: "SYS // LINE-BOT-02" }), _jsxs("div", { style: {
                                                                    display: 'inline-flex',
                                                                    alignItems: 'center',
                                                                    gap: 6,
                                                                    padding: '4px 10px',
                                                                    borderRadius: 3,
                                                                    backgroundColor: theme === 'dark' ? 'rgba(14, 165, 233, 0.08)' : 'rgba(2, 132, 199, 0.08)',
                                                                    border: `1px solid rgba(56, 189, 248, 0.3)`,
                                                                    fontSize: 11,
                                                                    fontFamily: '"JetBrains Mono", monospace',
                                                                    color: '#38bdf8',
                                                                    fontWeight: 600,
                                                                    letterSpacing: '0.02em'
                                                                }, children: [_jsx("span", { children: "LAUNCH STUDIO" }), _jsx(ArrowRight, { size: 12 })] })] })] }), _jsxs("div", { onClick: onCreateBlank, style: {
                                                    padding: 14,
                                                    backgroundColor: OsakaJadePalette.background.canvas,
                                                    border: `1px dashed ${OsakaJadePalette.border.default}`,
                                                    borderRadius: 8,
                                                    cursor: 'pointer',
                                                    transition: 'border-color 0.15s ease'
                                                }, onMouseEnter: (e) => {
                                                    e.currentTarget.style.borderColor = OsakaJadePalette.jade[600];
                                                }, onMouseLeave: (e) => {
                                                    e.currentTarget.style.borderColor = OsakaJadePalette.border.default;
                                                }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between' }, children: [_jsx("div", { style: { fontSize: 14, fontWeight: 700, color: OsakaJadePalette.text.primary }, children: "Custom Blank Process Forge" }), _jsx("span", { style: {
                                                                    fontSize: 10,
                                                                    fontWeight: 700,
                                                                    padding: '2px 6px',
                                                                    borderRadius: 4,
                                                                    backgroundColor: 'rgba(255, 255, 255, 0.05)',
                                                                    color: OsakaJadePalette.text.muted
                                                                }, children: "Empty Canvas" })] }), _jsx("p", { style: { fontSize: 12, color: OsakaJadePalette.text.secondary, margin: '6px 0 10px 0', lineHeight: 1.4 }, children: "A clean grid ready for your custom process equipment, ASME nozzles, instrument loops, and unit-op CAD configurations." }), _jsxs("div", { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 10 }, children: [_jsx("span", { style: { fontSize: 10, fontFamily: '"JetBrains Mono", monospace', color: OsakaJadePalette.text.muted }, children: "SYS // SCRATCH-CANVAS" }), _jsxs("div", { style: {
                                                                    display: 'inline-flex',
                                                                    alignItems: 'center',
                                                                    gap: 6,
                                                                    padding: '4px 10px',
                                                                    borderRadius: 3,
                                                                    backgroundColor: 'rgba(255, 255, 255, 0.04)',
                                                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                                                    fontSize: 11,
                                                                    fontFamily: '"JetBrains Mono", monospace',
                                                                    color: OsakaJadePalette.text.primary,
                                                                    fontWeight: 600,
                                                                    letterSpacing: '0.02em'
                                                                }, children: [_jsx("span", { children: "INITIALIZE BLANK" }), _jsx(Plus, { size: 12 })] })] })] })] })] })] }), _jsxs("div", { style: { display: 'flex', flexDirection: 'column', gap: 24 }, children: [_jsxs("div", { style: {
                                    backgroundColor: OsakaJadePalette.background.surface,
                                    border: `1px solid ${OsakaJadePalette.border.glow}`,
                                    borderRadius: 12,
                                    padding: 20,
                                    display: 'flex',
                                    flexDirection: 'column',
                                    boxShadow: '0 8px 24px rgba(0, 0, 0, 0.2)'
                                }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 8 }, children: [_jsx("div", { style: {
                                                            width: 32,
                                                            height: 32,
                                                            borderRadius: 6,
                                                            backgroundColor: `${OsakaJadePalette.jade[500]}1a`,
                                                            display: 'flex',
                                                            alignItems: 'center',
                                                            justifyContent: 'center',
                                                            border: `1px solid ${OsakaJadePalette.jade[500]}44`
                                                        }, children: _jsx(ProcessForgeEmblem, { size: 20 }) }), _jsxs("div", { children: [_jsxs("div", { style: { fontSize: 15, fontWeight: 700, color: OsakaJadePalette.text.primary, display: 'flex', alignItems: 'center', gap: 6 }, children: [_jsx("span", { children: "Plant Orchestrator" }), _jsx("span", { style: {
                                                                            width: 6,
                                                                            height: 6,
                                                                            borderRadius: '50%',
                                                                            backgroundColor: hasKey ? OsakaJadePalette.jade[500] : OsakaJadePalette.status.failed,
                                                                            boxShadow: hasKey ? `0 0 6px ${OsakaJadePalette.jade.glow}` : undefined
                                                                        } })] }), _jsxs("div", { style: { fontSize: 10, color: OsakaJadePalette.text.muted, fontFamily: '"JetBrains Mono", monospace' }, children: ["Plant Orchestrator \u2022 ", hasKey ? creds.provider.toUpperCase() : 'Locked (Add API Key)'] })] })] }), _jsxs("button", { onClick: onOpenAiModal, style: {
                                                    background: 'none',
                                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                                    borderRadius: 4,
                                                    padding: '4px 8px',
                                                    color: OsakaJadePalette.text.secondary,
                                                    fontSize: 11,
                                                    cursor: 'pointer',
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    gap: 4
                                                }, children: [_jsx(Cpu, { size: 12 }), _jsx("span", { children: "Config" })] })] }), !lockStatus.unlocked ? (_jsxs("div", { style: {
                                            backgroundColor: OsakaJadePalette.background.canvas,
                                            border: `1px solid ${OsakaJadePalette.border.default}`,
                                            borderRadius: 8,
                                            padding: '24px 20px',
                                            display: 'flex',
                                            flexDirection: 'column',
                                            alignItems: 'center',
                                            textAlign: 'center',
                                            gap: 12,
                                            marginBottom: 10
                                        }, children: [_jsx("div", { style: {
                                                    width: 42,
                                                    height: 42,
                                                    borderRadius: '50%',
                                                    backgroundColor: 'rgba(239, 68, 68, 0.1)',
                                                    border: '1px solid rgba(239, 68, 68, 0.25)',
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    justifyContent: 'center',
                                                    color: OsakaJadePalette.status.failed
                                                }, children: _jsx(Lock, { size: 20 }) }), _jsxs("div", { children: [_jsx("div", { style: { fontSize: 13, fontWeight: 700, color: OsakaJadePalette.text.primary, marginBottom: 4 }, children: "Plant Orchestrator Locked" }), _jsx("div", { style: { fontSize: 11, color: OsakaJadePalette.text.secondary, maxWidth: 320, lineHeight: 1.5 }, children: "For your security and privacy, agent orchestration is locked until credentials (API key or active local MCP connection) are detected." })] }), _jsxs("button", { onClick: onOpenAiModal, style: {
                                                    marginTop: 4,
                                                    display: 'inline-flex',
                                                    alignItems: 'center',
                                                    gap: 6,
                                                    backgroundColor: OsakaJadePalette.jade[500],
                                                    color: OsakaJadePalette.text.inverse,
                                                    border: 'none',
                                                    borderRadius: 6,
                                                    padding: '8px 14px',
                                                    fontSize: 12,
                                                    fontWeight: 600,
                                                    cursor: 'pointer',
                                                    boxShadow: `0 0 12px ${OsakaJadePalette.jade.glow}`,
                                                    transition: 'all 0.15s ease'
                                                }, children: [_jsx(KeyRound, { size: 13 }), _jsx("span", { children: "Unlock Agent / Add Credentials" })] })] })) : (_jsxs(_Fragment, { children: [_jsxs("div", { style: {
                                                    height: 220,
                                                    overflowY: 'auto',
                                                    backgroundColor: OsakaJadePalette.background.canvas,
                                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                                    borderRadius: 8,
                                                    padding: 12,
                                                    display: 'flex',
                                                    flexDirection: 'column',
                                                    gap: 10,
                                                    marginBottom: 10
                                                }, children: [agentConversation.map((m) => {
                                                        const isUser = m.sender === 'user';
                                                        return (_jsxs("div", { style: {
                                                                alignSelf: isUser ? 'flex-end' : 'flex-start',
                                                                maxWidth: '88%',
                                                                backgroundColor: isUser
                                                                    ? 'rgba(16, 185, 129, 0.15)'
                                                                    : 'rgba(255, 255, 255, 0.03)',
                                                                border: `1px solid ${isUser ? OsakaJadePalette.jade[600] : OsakaJadePalette.border.default}`,
                                                                borderRadius: 8,
                                                                padding: '8px 10px',
                                                                fontSize: 12,
                                                                color: OsakaJadePalette.text.primary,
                                                                lineHeight: 1.45
                                                            }, children: [_jsxs("div", { style: {
                                                                        fontSize: 10,
                                                                        fontWeight: 600,
                                                                        color: isUser ? OsakaJadePalette.text.accent : OsakaJadePalette.text.secondary,
                                                                        marginBottom: 3,
                                                                        display: 'flex',
                                                                        alignItems: 'center',
                                                                        gap: 6
                                                                    }, children: [_jsx("span", { children: m.senderTitle }), m.modelBadge && (_jsx("span", { style: {
                                                                                fontSize: 9,
                                                                                backgroundColor: 'rgba(255,255,255,0.06)',
                                                                                padding: '1px 4px',
                                                                                borderRadius: 3,
                                                                                color: OsakaJadePalette.text.muted
                                                                            }, children: m.modelBadge }))] }), _jsx("div", { style: { whiteSpace: 'pre-wrap' }, children: m.text })] }, m.id));
                                                    }), isAgentThinking && (_jsxs("div", { style: {
                                                            alignSelf: 'flex-start',
                                                            display: 'flex',
                                                            alignItems: 'center',
                                                            gap: 8,
                                                            fontSize: 12,
                                                            color: OsakaJadePalette.text.muted
                                                        }, children: [_jsx(Loader2, { size: 14, className: "animate-spin", color: OsakaJadePalette.jade.glow }), _jsx("span", { children: "Orchestrator reasoning..." })] }))] }), _jsx("div", { style: { display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 10 }, children: [
                                                    'Audit line bottleneck',
                                                    'Design 120 cpm canning line',
                                                    'ASME B16.5 nozzle sizing'
                                                ].map((p, idx) => (_jsx("button", { onClick: () => handleAgentSend(p), disabled: isAgentThinking, style: {
                                                        backgroundColor: 'rgba(255, 255, 255, 0.04)',
                                                        border: `1px solid ${OsakaJadePalette.border.default}`,
                                                        borderRadius: 4,
                                                        padding: '3px 8px',
                                                        color: OsakaJadePalette.text.secondary,
                                                        fontSize: 10,
                                                        cursor: 'pointer'
                                                    }, children: p }, idx))) }), _jsxs("div", { style: { display: 'flex', gap: 6 }, children: [_jsx("input", { type: "text", value: agentInput, onChange: (e) => setAgentInput(e.target.value), onKeyDown: (e) => {
                                                            if (e.key === 'Enter')
                                                                handleAgentSend();
                                                        }, placeholder: "Query plant solver or specify equipment parameters...", style: {
                                                            flex: 1,
                                                            backgroundColor: OsakaJadePalette.background.canvas,
                                                            border: `1px solid ${OsakaJadePalette.border.default}`,
                                                            borderRadius: 6,
                                                            padding: '8px 10px',
                                                            fontSize: 12,
                                                            color: OsakaJadePalette.text.primary,
                                                            outline: 'none'
                                                        } }), _jsx("button", { onClick: () => handleAgentSend(), disabled: !agentInput.trim() || isAgentThinking, style: {
                                                            backgroundColor: agentInput.trim() && !isAgentThinking ? OsakaJadePalette.jade[600] : 'rgba(255,255,255,0.05)',
                                                            border: 'none',
                                                            borderRadius: 6,
                                                            padding: '0 12px',
                                                            color: '#fff',
                                                            cursor: agentInput.trim() && !isAgentThinking ? 'pointer' : 'default',
                                                            display: 'flex',
                                                            alignItems: 'center',
                                                            justifyContent: 'center'
                                                        }, children: _jsx(Send, { size: 14 }) })] })] }))] }), _jsxs("div", { style: {
                                    backgroundColor: OsakaJadePalette.background.surface,
                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                    borderRadius: 12,
                                    padding: 20
                                }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 8 }, children: [_jsx(User, { size: 18, color: OsakaJadePalette.jade[400] }), _jsx("h2", { style: { fontSize: 15, fontWeight: 700, margin: 0, color: OsakaJadePalette.text.primary }, children: "Engineering Account & Sync" })] }), _jsx("span", { style: {
                                                    fontSize: 10,
                                                    fontWeight: 700,
                                                    padding: '2px 8px',
                                                    borderRadius: 12,
                                                    backgroundColor: isAuthenticated ? `${OsakaJadePalette.jade.glow}26` : `${OsakaJadePalette.status.blocked}26`,
                                                    color: isAuthenticated ? OsakaJadePalette.text.accent : OsakaJadePalette.status.blocked
                                                }, children: isAuthenticated ? `${user?.plan || 'Professional'} Plan` : 'Guest Mode' })] }), _jsx("div", { style: { fontSize: 13, color: OsakaJadePalette.text.primary, fontWeight: 600 }, children: isAuthenticated ? user?.name : 'Local Guest Engineer' }), _jsx("div", { style: { fontSize: 11, color: OsakaJadePalette.text.muted, marginTop: 2 }, children: isAuthenticated ? `${user?.email} • ${user?.organization || 'Process Engineering'}` : 'Sign in with Google to sync cloud projects and unlock higher quotas.' }), _jsxs("div", { style: { marginTop: 14 }, children: [_jsxs("div", { style: { display: 'flex', justifyContent: 'space-between', fontSize: 11, color: OsakaJadePalette.text.secondary, marginBottom: 4 }, children: [_jsx("span", { children: "Cloud Simulation Quota" }), _jsxs("span", { children: [cloudProjects.length, " / ", user?.cloudStorageQuota?.maxProjects || 25, " Projects"] })] }), _jsx("div", { style: {
                                                    width: '100%',
                                                    height: 6,
                                                    borderRadius: 3,
                                                    backgroundColor: 'rgba(255, 255, 255, 0.08)',
                                                    overflow: 'hidden'
                                                }, children: _jsx("div", { style: {
                                                        width: `${Math.min(100, ((cloudProjects.length) / (user?.cloudStorageQuota?.maxProjects || 25)) * 100)}%`,
                                                        height: '100%',
                                                        backgroundColor: OsakaJadePalette.jade[500],
                                                        borderRadius: 3
                                                    } }) })] }), _jsxs("button", { onClick: onOpenAccountModal, style: {
                                            width: '100%',
                                            marginTop: 14,
                                            padding: '9px 12px',
                                            borderRadius: 4,
                                            backgroundColor: OsakaJadePalette.background.canvas,
                                            border: `1px solid ${OsakaJadePalette.border.default}`,
                                            color: OsakaJadePalette.text.primary,
                                            fontSize: 11,
                                            fontWeight: 600,
                                            fontFamily: '"JetBrains Mono", monospace',
                                            letterSpacing: '0.02em',
                                            cursor: 'pointer',
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            gap: 6,
                                            transition: 'all 0.12s ease'
                                        }, children: [_jsx("span", { children: isAuthenticated ? 'MANAGE ACCOUNT & QUOTAS' : 'SIGN IN WITH GOOGLE' }), _jsx(ExternalLink, { size: 12 })] })] }), _jsxs("div", { style: {
                                    backgroundColor: OsakaJadePalette.background.surface,
                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                    borderRadius: 12,
                                    padding: 20
                                }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 8 }, children: [_jsx(Cpu, { size: 18, color: OsakaJadePalette.jade[400] }), _jsx("h2", { style: { fontSize: 15, fontWeight: 700, margin: 0, color: OsakaJadePalette.text.primary }, children: "Model Providers & Subscriptions" })] }), _jsx("span", { style: {
                                                    fontSize: 10,
                                                    fontWeight: 700,
                                                    padding: '2px 8px',
                                                    borderRadius: 12,
                                                    backgroundColor: hasKey ? 'rgba(16, 185, 129, 0.15)' : 'rgba(255, 255, 255, 0.06)',
                                                    color: hasKey ? OsakaJadePalette.text.accent : OsakaJadePalette.text.muted
                                                }, children: hasKey ? 'Active Key' : 'No Key Linked' })] }), _jsxs("p", { style: { fontSize: 12, color: OsakaJadePalette.text.secondary, margin: '0 0 14px 0', lineHeight: 1.4 }, children: ["Bring your existing subscription from ", _jsx("strong", { children: "Anthropic Claude" }), ", ", _jsx("strong", { children: "Google Gemini" }), ", ", _jsx("strong", { children: "OpenAI" }), ", or run locally on ", _jsx("strong", { children: "Ollama" }), ". Keys are stored strictly on your local browser."] }), _jsxs("button", { onClick: onOpenAiModal, style: {
                                            width: '100%',
                                            padding: '9px 12px',
                                            borderRadius: 4,
                                            backgroundColor: theme === 'dark' ? 'rgba(45, 213, 183, 0.1)' : 'rgba(35, 148, 104, 0.1)',
                                            border: `1px solid ${OsakaJadePalette.border.glow}`,
                                            color: OsakaJadePalette.text.accent,
                                            fontSize: 11,
                                            fontWeight: 600,
                                            fontFamily: '"JetBrains Mono", monospace',
                                            letterSpacing: '0.02em',
                                            cursor: 'pointer',
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            gap: 6,
                                            transition: 'all 0.12s ease'
                                        }, children: [_jsx(Sliders, { size: 13 }), _jsx("span", { children: "CONFIGURE AI SUBSCRIPTIONS" })] })] })] })] })] }));
};
//# sourceMappingURL=LandingPageHub.js.map