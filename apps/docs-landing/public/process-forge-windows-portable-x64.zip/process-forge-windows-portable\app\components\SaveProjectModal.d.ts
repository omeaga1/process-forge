import React from 'react';
import type { SimulationProject } from '@process-forge/protocol';
interface SaveProjectModalProps {
    isOpen: boolean;
    project: SimulationProject;
    onClose: () => void;
    onSaveLocal: (name: string, description: string) => void;
    onDownloadFile: (name: string, description: string) => void;
    onSaveCloud?: (name: string, description: string) => Promise<void>;
}
export declare const SaveProjectModal: React.FC<SaveProjectModalProps>;
export {};
//# sourceMappingURL=SaveProjectModal.d.ts.map