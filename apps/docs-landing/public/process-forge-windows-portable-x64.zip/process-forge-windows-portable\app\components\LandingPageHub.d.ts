import React from 'react';
import type { SimulationProject } from '@process-forge/protocol';
interface LandingPageHubProps {
    currentProject: SimulationProject;
    onNavigateLanding?: () => void;
    onCreateBlank: () => void;
    onSelectTemplate: (templateKey: string) => void;
    onOpenProject: (project: SimulationProject) => void;
    onImportFile: (file: File) => void;
    onOpenStudio: () => void;
    onOpenForgeHub?: () => void;
    onOpenAiModal: () => void;
    onOpenAccountModal: () => void;
    onOpenCloudProjectsModal: () => void;
}
export declare const LandingPageHub: React.FC<LandingPageHubProps>;
export {};
//# sourceMappingURL=LandingPageHub.d.ts.map