import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import React, { useState, useEffect } from 'react';
import { OsakaJadePalette } from '@process-forge/theme';
import { ReactorAnim, TankAnim, PumpAnim, injectEquipmentCSS } from '@process-forge/canvas-ui';
import { Download, Terminal, ExternalLink, Bot, Copy, Check, X, Boxes, Cpu, ArrowRight, Factory, Package, Activity, CheckCircle2, HardDrive } from 'lucide-react';
// ── Tutorial Step Animations CSS ──────────────────────────────────────────────
const TUTORIAL_CSS = `
  @keyframes pf-fade-up {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
  }
  @keyframes pf-stream-flow {
    0% { stroke-dashoffset: 36; }
    100% { stroke-dashoffset: 0; }
  }
`;
function injectTutorialCSS() {
    if (typeof document === 'undefined')
        return;
    injectEquipmentCSS();
    if (!document.getElementById('pf-tutorial-css')) {
        const s = document.createElement('style');
        s.id = 'pf-tutorial-css';
        s.textContent = TUTORIAL_CSS;
        document.head.appendChild(s);
    }
}
const TUTORIAL_STEPS = [
    {
        step: 1,
        title: '1. Place Equipment & Reactors',
        description: 'Add standard or custom unit operations — from jacketed CSTRs and surge vessels to 3D print farm queues and conveyors. The AI engine synthesizes vector CAD geometry and ASME nozzle schedules to specification.',
        equipment: ['reactor'],
        showStreams: 0
    },
    {
        step: 2,
        title: '2. Add Fluid & Material Transfer',
        description: 'Place transfer pumps or transport lines downstream. Ports, flanges, and connection endpoints snap together to define stream connectivity and mass balance boundaries.',
        equipment: ['reactor', 'pump'],
        showStreams: 1
    },
    {
        step: 3,
        title: '3. Run Dynamic Simulation & Solve Bottlenecks',
        description: 'Connect surge buffers and packaging stations. Run the deterministic hybrid simulation (continuous Runge-Kutta ODEs + discrete Poisson queuing) to expose bottlenecks in real time.',
        equipment: ['reactor', 'pump', 'tank'],
        showStreams: 2
    }
];
export const ProductLandingPage = ({ onLaunchStudio, onOpenPortal: _onOpenPortal, onSelectTemplate: _onSelectTemplate }) => {
    const [platform, setPlatform] = useState({
        name: 'Windows',
        os: 'windows',
        extension: '.exe',
        downloadUrl: '/ProcessForge-Setup-x64.exe',
        fileLabel: 'Windows Installer (64-bit .exe)'
    });
    const [isOtherModalOpen, setIsOtherModalOpen] = useState(false);
    const [copiedSnippet, setCopiedSnippet] = useState(false);
    const [activeTab, setActiveTab] = useState('claude');
    const [tutorialStep, setTutorialStep] = useState(0);
    useEffect(() => {
        injectTutorialCSS();
        const userAgent = window.navigator.userAgent.toLowerCase();
        const platformStr = window.navigator.platform?.toLowerCase() || '';
        if (platformStr.includes('mac') || userAgent.includes('macintosh') || userAgent.includes('mac os x')) {
            setPlatform({
                name: 'macOS',
                os: 'macos',
                extension: '.dmg',
                downloadUrl: 'https://github.com/omeaga1/process-forge/releases/download/v0.1.3/ProcessForge_0.1.3_aarch64.dmg',
                fileLabel: 'macOS Installer (.dmg)'
            });
        }
        else if (platformStr.includes('linux') || userAgent.includes('linux')) {
            setPlatform({
                name: 'Linux',
                os: 'linux',
                extension: '.AppImage',
                downloadUrl: 'https://github.com/omeaga1/process-forge/releases/download/v0.1.3/ProcessForge_0.1.3_amd64.AppImage',
                fileLabel: 'Linux AppImage (.AppImage)'
            });
        }
    }, []);
    // Auto-advance tutorial steps
    useEffect(() => {
        const timer = setInterval(() => {
            setTutorialStep((prev) => (prev + 1) % TUTORIAL_STEPS.length);
        }, 4500);
        return () => clearInterval(timer);
    }, []);
    // Escape key closes platforms modal
    useEffect(() => {
        const handleKeyDown = (e) => {
            if (e.key === 'Escape') {
                setIsOtherModalOpen(false);
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, []);
    const claudeConfigSnippet = `{
  "mcpServers": {
    "process-forge": {
      "command": "npx",
      "args": ["-y", "@process-forge/mcp-server"]
    }
  }
}`;
    const geminiConfigSnippet = `# Add ProcessForge to Gemini CLI or local agent stdio:
gemini mcp add process-forge -- npx -y @process-forge/mcp-server`;
    const copyToClipboard = (text) => {
        navigator.clipboard.writeText(text);
        setCopiedSnippet(true);
        setTimeout(() => setCopiedSnippet(false), 2000);
    };
    const currentTutorial = TUTORIAL_STEPS[tutorialStep];
    return (_jsxs("div", { style: {
            minHeight: '100vh',
            backgroundColor: OsakaJadePalette.background.base,
            color: OsakaJadePalette.text.primary,
            fontFamily: "'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif",
            display: 'flex',
            flexDirection: 'column'
        }, children: [_jsxs("header", { style: {
                    borderBottom: `1px solid ${OsakaJadePalette.border.subtle}`,
                    backgroundColor: `${OsakaJadePalette.background.surface}cc`,
                    backdropFilter: 'blur(14px)',
                    position: 'sticky',
                    top: 0,
                    zIndex: 50,
                    padding: '14px 32px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between'
                }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: '12px' }, children: [_jsx("div", { style: {
                                    width: '32px',
                                    height: '32px',
                                    borderRadius: '8px',
                                    background: `linear-gradient(135deg, ${OsakaJadePalette.jade[400]}, ${OsakaJadePalette.jade[600]})`,
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    boxShadow: `0 0 16px ${OsakaJadePalette.jade.glow}44`
                                }, children: _jsx(Boxes, { size: 18, color: "#0c1214" }) }), _jsxs("div", { children: [_jsxs("span", { style: { fontWeight: 800, fontSize: '1.15rem', letterSpacing: '-0.02em', color: OsakaJadePalette.text.primary }, children: ["PROCESS", _jsx("span", { style: { color: OsakaJadePalette.jade[400] }, children: "FORGE" })] }), _jsx("span", { style: {
                                            marginLeft: '8px',
                                            fontSize: '0.68rem',
                                            fontWeight: 700,
                                            padding: '2px 7px',
                                            borderRadius: '4px',
                                            backgroundColor: `${OsakaJadePalette.jade.muted}`,
                                            color: OsakaJadePalette.jade[300],
                                            border: `1px solid ${OsakaJadePalette.jade[700]}`
                                        }, children: "v0.1.3" })] })] }), _jsxs("nav", { style: { display: 'flex', alignItems: 'center', gap: '24px' }, children: [_jsx("a", { href: "#solutions", style: { color: OsakaJadePalette.text.secondary, textDecoration: 'none', fontSize: '0.88rem', fontWeight: 500 }, children: "Solutions" }), _jsx("a", { href: "#modeling", style: { color: OsakaJadePalette.text.secondary, textDecoration: 'none', fontSize: '0.88rem', fontWeight: 500 }, children: "Physics Engine" }), _jsx("a", { href: "#tutorial", style: { color: OsakaJadePalette.text.secondary, textDecoration: 'none', fontSize: '0.88rem', fontWeight: 500 }, children: "How It Works" }), _jsx("a", { href: "#automation", style: { color: OsakaJadePalette.text.secondary, textDecoration: 'none', fontSize: '0.88rem', fontWeight: 500 }, children: "MCP Automation" }), _jsxs("a", { href: "https://github.com/omeaga1/process-forge", target: "_blank", rel: "noreferrer", style: {
                                    color: OsakaJadePalette.text.secondary,
                                    textDecoration: 'none',
                                    fontSize: '0.88rem',
                                    fontWeight: 500,
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '4px'
                                }, children: ["GitHub ", _jsx(ExternalLink, { size: 13 })] }), _jsxs("button", { onClick: onLaunchStudio, style: {
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: '6px',
                                    padding: '8px 16px',
                                    borderRadius: '6px',
                                    backgroundColor: 'rgba(16, 185, 129, 0.12)',
                                    border: `1px solid ${OsakaJadePalette.jade[600]}`,
                                    color: OsakaJadePalette.jade[300],
                                    fontSize: '0.84rem',
                                    fontWeight: 600,
                                    cursor: 'pointer',
                                    transition: 'all 0.12s ease'
                                }, title: "Launch Web Studio directly in browser", children: [_jsx("span", { children: "Launch Web Studio" }), _jsx(ArrowRight, { size: 13, color: OsakaJadePalette.jade[400] })] })] })] }), _jsxs("section", { style: {
                    position: 'relative',
                    padding: '80px 24px 70px',
                    textAlign: 'center',
                    maxWidth: '960px',
                    margin: '0 auto',
                    width: '100%'
                }, children: [_jsx("div", { style: {
                            position: 'absolute',
                            top: '20px',
                            left: '50%',
                            transform: 'translateX(-50%)',
                            width: '600px',
                            height: '240px',
                            background: `radial-gradient(ellipse at center, ${OsakaJadePalette.jade[500]}1a 0%, transparent 70%)`,
                            pointerEvents: 'none',
                            zIndex: 0
                        } }), _jsxs("div", { style: { position: 'relative', zIndex: 1 }, children: [_jsxs("div", { style: {
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: '8px',
                                    padding: '5px 14px',
                                    borderRadius: '20px',
                                    backgroundColor: OsakaJadePalette.background.surfaceElevated,
                                    border: `1px solid ${OsakaJadePalette.border.strong}`,
                                    color: OsakaJadePalette.jade[300],
                                    fontSize: '0.78rem',
                                    fontWeight: 600,
                                    marginBottom: '22px'
                                }, children: [_jsx(Boxes, { size: 13, color: OsakaJadePalette.jade[400] }), _jsx("span", { children: "Native Desktop Process Engineering Studio \u2022 Windows, macOS & Linux" })] }), _jsxs("h1", { style: {
                                    fontSize: 'clamp(2.4rem, 5vw, 3.8rem)',
                                    fontWeight: 800,
                                    letterSpacing: '-0.03em',
                                    lineHeight: 1.15,
                                    marginBottom: '20px'
                                }, children: ["Model Any Process \u2014 From", ' ', _jsx("span", { style: {
                                            background: `linear-gradient(135deg, ${OsakaJadePalette.jade[300]} 0%, ${OsakaJadePalette.jade[500]} 100%)`,
                                            WebkitBackgroundClip: 'text',
                                            WebkitTextFillColor: 'transparent'
                                        }, children: "Chemical Plants" }), ' ', "to", ' ', _jsx("span", { style: {
                                            background: `linear-gradient(135deg, ${OsakaJadePalette.jade[300]} 0%, ${OsakaJadePalette.jade[500]} 100%)`,
                                            WebkitBackgroundClip: 'text',
                                            WebkitTextFillColor: 'transparent'
                                        }, children: "3D Print Farms" })] }), _jsx("p", { style: {
                                    fontSize: '1.12rem',
                                    color: OsakaJadePalette.text.secondary,
                                    lineHeight: 1.6,
                                    maxWidth: '720px',
                                    margin: '0 auto 36px'
                                }, children: "ProcessForge is an engineering desktop application for modeling, simulating, and optimizing complex operations. Combines continuous Runge-Kutta ODEs with discrete Poisson queuing, backed by an AI co-pilot for equipment and nozzle synthesis." }), _jsxs("div", { style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    gap: '14px',
                                    marginBottom: '22px',
                                    flexWrap: 'wrap'
                                }, children: [_jsxs("a", { href: platform.downloadUrl, download: platform.os === 'windows' ? 'ProcessForge-Setup-x64.exe' : undefined, style: {
                                            display: 'inline-flex',
                                            alignItems: 'center',
                                            gap: '10px',
                                            padding: '13px 26px',
                                            borderRadius: '8px',
                                            background: `linear-gradient(135deg, ${OsakaJadePalette.jade[500]}, ${OsakaJadePalette.jade[600]})`,
                                            color: OsakaJadePalette.text.inverse,
                                            textDecoration: 'none',
                                            fontWeight: 700,
                                            fontSize: '0.98rem',
                                            boxShadow: `0 4px 20px ${OsakaJadePalette.jade[500]}55`,
                                            cursor: 'pointer',
                                            transition: 'all 0.12s ease'
                                        }, title: `Download ProcessForge for ${platform.name}`, children: [_jsx(Download, { size: 18, strokeWidth: 2.4 }), _jsxs("span", { children: ["Download for ", platform.name, " (", platform.extension, ")"] })] }), _jsxs("button", { onClick: onLaunchStudio, style: {
                                            display: 'inline-flex',
                                            alignItems: 'center',
                                            gap: '10px',
                                            padding: '13px 24px',
                                            borderRadius: '8px',
                                            backgroundColor: OsakaJadePalette.background.surfaceElevated,
                                            border: `1px solid ${OsakaJadePalette.border.strong}`,
                                            color: OsakaJadePalette.text.primary,
                                            fontWeight: 600,
                                            fontSize: '0.98rem',
                                            cursor: 'pointer',
                                            boxShadow: '0 2px 8px rgba(0,0,0,0.2)',
                                            transition: 'all 0.12s ease'
                                        }, children: [_jsx("span", { children: "Launch Web Studio (In-Browser)" }), _jsx(ArrowRight, { size: 16, color: OsakaJadePalette.jade[400] })] })] }), _jsxs("div", { style: { display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', fontSize: '0.84rem', color: OsakaJadePalette.text.secondary }, children: [_jsx("span", { children: "Available for Windows, macOS & Linux \u2022" }), _jsx("button", { onClick: () => setIsOtherModalOpen(true), style: {
                                            background: 'none',
                                            border: 'none',
                                            color: OsakaJadePalette.jade[400],
                                            fontWeight: 600,
                                            cursor: 'pointer',
                                            padding: 0,
                                            textDecoration: 'underline'
                                        }, children: "All platforms & formats \u2192" })] }), _jsxs("div", { style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    gap: '24px',
                                    marginTop: '28px',
                                    flexWrap: 'wrap',
                                    fontSize: '0.78rem',
                                    color: OsakaJadePalette.text.muted
                                }, children: [_jsxs("span", { style: { display: 'flex', alignItems: 'center', gap: '6px' }, children: [_jsx(CheckCircle2, { size: 13, color: OsakaJadePalette.jade[400] }), "100% Offline & Local Execution"] }), _jsxs("span", { style: { display: 'flex', alignItems: 'center', gap: '6px' }, children: [_jsx(CheckCircle2, { size: 13, color: OsakaJadePalette.jade[400] }), "Deterministic ODE + Discrete Physics"] }), _jsxs("span", { style: { display: 'flex', alignItems: 'center', gap: '6px' }, children: [_jsx(CheckCircle2, { size: 13, color: OsakaJadePalette.jade[400] }), "Native Rust & Tauri v2 Architecture"] }), _jsxs("span", { style: { display: 'flex', alignItems: 'center', gap: '6px' }, children: [_jsx(CheckCircle2, { size: 13, color: OsakaJadePalette.jade[400] }), "Open Source (Apache-2.0)"] })] })] })] }), _jsxs("section", { id: "tutorial", style: {
                    padding: '60px 24px 80px',
                    maxWidth: '1020px',
                    margin: '0 auto',
                    width: '100%'
                }, children: [_jsxs("div", { style: { textAlign: 'center', marginBottom: '36px' }, children: [_jsx("h2", { style: { fontSize: '2rem', fontWeight: 800, letterSpacing: '-0.02em', marginBottom: '10px' }, children: "Build a Process Flowsheet in Minutes" }), _jsx("p", { style: { color: OsakaJadePalette.text.secondary, fontSize: '0.98rem', maxWidth: '580px', margin: '0 auto' }, children: "The AI engine synthesizes unit operations and vector CAD dressing. You place equipment, connect streams, and simulate dynamics." })] }), _jsx("div", { style: { display: 'flex', justifyContent: 'center', gap: '8px', marginBottom: '28px' }, children: TUTORIAL_STEPS.map((s, i) => (_jsx("button", { onClick: () => setTutorialStep(i), style: {
                                width: i === tutorialStep ? '32px' : '10px',
                                height: '8px',
                                borderRadius: '4px',
                                border: 'none',
                                backgroundColor: i === tutorialStep ? OsakaJadePalette.jade[400] : OsakaJadePalette.border.default,
                                cursor: 'pointer',
                                transition: 'all 0.25s ease'
                            }, title: `Step ${s.step}` }, s.step))) }), _jsxs("div", { style: {
                            borderRadius: '12px',
                            border: `1px solid ${OsakaJadePalette.border.default}`,
                            backgroundColor: OsakaJadePalette.background.canvas,
                            overflow: 'hidden',
                            boxShadow: `0 24px 48px rgba(0,0,0,0.45), 0 0 24px ${OsakaJadePalette.jade.glow}10`
                        }, children: [_jsxs("div", { style: {
                                    padding: '10px 20px',
                                    backgroundColor: OsakaJadePalette.background.surface,
                                    borderBottom: `1px solid ${OsakaJadePalette.border.subtle}`,
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'space-between'
                                }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: '10px' }, children: [_jsxs("div", { style: { display: 'flex', gap: '6px' }, children: [_jsx("div", { style: { width: '10px', height: '10px', borderRadius: '50%', backgroundColor: '#f43f5e' } }), _jsx("div", { style: { width: '10px', height: '10px', borderRadius: '50%', backgroundColor: '#f59e0b' } }), _jsx("div", { style: { width: '10px', height: '10px', borderRadius: '50%', backgroundColor: '#10b981' } })] }), _jsx("span", { style: { fontSize: '0.82rem', color: OsakaJadePalette.text.primary, fontWeight: 700 }, children: "ProcessForge Industrial Flowsheet Viewport" })] }), _jsxs("span", { style: { fontSize: '0.72rem', color: OsakaJadePalette.text.muted }, children: ["Step ", currentTutorial.step, " of ", TUTORIAL_STEPS.length] })] }), _jsxs("div", { style: {
                                    padding: '40px 24px',
                                    minHeight: '270px',
                                    position: 'relative'
                                }, children: [_jsx("div", { style: {
                                            position: 'absolute',
                                            inset: 0,
                                            backgroundImage: `radial-gradient(${OsakaJadePalette.border.default} 1px, transparent 1px)`,
                                            backgroundSize: '24px 24px',
                                            opacity: 0.35,
                                            pointerEvents: 'none'
                                        } }), _jsx("div", { style: {
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            gap: '12px',
                                            position: 'relative',
                                            zIndex: 1,
                                            overflowX: 'auto',
                                            maxWidth: '100%',
                                            paddingBottom: '8px'
                                        }, children: currentTutorial.equipment.map((eq, i) => (_jsxs(React.Fragment, { children: [_jsxs("div", { style: {
                                                        width: '160px',
                                                        backgroundColor: OsakaJadePalette.background.surface,
                                                        border: i === currentTutorial.equipment.length - 1
                                                            ? `2px solid ${OsakaJadePalette.jade[400]}`
                                                            : `1px solid ${OsakaJadePalette.border.default}`,
                                                        borderRadius: '10px',
                                                        padding: '14px',
                                                        textAlign: 'center',
                                                        animation: i === currentTutorial.equipment.length - 1 ? 'pf-fade-up 0.4s ease-out' : 'none',
                                                        boxShadow: i === currentTutorial.equipment.length - 1
                                                            ? `0 0 20px ${OsakaJadePalette.jade.glow}33`
                                                            : 'none'
                                                    }, children: [_jsx("div", { style: { fontSize: '0.65rem', fontWeight: 700, color: OsakaJadePalette.jade[400], marginBottom: '6px' }, children: eq === 'reactor' ? 'CSTR-101' : eq === 'pump' ? 'P-101' : 'TK-102' }), _jsxs("div", { style: { height: '90px', display: 'flex', alignItems: 'center', justifyContent: 'center' }, children: [eq === 'reactor' && _jsx(ReactorAnim, { isRunning: true, hasJacket: true, agitatorType: "rushton" }), eq === 'pump' && _jsx(PumpAnim, { isRunning: true }), eq === 'tank' && _jsx(TankAnim, { isRunning: true, levelPercent: 74 })] }), _jsx("div", { style: { fontWeight: 700, fontSize: '0.8rem', marginTop: '6px' }, children: eq === 'reactor' ? 'CSTR Reactor' : eq === 'pump' ? 'Transfer Pump' : 'Surge Tank' })] }), i < currentTutorial.equipment.length - 1 && i < currentTutorial.showStreams && (_jsxs("div", { style: { width: '48px', flexShrink: 0, display: 'flex', flexDirection: 'column', alignItems: 'center' }, children: [_jsxs("svg", { width: "48", height: "24", viewBox: "0 0 48 24", children: [_jsx("line", { x1: "0", y1: "12", x2: "40", y2: "12", stroke: OsakaJadePalette.jade[400], strokeWidth: "2", strokeDasharray: "6 3", style: { animation: 'pf-stream-flow 1.5s linear infinite' } }), _jsx("polygon", { points: "40,8 48,12 40,16", fill: OsakaJadePalette.jade[400] })] }), _jsx("span", { style: { fontSize: '0.6rem', color: OsakaJadePalette.text.muted, marginTop: '2px' }, children: "Stream" })] })), i < currentTutorial.equipment.length - 1 && i >= currentTutorial.showStreams && (_jsx("div", { style: { width: '48px', flexShrink: 0 } }))] }, eq))) })] }), _jsxs("div", { style: {
                                    padding: '16px 24px',
                                    backgroundColor: OsakaJadePalette.background.surface,
                                    borderTop: `1px solid ${OsakaJadePalette.border.subtle}`,
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '16px'
                                }, children: [_jsx("div", { style: {
                                            width: '36px',
                                            height: '36px',
                                            borderRadius: '8px',
                                            backgroundColor: OsakaJadePalette.jade.muted,
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            color: OsakaJadePalette.jade[300],
                                            fontWeight: 800,
                                            fontSize: '0.9rem',
                                            flexShrink: 0
                                        }, children: currentTutorial.step }), _jsxs("div", { children: [_jsx("div", { style: { fontWeight: 700, fontSize: '0.95rem', marginBottom: '2px' }, children: currentTutorial.title }), _jsx("div", { style: { fontSize: '0.84rem', color: OsakaJadePalette.text.secondary, lineHeight: 1.5 }, children: currentTutorial.description })] })] })] })] }), _jsx("section", { id: "solutions", style: {
                    padding: '70px 24px',
                    backgroundColor: OsakaJadePalette.background.surface,
                    borderTop: `1px solid ${OsakaJadePalette.border.subtle}`,
                    borderBottom: `1px solid ${OsakaJadePalette.border.subtle}`
                }, children: _jsxs("div", { style: { maxWidth: '1100px', margin: '0 auto', width: '100%' }, children: [_jsxs("div", { style: { textAlign: 'center', marginBottom: '48px' }, children: [_jsx("h2", { style: { fontSize: '2rem', fontWeight: 800, letterSpacing: '-0.02em', marginBottom: '10px' }, children: "Engineered for Diverse Process Domains" }), _jsx("p", { style: { color: OsakaJadePalette.text.secondary, fontSize: '0.98rem', maxWidth: '600px', margin: '0 auto' }, children: "Whether you are balancing fluid kinetics in a chemical plant or analyzing cycle times in a 3D printing farm, ProcessForge models your physics accurately." })] }), _jsxs("div", { style: {
                                display: 'grid',
                                gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
                                gap: '24px'
                            }, children: [_jsxs("div", { style: {
                                        padding: '28px',
                                        borderRadius: '10px',
                                        backgroundColor: OsakaJadePalette.background.canvas,
                                        border: `1px solid ${OsakaJadePalette.border.default}`,
                                        display: 'flex',
                                        flexDirection: 'column',
                                        gap: '12px'
                                    }, children: [_jsx("div", { style: {
                                                width: '44px',
                                                height: '44px',
                                                borderRadius: '8px',
                                                backgroundColor: 'rgba(16, 185, 129, 0.12)',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                color: OsakaJadePalette.jade[400]
                                            }, children: _jsx(Activity, { size: 22 }) }), _jsx("h3", { style: { fontSize: '1.15rem', fontWeight: 700, margin: 0 }, children: "Chemical & Continuous Plants" }), _jsx("p", { style: { color: OsakaJadePalette.text.secondary, fontSize: '0.88rem', lineHeight: 1.6, margin: 0 }, children: "Model continuous and batch reactions, multi-stage distillation, fluid hydraulics, and heat exchange networks." }), _jsxs("ul", { style: { margin: 0, paddingLeft: '18px', fontSize: '0.82rem', color: OsakaJadePalette.text.muted, lineHeight: 1.8 }, children: [_jsx("li", { children: "Runge-Kutta ODE solvers for continuous kinetics" }), _jsx("li", { children: "Pumping head curves, TDH & viscosity penalties" }), _jsx("li", { children: "ASME B16.5 flange & nozzle schedule verification" })] })] }), _jsxs("div", { style: {
                                        padding: '28px',
                                        borderRadius: '10px',
                                        backgroundColor: OsakaJadePalette.background.canvas,
                                        border: `1px solid ${OsakaJadePalette.border.default}`,
                                        display: 'flex',
                                        flexDirection: 'column',
                                        gap: '12px'
                                    }, children: [_jsx("div", { style: {
                                                width: '44px',
                                                height: '44px',
                                                borderRadius: '8px',
                                                backgroundColor: 'rgba(16, 185, 129, 0.12)',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                color: OsakaJadePalette.jade[400]
                                            }, children: _jsx(Factory, { size: 22 }) }), _jsx("h3", { style: { fontSize: '1.15rem', fontWeight: 700, margin: 0 }, children: "Discrete Manufacturing & 3D Print Farms" }), _jsx("p", { style: { color: OsakaJadePalette.text.secondary, fontSize: '0.88rem', lineHeight: 1.6, margin: 0 }, children: "Balance multi-machine 3D printer fleets, CNC machining cells, and automated robotic assembly lines." }), _jsxs("ul", { style: { margin: 0, paddingLeft: '18px', fontSize: '0.82rem', color: OsakaJadePalette.text.muted, lineHeight: 1.8 }, children: [_jsx("li", { children: "Poisson discrete-event queue & cycle time modeling" }), _jsx("li", { children: "Machine utilization & post-processing buffer depths" }), _jsx("li", { children: "Starvation and line-blocking bottleneck identification" })] })] }), _jsxs("div", { style: {
                                        padding: '28px',
                                        borderRadius: '10px',
                                        backgroundColor: OsakaJadePalette.background.canvas,
                                        border: `1px solid ${OsakaJadePalette.border.default}`,
                                        display: 'flex',
                                        flexDirection: 'column',
                                        gap: '12px'
                                    }, children: [_jsx("div", { style: {
                                                width: '44px',
                                                height: '44px',
                                                borderRadius: '8px',
                                                backgroundColor: 'rgba(16, 185, 129, 0.12)',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                color: OsakaJadePalette.jade[400]
                                            }, children: _jsx(Package, { size: 22 }) }), _jsx("h3", { style: { fontSize: '1.15rem', fontWeight: 700, margin: 0 }, children: "Warehousing & Packaging Logistics" }), _jsx("p", { style: { color: OsakaJadePalette.text.secondary, fontSize: '0.88rem', lineHeight: 1.6, margin: 0 }, children: "Optimize container throughput, sortation lines, accumulation conveyors, and end-of-line palletizing cells." }), _jsxs("ul", { style: { margin: 0, paddingLeft: '18px', fontSize: '0.82rem', color: OsakaJadePalette.text.muted, lineHeight: 1.8 }, children: [_jsx("li", { children: "Real-time pieces-per-minute (CPM) rate telemetry" }), _jsx("li", { children: "Accumulation conveyor buffering & indexing" }), _jsx("li", { children: "Packaging line phase transitions (fluid $\\rightarrow$ discrete containers)" })] })] })] })] }) }), _jsxs("section", { id: "modeling", style: {
                    padding: '70px 24px',
                    maxWidth: '1100px',
                    margin: '0 auto',
                    width: '100%'
                }, children: [_jsxs("div", { style: { textAlign: 'center', marginBottom: '48px' }, children: [_jsx("h2", { style: { fontSize: '2rem', fontWeight: 800, letterSpacing: '-0.02em', marginBottom: '10px' }, children: "Built on Rigorous Engineering Foundations" }), _jsx("p", { style: { color: OsakaJadePalette.text.secondary, fontSize: '0.98rem', maxWidth: '580px', margin: '0 auto' }, children: "A unified simulation kernel with zero cloud latency and total intellectual property privacy." })] }), _jsxs("div", { style: {
                            display: 'grid',
                            gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
                            gap: '20px'
                        }, children: [_jsxs("div", { style: {
                                    padding: '28px',
                                    borderRadius: '10px',
                                    backgroundColor: OsakaJadePalette.background.surface,
                                    border: `1px solid ${OsakaJadePalette.border.default}`
                                }, children: [_jsx("div", { style: {
                                            width: '44px',
                                            height: '44px',
                                            borderRadius: '8px',
                                            backgroundColor: OsakaJadePalette.background.surfaceElevated,
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            marginBottom: '16px',
                                            color: OsakaJadePalette.jade[400]
                                        }, children: _jsx(Cpu, { size: 22 }) }), _jsx("h3", { style: { fontSize: '1.1rem', fontWeight: 700, marginBottom: '8px' }, children: "Dual Continuous & Discrete Solver" }), _jsx("p", { style: { color: OsakaJadePalette.text.secondary, fontSize: '0.88rem', lineHeight: 1.6, margin: 0 }, children: "Continuous Runge-Kutta numerical integration for reaction kinetics and fluid rheology runs synchronized on the exact same master clock as discrete event queues and conveyor transfers." })] }), _jsxs("div", { style: {
                                    padding: '28px',
                                    borderRadius: '10px',
                                    backgroundColor: OsakaJadePalette.background.surface,
                                    border: `1px solid ${OsakaJadePalette.border.default}`
                                }, children: [_jsx("div", { style: {
                                            width: '44px',
                                            height: '44px',
                                            borderRadius: '8px',
                                            backgroundColor: OsakaJadePalette.background.surfaceElevated,
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            marginBottom: '16px',
                                            color: OsakaJadePalette.jade[400]
                                        }, children: _jsx(Bot, { size: 22 }) }), _jsx("h3", { style: { fontSize: '1.1rem', fontWeight: 700, marginBottom: '8px' }, children: "AI Equipment & CAD Synthesis" }), _jsx("p", { style: { color: OsakaJadePalette.text.secondary, fontSize: '0.88rem', lineHeight: 1.6, margin: 0 }, children: "Describe equipment geometry, process constraints, or nozzle ratings in plain language. The built-in AI co-pilot creates validated JSON node definitions, vector CAD drawings, and ASME nozzle schedules." })] }), _jsxs("div", { style: {
                                    padding: '28px',
                                    borderRadius: '10px',
                                    backgroundColor: OsakaJadePalette.background.surface,
                                    border: `1px solid ${OsakaJadePalette.border.default}`
                                }, children: [_jsx("div", { style: {
                                            width: '44px',
                                            height: '44px',
                                            borderRadius: '8px',
                                            backgroundColor: OsakaJadePalette.background.surfaceElevated,
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            marginBottom: '16px',
                                            color: OsakaJadePalette.jade[400]
                                        }, children: _jsx(HardDrive, { size: 22 }) }), _jsx("h3", { style: { fontSize: '1.1rem', fontWeight: 700, marginBottom: '8px' }, children: "100% Offline & Data Privacy" }), _jsx("p", { style: { color: OsakaJadePalette.text.secondary, fontSize: '0.88rem', lineHeight: 1.6, margin: 0 }, children: "The native desktop application runs completely self-contained. All simulation math, flowsheet topology, and proprietary facility data remain securely on your local workstation." })] })] })] }), _jsx("section", { id: "automation", style: {
                    padding: '60px 24px',
                    backgroundColor: OsakaJadePalette.background.surface,
                    borderTop: `1px solid ${OsakaJadePalette.border.subtle}`,
                    borderBottom: `1px solid ${OsakaJadePalette.border.subtle}`
                }, children: _jsxs("div", { style: { maxWidth: '740px', margin: '0 auto', textAlign: 'center' }, children: [_jsxs("div", { style: {
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: '6px',
                                padding: '4px 12px',
                                borderRadius: '16px',
                                backgroundColor: OsakaJadePalette.background.surfaceElevated,
                                color: OsakaJadePalette.jade[400],
                                fontSize: '0.78rem',
                                fontWeight: 600,
                                marginBottom: '16px'
                            }, children: [_jsx(Terminal, { size: 14 }), " Model Context Protocol (MCP) Standard"] }), _jsx("h2", { style: { fontSize: '1.8rem', fontWeight: 800, marginBottom: '12px' }, children: "Automate & Script with External AI Assistants" }), _jsx("p", { style: { color: OsakaJadePalette.text.secondary, fontSize: '0.94rem', marginBottom: '28px', maxWidth: '580px', margin: '0 auto 28px' }, children: "Connect Claude Desktop, Gemini CLI, or custom Python scripts via the MCP standard to programmatically synthesize unit operations, run sweeps, and analyze bottlenecks." }), _jsxs("div", { style: {
                                borderRadius: '8px',
                                backgroundColor: OsakaJadePalette.background.canvas,
                                border: `1px solid ${OsakaJadePalette.border.default}`,
                                overflow: 'hidden',
                                textAlign: 'left'
                            }, children: [_jsxs("div", { style: {
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'space-between',
                                        padding: '10px 16px',
                                        backgroundColor: OsakaJadePalette.background.surfaceElevated,
                                        borderBottom: `1px solid ${OsakaJadePalette.border.subtle}`
                                    }, children: [_jsxs("div", { style: { display: 'flex', gap: '8px' }, children: [_jsx("button", { onClick: () => setActiveTab('claude'), style: {
                                                        padding: '6px 12px',
                                                        borderRadius: '4px',
                                                        border: 'none',
                                                        backgroundColor: activeTab === 'claude' ? OsakaJadePalette.background.surfaceHover : 'transparent',
                                                        color: activeTab === 'claude' ? OsakaJadePalette.jade[400] : OsakaJadePalette.text.muted,
                                                        fontSize: '0.8rem',
                                                        fontWeight: 600,
                                                        cursor: 'pointer'
                                                    }, children: "Claude Desktop" }), _jsx("button", { onClick: () => setActiveTab('gemini'), style: {
                                                        padding: '6px 12px',
                                                        borderRadius: '4px',
                                                        border: 'none',
                                                        backgroundColor: activeTab === 'gemini' ? OsakaJadePalette.background.surfaceHover : 'transparent',
                                                        color: activeTab === 'gemini' ? OsakaJadePalette.jade[400] : OsakaJadePalette.text.muted,
                                                        fontSize: '0.8rem',
                                                        fontWeight: 600,
                                                        cursor: 'pointer'
                                                    }, children: "Gemini CLI" })] }), _jsxs("button", { onClick: () => copyToClipboard(activeTab === 'claude' ? claudeConfigSnippet : geminiConfigSnippet), style: {
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: '6px',
                                                padding: '4px 10px',
                                                borderRadius: '4px',
                                                backgroundColor: OsakaJadePalette.background.surface,
                                                border: `1px solid ${OsakaJadePalette.border.default}`,
                                                color: OsakaJadePalette.text.secondary,
                                                fontSize: '0.75rem',
                                                cursor: 'pointer'
                                            }, children: [copiedSnippet ? _jsx(Check, { size: 13, color: OsakaJadePalette.jade[400] }) : _jsx(Copy, { size: 13 }), copiedSnippet ? 'Copied!' : 'Copy'] })] }), _jsx("pre", { style: {
                                        margin: 0,
                                        padding: '18px',
                                        fontSize: '0.85rem',
                                        color: OsakaJadePalette.jade[300],
                                        overflowX: 'auto',
                                        lineHeight: 1.5
                                    }, children: _jsx("code", { children: activeTab === 'claude' ? claudeConfigSnippet : geminiConfigSnippet }) })] })] }) }), _jsx("footer", { style: {
                    marginTop: 'auto',
                    borderTop: `1px solid ${OsakaJadePalette.border.subtle}`,
                    padding: '36px 24px',
                    backgroundColor: OsakaJadePalette.background.base,
                    textAlign: 'center'
                }, children: _jsxs("div", { style: {
                        maxWidth: '960px',
                        margin: '0 auto',
                        display: 'flex',
                        flexWrap: 'wrap',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        gap: '20px'
                    }, children: [_jsxs("div", { style: { textAlign: 'left' }, children: [_jsxs("div", { style: { fontWeight: 800, fontSize: '1.05rem', color: OsakaJadePalette.text.primary, marginBottom: '4px' }, children: ["PROCESS", _jsx("span", { style: { color: OsakaJadePalette.jade[400] }, children: "FORGE" })] }), _jsx("div", { style: { fontSize: '0.8rem', color: OsakaJadePalette.text.muted }, children: "Native desktop simulation studio for continuous and discrete industrial processes." })] }), _jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: '20px', fontSize: '0.85rem' }, children: [_jsx("a", { href: "https://github.com/omeaga1/process-forge", target: "_blank", rel: "noreferrer", style: { color: OsakaJadePalette.text.secondary, textDecoration: 'none' }, children: "GitHub" }), _jsx("a", { href: "https://github.com/omeaga1/process-forge/releases/tag/v0.1.3", target: "_blank", rel: "noreferrer", style: { color: OsakaJadePalette.text.secondary, textDecoration: 'none' }, children: "Releases (v0.1.3)" }), _jsx("a", { href: "https://github.com/omeaga1/process-forge/blob/main/LICENSE", target: "_blank", rel: "noreferrer", style: { color: OsakaJadePalette.text.secondary, textDecoration: 'none' }, children: "Apache-2.0" })] })] }) }), isOtherModalOpen && (_jsx("div", { style: {
                    position: 'fixed',
                    inset: 0,
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    backdropFilter: 'blur(8px)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    zIndex: 100,
                    padding: '20px'
                }, onClick: () => setIsOtherModalOpen(false), children: _jsxs("div", { style: {
                        backgroundColor: OsakaJadePalette.background.surface,
                        border: `1px solid ${OsakaJadePalette.border.default}`,
                        borderRadius: '12px',
                        padding: '24px',
                        maxWidth: '540px',
                        width: '100%',
                        boxShadow: '0 20px 40px rgba(0,0,0,0.6)'
                    }, onClick: (e) => e.stopPropagation(), children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '18px' }, children: [_jsxs("div", { children: [_jsxs("h3", { style: { margin: 0, fontSize: '1.15rem', fontWeight: 800, color: OsakaJadePalette.text.primary, display: 'flex', alignItems: 'center', gap: '8px' }, children: [_jsx(Download, { size: 18, color: OsakaJadePalette.jade[400] }), " ProcessForge Desktop Downloads"] }), _jsx("span", { style: { fontSize: '0.78rem', color: OsakaJadePalette.text.muted }, children: "Official Release v0.1.3 \u2022 Native 64-bit binaries" })] }), _jsx("button", { onClick: () => setIsOtherModalOpen(false), style: { background: 'none', border: 'none', color: OsakaJadePalette.text.muted, cursor: 'pointer', padding: '4px' }, children: _jsx(X, { size: 18 }) })] }), _jsx("div", { style: { display: 'flex', flexDirection: 'column', gap: '10px' }, children: [
                                {
                                    label: 'Windows Setup Installer (.exe)',
                                    url: '/ProcessForge-Setup-x64.exe',
                                    download: 'ProcessForge-Setup-x64.exe',
                                    tag: 'Recommended (Windows)',
                                    sub: 'Native NSIS 64-bit installer with automatic updates'
                                },
                                {
                                    label: 'Windows MSI Enterprise Package (.msi)',
                                    url: 'https://github.com/omeaga1/process-forge/releases/download/v0.1.3/ProcessForge_0.1.3_x64_en-US.msi',
                                    download: 'ProcessForge_0.1.3_x64_en-US.msi',
                                    tag: 'Enterprise MSI',
                                    sub: 'Standard Windows Installer package for managed deployments'
                                },
                                {
                                    label: 'Windows Portable Bundle (.zip)',
                                    url: '/process-forge-windows-portable-x64.zip',
                                    download: 'process-forge-windows-portable-x64.zip',
                                    tag: 'Zero Install',
                                    sub: 'Standalone executable archive — runs without administrative installation'
                                },
                                {
                                    label: 'macOS Disk Image (.dmg)',
                                    url: 'https://github.com/omeaga1/process-forge/releases/download/v0.1.3/ProcessForge_0.1.3_aarch64.dmg',
                                    download: 'ProcessForge_0.1.3_aarch64.dmg',
                                    tag: 'macOS Apple Silicon',
                                    sub: 'Apple Silicon (M1/M2/M3/M4) native universal app'
                                },
                                {
                                    label: 'Linux AppImage (.AppImage)',
                                    url: 'https://github.com/omeaga1/process-forge/releases/download/v0.1.3/ProcessForge_0.1.3_amd64.AppImage',
                                    download: 'ProcessForge_0.1.3_amd64.AppImage',
                                    tag: 'Linux Standalone',
                                    sub: 'Compatible with Ubuntu, Debian, Fedora, Arch Linux'
                                },
                                {
                                    label: 'Linux Debian Package (.deb)',
                                    url: 'https://github.com/omeaga1/process-forge/releases/download/v0.1.3/ProcessForge_0.1.3_amd64.deb',
                                    download: 'ProcessForge_0.1.3_amd64.deb',
                                    tag: 'Ubuntu / Debian',
                                    sub: 'Native Debian package with apt integration'
                                }
                            ].map((item) => (_jsxs("a", { href: item.url, download: item.download, target: item.url.startsWith('http') ? '_blank' : undefined, rel: "noreferrer", style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'space-between',
                                    padding: '11px 14px',
                                    borderRadius: '8px',
                                    backgroundColor: OsakaJadePalette.background.surfaceElevated,
                                    border: `1px solid ${OsakaJadePalette.border.subtle}`,
                                    color: OsakaJadePalette.text.primary,
                                    textDecoration: 'none',
                                    transition: 'all 0.12s ease'
                                }, children: [_jsxs("div", { children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '2px' }, children: [_jsx("span", { style: { fontWeight: 600, fontSize: '0.88rem' }, children: item.label }), _jsx("span", { style: {
                                                            fontSize: '0.65rem',
                                                            fontWeight: 700,
                                                            padding: '1px 6px',
                                                            borderRadius: '4px',
                                                            backgroundColor: OsakaJadePalette.jade.muted,
                                                            color: OsakaJadePalette.jade[300]
                                                        }, children: item.tag })] }), _jsx("div", { style: { fontSize: '0.74rem', color: OsakaJadePalette.text.muted }, children: item.sub })] }), _jsx(Download, { size: 15, color: OsakaJadePalette.jade[400] })] }, item.label))) }), _jsx("div", { style: { display: 'flex', justifyContent: 'flex-end', marginTop: '18px' }, children: _jsx("button", { onClick: () => setIsOtherModalOpen(false), style: {
                                    padding: '8px 18px',
                                    borderRadius: '6px',
                                    backgroundColor: OsakaJadePalette.background.surfaceElevated,
                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                    color: OsakaJadePalette.text.primary,
                                    cursor: 'pointer',
                                    fontWeight: 600,
                                    fontSize: '0.85rem'
                                }, children: "Close" }) })] }) }))] }));
};
export default ProductLandingPage;
//# sourceMappingURL=ProductLandingPage.js.map