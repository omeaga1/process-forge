import React from 'react';
export declare const App: React.FC;
export default App;
//# sourceMappingURL=App.d.ts.map