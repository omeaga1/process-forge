export {};
//# sourceMappingURL=updaterProtocol.test.d.ts.map