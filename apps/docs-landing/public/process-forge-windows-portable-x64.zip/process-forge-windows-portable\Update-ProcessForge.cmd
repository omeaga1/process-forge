@echo off
setlocal
title ProcessForge Update Pull
echo ========================================================
echo   ProcessForge - Checking and Pulling Latest Updates
echo ========================================================
echo Terminating running ProcessForge instances...
taskkill /F /IM ProcessForge.exe /T > nul 2>&1
ping 127.0.0.1 -n 2 > nul

set "TARGET=%LOCALAPPDATA%\ProcessForge"
set "TEMP_ZIP=%TEMP%\process-forge-update.zip"
set "TEMP_DIR=%TEMP%\pf-update-extract"

echo Downloading latest release bundle...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$candidates = @('https://github.com/omeaga1/process-forge/releases/latest/download/process-forge-windows-portable-x64.zip','https://github.com/omeaga1/process-forge/releases/download/v0.1.2/process-forge-windows-portable-x64.zip','https://raw.githubusercontent.com/omeaga1/process-forge/main/release-dist/process-forge-windows-portable-x64.zip'); foreach ($u in $candidates) { try { Invoke-WebRequest -Uri $u -OutFile '%TEMP_ZIP%' -UseBasicParsing; if ((Get-Item '%TEMP_ZIP%').Length -gt 1000) { break } } catch {} }"

if not exist "%TEMP_ZIP%" (
  echo Failed to download update. Please check internet connection.
  pause
  exit /b 1
)

echo Extracting updated files...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Path '%TEMP_ZIP%' -DestinationPath '%TEMP_DIR%' -Force"

if exist "%TEMP_DIR%\process-forge-windows-portable\app" (
  xcopy /E /I /Y "%TEMP_DIR%\process-forge-windows-portable\app" "%TARGET%\app" > nul
) else if exist "%TEMP_DIR%\app" (
  xcopy /E /I /Y "%TEMP_DIR%\app" "%TARGET%\app" > nul
)

if exist "%TEMP_DIR%\process-forge-windows-portable\ProcessForge.exe" (
  copy /Y "%TEMP_DIR%\process-forge-windows-portable\ProcessForge.exe" "%TARGET%\" > nul
)

rd /s /q "%TEMP_DIR%" > nul 2>&1
del /f /q "%TEMP_ZIP%" > nul 2>&1

echo ========================================================
echo   Update applied successfully! Launching ProcessForge...
echo ========================================================
start "" "%TARGET%\ProcessForge.exe"
ping 127.0.0.1 -n 2 > nul
exit
