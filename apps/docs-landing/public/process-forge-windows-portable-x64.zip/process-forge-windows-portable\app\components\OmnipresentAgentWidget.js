import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState, useEffect, useRef } from 'react';
import { Sparkles, Send, X, ChevronUp, ChevronDown, Loader2, Cpu, ArrowRight } from 'lucide-react';
import { useTheme, getLlmCredentials, hasValidCredentials, dispatchMasterOrchestratorMessage } from '@process-forge/canvas-ui';
export const OmnipresentAgentWidget = ({ currentProject, onOpenStudio, onOpenAiModal, isInStudioView = false }) => {
    const { palette } = useTheme();
    const OsakaJadePalette = palette;
    const [isExpanded, setIsExpanded] = useState(false);
    const [inputText, setInputText] = useState('');
    const [isProcessing, setIsProcessing] = useState(false);
    const [creds, setCreds] = useState(() => getLlmCredentials());
    const [messages, setMessages] = useState([]);
    const messagesEndRef = useRef(null);
    useEffect(() => {
        const handleStorage = () => setCreds(getLlmCredentials());
        window.addEventListener('storage', handleStorage);
        return () => window.removeEventListener('storage', handleStorage);
    }, []);
    useEffect(() => {
        if (isExpanded) {
            messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
        }
    }, [messages, isExpanded]);
    if (isInStudioView)
        return null;
    const hasKey = hasValidCredentials(creds);
    const handleSendMessage = async (customPrompt) => {
        const text = customPrompt || inputText;
        if (!text.trim() || isProcessing)
            return;
        const userMsg = {
            id: `usr-${Date.now()}`,
            sender: 'user',
            senderTitle: 'Process Engineer',
            text,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
        setMessages((prev) => [...prev, userMsg]);
        if (!customPrompt)
            setInputText('');
        setIsProcessing(true);
        try {
            const res = await dispatchMasterOrchestratorMessage(text, {
                graphName: currentProject.graph.name,
                nodeCount: currentProject.graph.nodes.length,
                totalPackaged: 0,
                averageRatePerMin: 0
            });
            const agentMsg = {
                id: `agent-${Date.now()}`,
                sender: 'master_orchestrator',
                senderTitle: 'Plant Orchestrator',
                text: res.text,
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                modelBadge: res.senderBadge
            };
            setMessages((prev) => [...prev, agentMsg]);
        }
        catch (err) {
            setMessages((prev) => [
                ...prev,
                {
                    id: `err-${Date.now()}`,
                    sender: 'master_orchestrator',
                    senderTitle: 'Error',
                    text: `[Error]: ${err.message || 'Failed to communicate with model provider'}`,
                    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                }
            ]);
        }
        finally {
            setIsProcessing(false);
        }
    };
    const modelDisplayLabel = hasKey
        ? `${creds.provider.toUpperCase()}`
        : 'No Model Linked';
    return (_jsxs("div", { style: {
            position: 'fixed',
            bottom: 18,
            right: isInStudioView ? 52 : 24, // avoid colliding with dock toggle in studio
            zIndex: 90,
            fontFamily: 'Inter, system-ui, sans-serif'
        }, children: [isExpanded && (_jsxs("div", { style: {
                    position: 'absolute',
                    bottom: 48,
                    right: 0,
                    width: 380,
                    maxWidth: 'calc(100vw - 32px)',
                    height: 480,
                    backgroundColor: OsakaJadePalette.background.surface,
                    border: `1px solid ${OsakaJadePalette.border.glow}`,
                    borderRadius: 12,
                    boxShadow: '0 16px 40px rgba(0, 0, 0, 0.45)',
                    display: 'flex',
                    flexDirection: 'column',
                    overflow: 'hidden',
                    animation: 'fadeIn 0.15s ease-out'
                }, children: [_jsxs("div", { style: {
                            padding: '10px 14px',
                            backgroundColor: OsakaJadePalette.background.canvas,
                            borderBottom: `1px solid ${OsakaJadePalette.border.default}`,
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between'
                        }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 8 }, children: [_jsx("div", { style: {
                                            width: 24,
                                            height: 24,
                                            borderRadius: 6,
                                            backgroundColor: OsakaJadePalette.jade.muted,
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            border: `1px solid ${OsakaJadePalette.jade[600]}`
                                        }, children: _jsx(Sparkles, { size: 14, color: OsakaJadePalette.jade[400] }) }), _jsxs("div", { children: [_jsxs("div", { style: { fontSize: 13, fontWeight: 700, color: OsakaJadePalette.text.primary, display: 'flex', alignItems: 'center', gap: 6 }, children: [_jsx("span", { children: "Master Process Orchestrator" }), _jsx("span", { style: {
                                                            width: 6,
                                                            height: 6,
                                                            borderRadius: '50%',
                                                            backgroundColor: hasKey ? OsakaJadePalette.jade[500] : '#f59e0b',
                                                            boxShadow: hasKey ? `0 0 6px ${OsakaJadePalette.jade.glow}` : undefined
                                                        } })] }), _jsxs("div", { style: { fontSize: 10, color: OsakaJadePalette.text.muted }, children: ["Active Plant: ", currentProject.name.slice(0, 28)] })] })] }), _jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 4 }, children: [_jsxs("button", { onClick: onOpenAiModal, style: {
                                            background: 'none',
                                            border: `1px solid ${OsakaJadePalette.border.default}`,
                                            borderRadius: 4,
                                            padding: '3px 6px',
                                            color: OsakaJadePalette.text.secondary,
                                            fontSize: 10,
                                            cursor: 'pointer',
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: 4
                                        }, title: "Configure Model Subscriptions", children: [_jsx(Cpu, { size: 11 }), _jsx("span", { children: modelDisplayLabel })] }), _jsx("button", { onClick: () => setIsExpanded(false), style: {
                                            background: 'none',
                                            border: 'none',
                                            color: OsakaJadePalette.text.muted,
                                            cursor: 'pointer',
                                            padding: 4
                                        }, children: _jsx(X, { size: 16 }) })] })] }), !isInStudioView && onOpenStudio && (_jsxs("div", { style: {
                            backgroundColor: 'rgba(16, 185, 129, 0.08)',
                            borderBottom: `1px solid rgba(16, 185, 129, 0.2)`,
                            padding: '6px 12px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            fontSize: 11
                        }, children: [_jsx("span", { style: { color: OsakaJadePalette.text.accent }, children: "Flowsheet active in memory" }), _jsxs("button", { onClick: () => {
                                    setIsExpanded(false);
                                    onOpenStudio();
                                }, style: {
                                    background: OsakaJadePalette.jade[600],
                                    border: 'none',
                                    borderRadius: 4,
                                    color: '#fff',
                                    padding: '3px 8px',
                                    fontSize: 10,
                                    fontWeight: 600,
                                    cursor: 'pointer',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: 4
                                }, children: [_jsx("span", { children: "Open Studio" }), _jsx(ArrowRight, { size: 11 })] })] })), _jsxs("div", { style: {
                            flex: 1,
                            overflowY: 'auto',
                            padding: 12,
                            display: 'flex',
                            flexDirection: 'column',
                            gap: 10
                        }, children: [messages.map((m) => {
                                const isUser = m.sender === 'user';
                                return (_jsxs("div", { style: {
                                        alignSelf: isUser ? 'flex-end' : 'flex-start',
                                        maxWidth: '85%',
                                        backgroundColor: isUser
                                            ? 'rgba(16, 185, 129, 0.15)'
                                            : OsakaJadePalette.background.canvas,
                                        border: `1px solid ${isUser ? OsakaJadePalette.jade[600] : OsakaJadePalette.border.default}`,
                                        borderRadius: 8,
                                        padding: '8px 10px',
                                        fontSize: 12,
                                        lineHeight: 1.45,
                                        color: OsakaJadePalette.text.primary
                                    }, children: [_jsxs("div", { style: {
                                                fontSize: 10,
                                                fontWeight: 600,
                                                color: isUser ? OsakaJadePalette.text.accent : OsakaJadePalette.text.secondary,
                                                marginBottom: 3,
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: 6
                                            }, children: [_jsx("span", { children: m.senderTitle || (isUser ? 'You' : 'Orchestrator') }), m.modelBadge && (_jsx("span", { style: {
                                                        fontSize: 9,
                                                        backgroundColor: 'rgba(255,255,255,0.06)',
                                                        padding: '1px 4px',
                                                        borderRadius: 3,
                                                        color: OsakaJadePalette.text.muted
                                                    }, children: m.modelBadge }))] }), _jsx("div", { style: { whiteSpace: 'pre-wrap' }, children: m.text })] }, m.id));
                            }), isProcessing && (_jsxs("div", { style: {
                                    alignSelf: 'flex-start',
                                    backgroundColor: OsakaJadePalette.background.canvas,
                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                    borderRadius: 8,
                                    padding: '8px 12px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: 8,
                                    fontSize: 12,
                                    color: OsakaJadePalette.text.muted
                                }, children: [_jsx(Loader2, { size: 14, className: "animate-spin", color: OsakaJadePalette.jade.glow }), _jsx("span", { children: "Orchestrator thinking..." })] })), _jsx("div", { ref: messagesEndRef })] }), _jsx("div", { style: {
                            padding: '6px 10px',
                            backgroundColor: OsakaJadePalette.background.canvas,
                            borderTop: `1px solid ${OsakaJadePalette.border.default}`,
                            display: 'flex',
                            gap: 6,
                            overflowX: 'auto'
                        }, children: [
                            'Audit line bottleneck',
                            'Sizing for 120 cpm line',
                            'ASME nozzle rules'
                        ].map((p, idx) => (_jsx("button", { onClick: () => handleSendMessage(p), disabled: isProcessing, style: {
                                backgroundColor: 'rgba(255,255,255,0.04)',
                                border: `1px solid ${OsakaJadePalette.border.default}`,
                                borderRadius: 4,
                                padding: '3px 8px',
                                color: OsakaJadePalette.text.secondary,
                                fontSize: 10,
                                whiteSpace: 'nowrap',
                                cursor: 'pointer'
                            }, children: p }, idx))) }), _jsxs("div", { style: {
                            padding: 10,
                            backgroundColor: OsakaJadePalette.background.surface,
                            borderTop: `1px solid ${OsakaJadePalette.border.default}`,
                            display: 'flex',
                            gap: 6
                        }, children: [_jsx("input", { type: "text", value: inputText, onChange: (e) => setInputText(e.target.value), onKeyDown: (e) => {
                                    if (e.key === 'Enter')
                                        handleSendMessage();
                                }, placeholder: "Ask the Master Orchestrator...", style: {
                                    flex: 1,
                                    backgroundColor: OsakaJadePalette.background.canvas,
                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                    borderRadius: 6,
                                    padding: '6px 10px',
                                    fontSize: 12,
                                    color: OsakaJadePalette.text.primary,
                                    outline: 'none'
                                } }), _jsx("button", { onClick: () => handleSendMessage(), disabled: !inputText.trim() || isProcessing, style: {
                                    backgroundColor: inputText.trim() && !isProcessing ? OsakaJadePalette.jade[600] : 'rgba(255,255,255,0.05)',
                                    border: 'none',
                                    borderRadius: 6,
                                    padding: '0 10px',
                                    color: '#fff',
                                    cursor: inputText.trim() && !isProcessing ? 'pointer' : 'default',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center'
                                }, children: _jsx(Send, { size: 14 }) })] })] })), _jsxs("button", { onClick: () => setIsExpanded((prev) => !prev), style: {
                    display: 'flex',
                    alignItems: 'center',
                    gap: 8,
                    padding: '7px 14px',
                    borderRadius: 24,
                    backgroundColor: OsakaJadePalette.background.surface,
                    border: `1px solid ${isExpanded ? OsakaJadePalette.jade.glow : OsakaJadePalette.border.glow}`,
                    boxShadow: '0 4px 16px rgba(0, 0, 0, 0.35)',
                    color: OsakaJadePalette.text.primary,
                    cursor: 'pointer',
                    transition: 'all 0.15s ease'
                }, title: "Master Process Orchestrator (Always Visible AI Companion)", children: [_jsx("div", { style: {
                            width: 20,
                            height: 20,
                            borderRadius: '50%',
                            backgroundColor: OsakaJadePalette.jade.muted,
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            border: `1px solid ${OsakaJadePalette.jade[500]}`
                        }, children: _jsx(Sparkles, { size: 12, color: OsakaJadePalette.jade[400] }) }), _jsxs("div", { style: { textAlign: 'left' }, children: [_jsxs("div", { style: { fontSize: 11, fontWeight: 700, color: OsakaJadePalette.text.primary, display: 'flex', alignItems: 'center', gap: 5 }, children: [_jsx("span", { children: "Process Copilot" }), _jsx("span", { style: {
                                            width: 5,
                                            height: 5,
                                            borderRadius: '50%',
                                            backgroundColor: hasKey ? OsakaJadePalette.jade[500] : '#f59e0b'
                                        } })] }), _jsx("div", { style: { fontSize: 9, color: OsakaJadePalette.text.muted }, children: modelDisplayLabel })] }), isExpanded ? _jsx(ChevronDown, { size: 14 }) : _jsx(ChevronUp, { size: 14 })] })] }));
};
//# sourceMappingURL=OmnipresentAgentWidget.js.map