import React from 'react';
interface GuestAcknowledgementModalProps {
    isOpen: boolean;
    onClose: () => void;
    onExportFile: () => void;
    onOpenAccountModal?: () => void;
}
export declare const GuestAcknowledgementModal: React.FC<GuestAcknowledgementModalProps>;
export {};
//# sourceMappingURL=GuestAcknowledgementModal.d.ts.map