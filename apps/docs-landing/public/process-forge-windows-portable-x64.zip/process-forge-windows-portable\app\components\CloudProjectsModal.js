import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState, useEffect } from 'react';
import { Cloud, FolderOpen, Search, Check, Trash2, Download, Upload, Clock, Layers, X, ArrowRight, ShieldCheck, Activity } from 'lucide-react';
import { useTheme } from '@process-forge/canvas-ui';
import { useAccount } from '../auth/useAccount.js';
import { listUserCloudProjects, deleteProjectFromCloud } from '../storage/cloudStorageAdapter.js';
import { downloadProjectFile } from '../storage/localStorageAdapter.js';
export const CloudProjectsModal = ({ isOpen, onClose, onSelectProject, onUploadLocalFile }) => {
    const { palette } = useTheme();
    const OsakaJadePalette = palette;
    const { user, isAuthenticated, openAccountModal } = useAccount();
    const [projects, setProjects] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [isLoading, setIsLoading] = useState(true);
    const [loadedId, setLoadedId] = useState(null);
    useEffect(() => {
        if (isOpen) {
            setIsLoading(true);
            listUserCloudProjects(user)
                .then((items) => {
                setProjects(items);
                setIsLoading(false);
            })
                .catch(() => setIsLoading(false));
        }
    }, [isOpen, user]);
    if (!isOpen)
        return null;
    const handleSelect = (record) => {
        setLoadedId(record.id);
        setTimeout(() => {
            onSelectProject(record.bundle);
            onClose();
        }, 400);
    };
    const handleDelete = async (e, recordId) => {
        e.stopPropagation();
        if (window.confirm('Delete this simulation project from Cloud Storage?')) {
            await deleteProjectFromCloud(recordId, user);
            setProjects((prev) => prev.filter((p) => p.id !== recordId));
        }
    };
    const handleExport = (e, record) => {
        e.stopPropagation();
        downloadProjectFile(record.bundle);
    };
    const handleFileInput = (e) => {
        const file = e.target.files?.[0];
        if (file) {
            onUploadLocalFile(file);
            e.target.value = '';
            onClose();
        }
    };
    const filteredProjects = projects.filter((p) => p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.description.toLowerCase().includes(searchQuery.toLowerCase()));
    const formatRelativeTime = (isoString) => {
        try {
            const diff = Date.now() - new Date(isoString).getTime();
            const mins = Math.floor(diff / 60000);
            if (mins < 1)
                return 'Just now';
            if (mins < 60)
                return `${mins}m ago`;
            const hours = Math.floor(mins / 60);
            if (hours < 24)
                return `${hours}h ago`;
            const days = Math.floor(hours / 24);
            return `${days}d ago`;
        }
        catch {
            return 'Recently';
        }
    };
    return (_jsx("div", { style: {
            position: 'fixed',
            inset: 0,
            backgroundColor: 'rgba(5, 10, 12, 0.85)',
            backdropFilter: 'blur(8px)',
            zIndex: 10000,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: 20
        }, children: _jsxs("div", { style: {
                width: 720,
                maxWidth: '100%',
                maxHeight: 'min(90vh, calc(100vh - 40px))',
                backgroundColor: OsakaJadePalette.background.surface,
                border: `1px solid ${OsakaJadePalette.border.default}`,
                borderRadius: 12,
                boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.8)',
                overflow: 'hidden',
                display: 'flex',
                flexDirection: 'column'
            }, children: [_jsxs("div", { style: {
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        padding: '16px 20px',
                        backgroundColor: OsakaJadePalette.background.canvas,
                        borderBottom: `1px solid ${OsakaJadePalette.border.subtle}`
                    }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 10 }, children: [_jsx("div", { style: {
                                        width: 34,
                                        height: 34,
                                        borderRadius: 8,
                                        backgroundColor: 'rgba(16, 185, 129, 0.15)',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        color: OsakaJadePalette.jade[500]
                                    }, children: _jsx(Cloud, { size: 18 }) }), _jsxs("div", { children: [_jsx("h3", { style: { margin: 0, fontSize: 16, fontWeight: 700, color: OsakaJadePalette.text.primary }, children: "Cloud Simulation Projects" }), _jsx("span", { style: { fontSize: 12, color: OsakaJadePalette.text.secondary }, children: isAuthenticated && user
                                                ? `${user.name} • ${projects.length} simulations in Cloud Storage`
                                                : 'Open, browse, or import saved digital twins' })] })] }), _jsx("button", { onClick: onClose, style: {
                                background: 'none',
                                border: 'none',
                                color: OsakaJadePalette.text.muted,
                                cursor: 'pointer',
                                padding: 4
                            }, children: _jsx(X, { size: 18 }) })] }), _jsxs("div", { style: {
                        padding: '12px 20px',
                        backgroundColor: OsakaJadePalette.background.surfaceElevated,
                        borderBottom: `1px solid ${OsakaJadePalette.border.subtle}`,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        gap: 12,
                        flexWrap: 'wrap'
                    }, children: [_jsxs("div", { style: {
                                display: 'flex',
                                alignItems: 'center',
                                gap: 8,
                                backgroundColor: OsakaJadePalette.background.canvas,
                                border: `1px solid ${OsakaJadePalette.border.default}`,
                                borderRadius: 6,
                                padding: '6px 12px',
                                flex: 1,
                                minWidth: 200
                            }, children: [_jsx(Search, { size: 14, color: OsakaJadePalette.text.muted }), _jsx("input", { type: "text", placeholder: "Search cloud simulations...", value: searchQuery, onChange: (e) => setSearchQuery(e.target.value), style: {
                                        border: 'none',
                                        background: 'transparent',
                                        outline: 'none',
                                        color: OsakaJadePalette.text.primary,
                                        fontSize: 12,
                                        width: '100%'
                                    } })] }), _jsxs("label", { style: {
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: 6,
                                padding: '6px 14px',
                                backgroundColor: OsakaJadePalette.background.surface,
                                border: `1px solid ${OsakaJadePalette.border.default}`,
                                borderRadius: 6,
                                color: OsakaJadePalette.text.secondary,
                                fontSize: 12,
                                fontWeight: 600,
                                cursor: 'pointer',
                                whiteSpace: 'nowrap'
                            }, children: [_jsx(Upload, { size: 14 }), "Import .pfg File", _jsx("input", { type: "file", accept: ".json,.pfg,.pfg.json", onChange: handleFileInput, style: { display: 'none' } })] })] }), _jsx("div", { style: { flex: 1, overflowY: 'auto', padding: 20, display: 'flex', flexDirection: 'column', gap: 12 }, children: !isAuthenticated ? (
                    /* Unauthenticated Prompt */
                    _jsxs("div", { style: {
                            padding: 30,
                            textAlign: 'center',
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                            gap: 14
                        }, children: [_jsx("div", { style: {
                                    width: 48,
                                    height: 48,
                                    borderRadius: '50%',
                                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    color: OsakaJadePalette.jade[400]
                                }, children: _jsx(Cloud, { size: 24 }) }), _jsxs("div", { children: [_jsx("h4", { style: { margin: '0 0 6px 0', fontSize: 16, color: OsakaJadePalette.text.primary }, children: "Connect Account for Cloud Storage" }), _jsx("p", { style: { margin: 0, fontSize: 13, color: OsakaJadePalette.text.secondary, maxWidth: 420 }, children: "Sign in with GitHub, Google, or your corporate engineering email to automatically sync simulations to the cloud and collaborate across devices." })] }), _jsxs("button", { onClick: () => {
                                    onClose();
                                    openAccountModal();
                                }, style: {
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: 6,
                                    padding: '9px 20px',
                                    backgroundColor: OsakaJadePalette.jade[500],
                                    color: OsakaJadePalette.text.inverse,
                                    border: 'none',
                                    borderRadius: 6,
                                    fontWeight: 700,
                                    fontSize: 13,
                                    cursor: 'pointer',
                                    marginTop: 6
                                }, children: ["Sign In Now ", _jsx(ArrowRight, { size: 14 })] })] })) : isLoading ? (_jsx("div", { style: { textAlign: 'center', padding: 40, color: OsakaJadePalette.text.secondary }, children: "Loading cloud digital twins..." })) : filteredProjects.length === 0 ? (_jsxs("div", { style: { textAlign: 'center', padding: 40, color: OsakaJadePalette.text.secondary }, children: ["No simulations found matching \"", searchQuery, "\". Save your active flowsheet to Cloud Storage to see it here!"] })) : (filteredProjects.map((project) => {
                        const isLoaded = loadedId === project.id;
                        return (_jsxs("div", { onClick: () => handleSelect(project), style: {
                                padding: 16,
                                borderRadius: 8,
                                backgroundColor: OsakaJadePalette.background.surfaceElevated,
                                border: `1px solid ${isLoaded ? OsakaJadePalette.jade[500] : OsakaJadePalette.border.default}`,
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'space-between',
                                gap: 16,
                                cursor: 'pointer',
                                transition: 'all 0.15s ease'
                            }, children: [_jsxs("div", { style: { flex: 1, minWidth: 0 }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }, children: [_jsx("span", { style: { fontSize: 14, fontWeight: 700, color: OsakaJadePalette.text.primary }, children: project.name }), _jsxs("span", { style: {
                                                        fontSize: 10,
                                                        fontWeight: 600,
                                                        padding: '2px 6px',
                                                        borderRadius: 4,
                                                        backgroundColor: 'rgba(16, 185, 129, 0.15)',
                                                        color: OsakaJadePalette.jade[400],
                                                        border: `1px solid ${OsakaJadePalette.jade[700]}`,
                                                        display: 'flex',
                                                        alignItems: 'center',
                                                        gap: 4
                                                    }, children: [_jsx(ShieldCheck, { size: 10 }), " Cloud Synced"] })] }), _jsx("p", { style: {
                                                margin: '0 0 8px 0',
                                                fontSize: 12,
                                                color: OsakaJadePalette.text.secondary,
                                                lineHeight: 1.4,
                                                overflow: 'hidden',
                                                textOverflow: 'ellipsis',
                                                whiteSpace: 'nowrap'
                                            }, children: project.description || 'No description provided.' }), _jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 14, fontSize: 11, color: OsakaJadePalette.text.muted }, children: [_jsxs("span", { style: { display: 'flex', alignItems: 'center', gap: 4 }, children: [_jsx(Layers, { size: 12 }), " ", project.nodeCount, " Equipment Units"] }), _jsxs("span", { style: { display: 'flex', alignItems: 'center', gap: 4 }, children: [_jsx(Activity, { size: 12 }), " ", project.streamCount, " Streams"] }), _jsxs("span", { style: { display: 'flex', alignItems: 'center', gap: 4 }, children: [_jsx(Clock, { size: 12 }), " ", formatRelativeTime(project.updatedAt)] })] })] }), _jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 8 }, children: [_jsx("button", { onClick: (e) => handleExport(e, project), title: "Download .pfg.json bundle", style: {
                                                background: 'none',
                                                border: `1px solid ${OsakaJadePalette.border.subtle}`,
                                                borderRadius: 6,
                                                color: OsakaJadePalette.text.secondary,
                                                padding: 6,
                                                cursor: 'pointer'
                                            }, children: _jsx(Download, { size: 14 }) }), _jsx("button", { onClick: (e) => handleDelete(e, project.id), title: "Delete from Cloud", style: {
                                                background: 'none',
                                                border: `1px solid ${OsakaJadePalette.border.subtle}`,
                                                borderRadius: 6,
                                                color: OsakaJadePalette.text.muted,
                                                padding: 6,
                                                cursor: 'pointer'
                                            }, children: _jsx(Trash2, { size: 14 }) }), _jsxs("button", { onClick: () => handleSelect(project), style: {
                                                display: 'inline-flex',
                                                alignItems: 'center',
                                                gap: 6,
                                                padding: '6px 12px',
                                                borderRadius: 6,
                                                backgroundColor: isLoaded ? OsakaJadePalette.jade[600] : OsakaJadePalette.jade[500],
                                                color: OsakaJadePalette.text.inverse,
                                                border: 'none',
                                                fontWeight: 700,
                                                fontSize: 12,
                                                cursor: 'pointer'
                                            }, children: [isLoaded ? _jsx(Check, { size: 13 }) : _jsx(FolderOpen, { size: 13 }), isLoaded ? 'Loaded' : 'Open Twin'] })] })] }, project.id));
                    })) }), _jsxs("div", { style: {
                        padding: '12px 20px',
                        backgroundColor: OsakaJadePalette.background.canvas,
                        borderTop: `1px solid ${OsakaJadePalette.border.subtle}`,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        fontSize: 11,
                        color: OsakaJadePalette.text.muted
                    }, children: [_jsx("span", { children: "ProcessForge Cloud replicates topology, machine configs, Sub-Agent transcripts, and simulation telemetry." }), _jsx("button", { onClick: onClose, style: {
                                padding: '6px 14px',
                                backgroundColor: 'transparent',
                                border: `1px solid ${OsakaJadePalette.border.default}`,
                                borderRadius: 6,
                                color: OsakaJadePalette.text.secondary,
                                cursor: 'pointer'
                            }, children: "Close" })] })] }) }));
};
//# sourceMappingURL=CloudProjectsModal.js.map