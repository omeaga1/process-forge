import React from 'react';
import type { SimulationProject } from '@process-forge/protocol';
export interface CloudProjectsModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSelectProject: (project: SimulationProject) => void;
    onUploadLocalFile: (file: File) => void;
}
export declare const CloudProjectsModal: React.FC<CloudProjectsModalProps>;
//# sourceMappingURL=CloudProjectsModal.d.ts.map