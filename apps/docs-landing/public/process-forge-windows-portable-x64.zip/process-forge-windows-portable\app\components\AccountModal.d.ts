import React from 'react';
export interface AccountModalProps {
    isOpen: boolean;
    onClose: () => void;
    onOpenCloudProjects?: () => void;
}
export declare const AccountModal: React.FC<AccountModalProps>;
//# sourceMappingURL=AccountModal.d.ts.map