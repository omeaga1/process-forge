@echo off
echo Starting ProcessForge Industrial Studio...
if exist "%~dp0ProcessForge.exe" (
  start "" "%~dp0ProcessForge.exe"
) else (
  start "" "app\index.html"
)
