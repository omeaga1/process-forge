import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from 'react';
import { Save, Download, X, Check, Cloud, ShieldCheck, User, HardDrive } from 'lucide-react';
import { useTheme } from '@process-forge/canvas-ui';
import { useAccount } from '../auth/useAccount.js';
export const SaveProjectModal = ({ isOpen, project, onClose, onSaveLocal, onDownloadFile, onSaveCloud }) => {
    const { palette } = useTheme();
    const OsakaJadePalette = palette;
    const { user, isAuthenticated, openAccountModal } = useAccount();
    const [name, setName] = useState(project.name);
    const [description, setDescription] = useState(project.description || '');
    const [isSavedLocally, setIsSavedLocally] = useState(false);
    const [isSavingCloud, setIsSavingCloud] = useState(false);
    const [isSavedCloud, setIsSavedCloud] = useState(false);
    if (!isOpen)
        return null;
    const handleSaveLocal = () => {
        onSaveLocal(name, description);
        setIsSavedLocally(true);
        setTimeout(() => setIsSavedLocally(false), 2000);
    };
    const handleSaveCloud = async () => {
        if (!onSaveCloud)
            return;
        setIsSavingCloud(true);
        try {
            await onSaveCloud(name, description);
            setIsSavedCloud(true);
            setTimeout(() => setIsSavedCloud(false), 2000);
        }
        catch (e) {
            console.error('Cloud save failed:', e);
        }
        finally {
            setIsSavingCloud(false);
        }
    };
    const handleDownload = () => {
        onDownloadFile(name, description);
    };
    return (_jsx("div", { style: {
            position: 'fixed',
            inset: 0,
            backgroundColor: 'rgba(5, 10, 12, 0.85)',
            backdropFilter: 'blur(8px)',
            zIndex: 10000,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: 20
        }, children: _jsxs("div", { style: {
                width: 580,
                maxWidth: '100%',
                maxHeight: 'min(90vh, calc(100vh - 40px))',
                backgroundColor: OsakaJadePalette.background.surface,
                border: `1px solid ${OsakaJadePalette.border.default}`,
                borderRadius: 12,
                boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.8)',
                overflow: 'hidden',
                display: 'flex',
                flexDirection: 'column'
            }, children: [_jsxs("div", { style: {
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        padding: '16px 20px',
                        backgroundColor: OsakaJadePalette.background.canvas,
                        borderBottom: `1px solid ${OsakaJadePalette.border.subtle}`
                    }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 10 }, children: [_jsx("div", { style: {
                                        width: 32,
                                        height: 32,
                                        borderRadius: 8,
                                        backgroundColor: 'rgba(16, 185, 129, 0.15)',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        color: OsakaJadePalette.jade[500]
                                    }, children: _jsx(Save, { size: 18 }) }), _jsxs("div", { children: [_jsx("h3", { style: { margin: 0, fontSize: 16, fontWeight: 700, color: OsakaJadePalette.text.primary }, children: "Save Simulation Flowsheet" }), _jsx("span", { style: { fontSize: 12, color: OsakaJadePalette.text.secondary }, children: "Preserve digital twin topology, equipment dressing, and agent transcripts" })] })] }), _jsx("button", { onClick: onClose, style: {
                                background: 'none',
                                border: 'none',
                                color: OsakaJadePalette.text.muted,
                                cursor: 'pointer',
                                padding: 4
                            }, children: _jsx(X, { size: 18 }) })] }), _jsxs("div", { style: { padding: 22, display: 'flex', flexDirection: 'column', gap: 14, overflowY: 'auto' }, children: [_jsxs("div", { children: [_jsx("label", { style: { display: 'block', fontSize: 12, fontWeight: 600, color: OsakaJadePalette.text.secondary, marginBottom: 4 }, children: "Simulation Project Name" }), _jsx("input", { type: "text", value: name, onChange: (e) => setName(e.target.value), placeholder: "e.g. Sherwin-Williams Line Twin", style: {
                                        width: '100%',
                                        backgroundColor: OsakaJadePalette.background.canvas,
                                        border: `1px solid ${OsakaJadePalette.border.default}`,
                                        borderRadius: 6,
                                        padding: '8px 12px',
                                        color: OsakaJadePalette.text.primary,
                                        fontSize: 13,
                                        outline: 'none'
                                    } })] }), _jsxs("div", { children: [_jsx("label", { style: { display: 'block', fontSize: 12, fontWeight: 600, color: OsakaJadePalette.text.secondary, marginBottom: 4 }, children: "Description & Engineering Notes" }), _jsx("textarea", { rows: 2, value: description, onChange: (e) => setDescription(e.target.value), placeholder: "Facility notes, batch recipe details, or line targets...", style: {
                                        width: '100%',
                                        backgroundColor: OsakaJadePalette.background.canvas,
                                        border: `1px solid ${OsakaJadePalette.border.default}`,
                                        borderRadius: 6,
                                        padding: '8px 12px',
                                        color: OsakaJadePalette.text.primary,
                                        fontSize: 13,
                                        outline: 'none',
                                        resize: 'none'
                                    } })] }), _jsxs("div", { style: { display: 'flex', flexDirection: 'column', gap: 10, marginTop: 4 }, children: [_jsxs("div", { style: {
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'space-between',
                                        padding: 14,
                                        backgroundColor: 'rgba(16, 185, 129, 0.08)',
                                        border: `1px solid ${OsakaJadePalette.jade[600]}`,
                                        borderRadius: 8
                                    }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 10 }, children: [_jsx(Cloud, { size: 20, color: OsakaJadePalette.jade[400] }), _jsxs("div", { children: [_jsxs("div", { style: { fontSize: 13, fontWeight: 700, color: OsakaJadePalette.text.primary, display: 'flex', alignItems: 'center', gap: 6 }, children: ["Save to ProcessForge Cloud", _jsx("span", { style: {
                                                                        fontSize: 9,
                                                                        fontWeight: 700,
                                                                        padding: '1px 6px',
                                                                        borderRadius: 10,
                                                                        backgroundColor: OsakaJadePalette.jade[500],
                                                                        color: OsakaJadePalette.text.inverse
                                                                    }, children: "RECOMMENDED" })] }), _jsx("div", { style: { fontSize: 11, color: OsakaJadePalette.text.secondary, marginTop: 2 }, children: isAuthenticated && user
                                                                ? `Syncs to ${user.name}'s account • Accessible across all devices`
                                                                : 'Sync your digital twin across devices and team members' })] })] }), isAuthenticated ? (_jsxs("button", { onClick: handleSaveCloud, disabled: isSavingCloud, style: {
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: 6,
                                                padding: '8px 16px',
                                                backgroundColor: isSavedCloud ? OsakaJadePalette.jade[600] : OsakaJadePalette.jade[500],
                                                border: 'none',
                                                borderRadius: 6,
                                                color: OsakaJadePalette.text.inverse,
                                                fontSize: 12,
                                                fontWeight: 700,
                                                cursor: isSavingCloud ? 'wait' : 'pointer'
                                            }, children: [isSavedCloud ? _jsx(Check, { size: 14 }) : _jsx(Cloud, { size: 14 }), isSavedCloud ? 'Saved to Cloud!' : isSavingCloud ? 'Syncing...' : 'Save to Cloud'] })) : (_jsxs("button", { onClick: () => {
                                                onClose();
                                                openAccountModal();
                                            }, style: {
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: 6,
                                                padding: '8px 14px',
                                                backgroundColor: OsakaJadePalette.jade[500],
                                                border: 'none',
                                                borderRadius: 6,
                                                color: OsakaJadePalette.text.inverse,
                                                fontSize: 12,
                                                fontWeight: 700,
                                                cursor: 'pointer'
                                            }, children: [_jsx(User, { size: 13 }), "Sign In to Sync"] }))] }), _jsxs("div", { style: {
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'space-between',
                                        padding: 12,
                                        backgroundColor: OsakaJadePalette.background.canvas,
                                        border: `1px solid ${OsakaJadePalette.border.subtle}`,
                                        borderRadius: 8
                                    }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 10 }, children: [_jsx(HardDrive, { size: 18, color: OsakaJadePalette.text.secondary }), _jsxs("div", { children: [_jsx("div", { style: { fontSize: 13, fontWeight: 600, color: OsakaJadePalette.text.primary }, children: "Browser Local Storage" }), _jsx("div", { style: { fontSize: 11, color: OsakaJadePalette.text.secondary }, children: "Quick save to this browser for fast reloading" })] })] }), _jsxs("button", { onClick: handleSaveLocal, style: {
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: 6,
                                                padding: '6px 12px',
                                                backgroundColor: isSavedLocally ? 'rgba(16, 185, 129, 0.2)' : 'rgba(255, 255, 255, 0.06)',
                                                border: `1px solid ${isSavedLocally ? OsakaJadePalette.jade[500] : OsakaJadePalette.border.default}`,
                                                borderRadius: 6,
                                                color: isSavedLocally ? OsakaJadePalette.jade[300] : OsakaJadePalette.text.primary,
                                                fontSize: 12,
                                                fontWeight: 600,
                                                cursor: 'pointer'
                                            }, children: [isSavedLocally ? _jsx(Check, { size: 13 }) : _jsx(Save, { size: 13 }), isSavedLocally ? 'Saved' : 'Save Local'] })] }), _jsxs("div", { style: {
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'space-between',
                                        padding: 12,
                                        backgroundColor: OsakaJadePalette.background.canvas,
                                        border: `1px solid ${OsakaJadePalette.border.subtle}`,
                                        borderRadius: 8
                                    }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 10 }, children: [_jsx(Download, { size: 18, color: OsakaJadePalette.text.secondary }), _jsxs("div", { children: [_jsx("div", { style: { fontSize: 13, fontWeight: 600, color: OsakaJadePalette.text.primary }, children: "Download .pfg.json Bundle" }), _jsx("div", { style: { fontSize: 11, color: OsakaJadePalette.text.secondary }, children: "Export a standalone JSON file to share or archive on your drive" })] })] }), _jsxs("button", { onClick: handleDownload, style: {
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: 6,
                                                padding: '6px 12px',
                                                backgroundColor: 'rgba(255, 255, 255, 0.06)',
                                                border: `1px solid ${OsakaJadePalette.border.default}`,
                                                borderRadius: 6,
                                                color: OsakaJadePalette.text.primary,
                                                fontSize: 12,
                                                fontWeight: 600,
                                                cursor: 'pointer'
                                            }, children: [_jsx(Download, { size: 13 }), "Download"] })] })] })] }), _jsxs("div", { style: {
                        padding: '12px 20px',
                        backgroundColor: OsakaJadePalette.background.canvas,
                        borderTop: `1px solid ${OsakaJadePalette.border.subtle}`,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        fontSize: 11,
                        color: OsakaJadePalette.text.muted
                    }, children: [_jsxs("span", { style: { display: 'flex', alignItems: 'center', gap: 4 }, children: [_jsx(ShieldCheck, { size: 12, color: OsakaJadePalette.jade[500] }), "100% Deterministic Simulation State Preservation"] }), _jsx("button", { onClick: onClose, style: {
                                padding: '6px 14px',
                                backgroundColor: 'transparent',
                                border: `1px solid ${OsakaJadePalette.border.default}`,
                                borderRadius: 6,
                                color: OsakaJadePalette.text.secondary,
                                fontSize: 12,
                                cursor: 'pointer'
                            }, children: "Close" })] })] }) }));
};
//# sourceMappingURL=SaveProjectModal.js.map