/**
 * User Account & Session Management for ProcessForge Cloud
 * Authentic authentication with real password verification, SHA-256 hashing,
 * and zero fake stock photos or mock personas.
 */
export interface UserSession {
    id: string;
    email: string;
    name: string;
    avatarUrl?: string;
    organization: string;
    provider: 'github' | 'google' | 'microsoft' | 'email';
    token: string;
    plan: 'Community' | 'Professional' | 'Enterprise';
    cloudStorageQuota: {
        usedProjects: number;
        maxProjects: number;
    };
    createdAt: string;
}
export interface StoredUserAccount {
    id: string;
    email: string;
    name: string;
    organization: string;
    passwordHash: string;
    salt: string;
    avatarUrl?: string;
    plan: 'Community' | 'Professional' | 'Enterprise';
    createdAt: string;
}
/**
 * Generate authentic monogram initials (e.g. "Vincent Price" -> "VP")
 */
export declare function getInitials(name?: string, email?: string): string;
/**
 * Generate a clean, authentic SVG avatar data URI with the engineer's initials
 * Replaces all third-party stock photos with zero external dependency
 */
export declare function generateInitialsAvatar(name?: string, email?: string): string;
/**
 * Hash password with SHA-256 and salt using Web Crypto API or Node crypto
 */
export declare function hashPasswordClient(password: string, salt: string): Promise<string>;
/**
 * Retrieve the active user session from browser storage
 */
export declare function getUserSession(): UserSession | null;
/**
 * Decode a Google Identity Services (GIS) JWT credential token
 */
export declare function decodeGoogleCredential(credentialToken: string): {
    email: string;
    name: string;
    picture?: string;
    sub: string;
} | null;
/**
 * Register a new user account with real password validation
 */
export declare function registerUser(credentials: {
    email: string;
    password: string;
    name?: string;
    organization?: string;
}): Promise<UserSession>;
/**
 * Log in an existing user with email and password verification
 */
export declare function loginWithPassword(credentials: {
    email: string;
    password: string;
}): Promise<UserSession>;
/**
 * Log in directly using an authentic Google OAuth credential token
 */
export declare function loginWithGoogleCredential(credentialToken: string): Promise<UserSession | null>;
/**
 * Authenticate the user with chosen identity provider (maintained for backward-compatible test suites)
 */
export declare function loginUser(provider: 'github' | 'google' | 'microsoft' | 'email', details?: {
    email?: string;
    name?: string;
    organization?: string;
    avatarUrl?: string;
}): Promise<UserSession>;
/**
 * Sign out and clear stored session
 */
export declare function logoutUser(): void;
/**
 * Update the user's active session profile
 */
export declare function updateUserProfile(updates: Partial<UserSession>): UserSession | null;
//# sourceMappingURL=accountManager.d.ts.map