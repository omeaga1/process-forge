import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Component } from 'react';
import { AlertTriangle, RotateCcw, Home } from 'lucide-react';
export class StudioErrorBoundary extends Component {
    state = {
        hasError: false,
        error: null
    };
    static getDerivedStateFromError(error) {
        return { hasError: true, error };
    }
    componentDidCatch(error, errorInfo) {
        console.error('[ProcessForge Studio] Caught unhandled rendering error:', error, errorInfo);
    }
    handleReset = () => {
        this.setState({ hasError: false, error: null });
        window.location.reload();
    };
    handleReturnToLanding = () => {
        this.setState({ hasError: false, error: null });
        try {
            localStorage.removeItem('pf_current_project');
        }
        catch { }
        window.location.href = window.location.pathname;
    };
    render() {
        if (this.state.hasError) {
            return (_jsx("div", { style: {
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    width: '100vw',
                    height: '100vh',
                    backgroundColor: '#11221c',
                    color: '#f6f5dd',
                    fontFamily: "'Inter', sans-serif",
                    padding: 24,
                    boxSizing: 'border-box',
                    textAlign: 'center'
                }, children: _jsxs("div", { style: {
                        maxWidth: 580,
                        width: '100%',
                        backgroundColor: '#16241f',
                        border: '1px solid #e5c736',
                        borderRadius: 8,
                        padding: 28,
                        boxShadow: '0 12px 40px rgba(0, 0, 0, 0.6), 0 0 20px rgba(229, 199, 54, 0.15)',
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        gap: 16
                    }, children: [_jsx("div", { style: {
                                width: 48,
                                height: 48,
                                borderRadius: '50%',
                                backgroundColor: 'rgba(229, 199, 54, 0.15)',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                color: '#e5c736'
                            }, children: _jsx(AlertTriangle, { size: 26 }) }), _jsx("h2", { style: { margin: 0, fontSize: 18, fontWeight: 700, letterSpacing: '-0.01em' }, children: "Studio Interface Recovery" }), _jsx("p", { style: { margin: 0, fontSize: 13, color: '#c1c497', lineHeight: 1.5 }, children: "ProcessForge encountered an unexpected error while rendering the interactive studio canvas." }), this.state.error && (_jsx("div", { style: {
                                width: '100%',
                                textAlign: 'left',
                                backgroundColor: '#111c18',
                                border: '1px solid #253c33',
                                borderRadius: 6,
                                padding: '10px 14px',
                                fontSize: 12,
                                fontFamily: "'JetBrains Mono', monospace",
                                color: '#ff7b72',
                                overflowX: 'auto',
                                maxHeight: 120,
                                boxSizing: 'border-box'
                            }, children: this.state.error.message || String(this.state.error) })), _jsxs("div", { style: { display: 'flex', gap: 12, marginTop: 8 }, children: [_jsxs("button", { onClick: this.handleReturnToLanding, style: {
                                        display: 'inline-flex',
                                        alignItems: 'center',
                                        gap: 8,
                                        padding: '10px 18px',
                                        borderRadius: 4,
                                        backgroundColor: '#549e6a',
                                        color: '#111c18',
                                        border: 'none',
                                        fontSize: 13,
                                        fontWeight: 700,
                                        cursor: 'pointer'
                                    }, children: [_jsx(Home, { size: 15 }), "Return to Dashboard"] }), _jsxs("button", { onClick: this.handleReset, style: {
                                        display: 'inline-flex',
                                        alignItems: 'center',
                                        gap: 8,
                                        padding: '10px 18px',
                                        borderRadius: 4,
                                        backgroundColor: '#1d2f28',
                                        color: '#f6f5dd',
                                        border: '1px solid #253c33',
                                        fontSize: 13,
                                        fontWeight: 600,
                                        cursor: 'pointer'
                                    }, children: [_jsx(RotateCcw, { size: 14 }), "Reload Studio"] })] })] }) }));
        }
        return this.props.children;
    }
}
//# sourceMappingURL=StudioErrorBoundary.js.map