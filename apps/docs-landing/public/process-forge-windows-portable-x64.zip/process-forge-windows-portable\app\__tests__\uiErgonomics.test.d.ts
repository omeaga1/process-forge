export {};
//# sourceMappingURL=uiErgonomics.test.d.ts.map