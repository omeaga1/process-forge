import React from 'react';
interface StudioEntryGateModalProps {
    isOpen: boolean;
    onClose: () => void;
    onOpenAccountModal: () => void;
    onContinueGuest: () => void;
}
export declare const StudioEntryGateModal: React.FC<StudioEntryGateModalProps>;
export {};
//# sourceMappingURL=StudioEntryGateModal.d.ts.map