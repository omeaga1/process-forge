import { type SimulationProject } from '@process-forge/protocol';
import type { UserSession } from '../auth/accountManager.js';
export interface CloudProjectRecord {
    id: string;
    name: string;
    description: string;
    userId: string;
    authorName: string;
    nodeCount: number;
    streamCount: number;
    createdAt: string;
    updatedAt: string;
    syncStatus: 'synced' | 'syncing' | 'failed';
    bundle: SimulationProject;
}
/**
 * Lists all projects stored in the cloud for the active user
 */
export declare function listUserCloudProjects(user?: UserSession | null): Promise<CloudProjectRecord[]>;
/**
 * Saves a simulation project to ProcessForge Cloud Storage
 */
export declare function saveProjectToCloud(project: SimulationProject, user?: UserSession | null): Promise<{
    success: boolean;
    cloudRecord: CloudProjectRecord;
    message: string;
}>;
/**
 * Loads a full simulation project from Cloud Storage by ID
 */
export declare function loadProjectFromCloud(projectId: string, user?: UserSession | null): Promise<SimulationProject | null>;
/**
 * Deletes a project from Cloud Storage
 */
export declare function deleteProjectFromCloud(projectId: string, user?: UserSession | null): Promise<boolean>;
//# sourceMappingURL=cloudStorageAdapter.d.ts.map