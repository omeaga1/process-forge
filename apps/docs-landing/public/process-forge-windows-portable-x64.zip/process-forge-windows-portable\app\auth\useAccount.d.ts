import React, { ReactNode } from 'react';
import { type UserSession } from './accountManager.js';
interface AccountContextValue {
    user: UserSession | null;
    isAuthenticated: boolean;
    isAccountModalOpen: boolean;
    openAccountModal: () => void;
    closeAccountModal: () => void;
    register: (credentials: {
        email: string;
        password: string;
        name?: string;
        organization?: string;
    }) => Promise<UserSession>;
    login: (credentials: {
        email: string;
        password: string;
    }) => Promise<UserSession>;
    signIn: (provider: 'github' | 'google' | 'microsoft' | 'email', details?: {
        email?: string;
        name?: string;
        organization?: string;
        avatarUrl?: string;
    }) => Promise<UserSession>;
    signInWithGoogleCredential: (credentialToken: string) => Promise<UserSession | null>;
    signOut: () => void;
    updateProfile: (updates: Partial<UserSession>) => void;
}
export interface AccountProviderProps {
    children: ReactNode;
}
export declare const AccountProvider: React.FC<AccountProviderProps>;
export declare function useAccount(): AccountContextValue;
export {};
//# sourceMappingURL=useAccount.d.ts.map