import React from 'react';
interface HeaderBarProps {
    currentTemplate: string;
    isGuestMode: boolean;
    activeAiProvider?: string;
    onNavigateHome?: () => void;
    onSelectTemplate: (templateKey: string) => void;
    onOpenAiModal?: () => void;
    onOpenForgeHub: () => void;
    onOpenSaveModal: () => void;
    onOpenGuestModal: () => void;
    onImportFile: (file: File) => void;
    onOpenAccountModal?: () => void;
    onOpenCloudProjects?: () => void;
    onCheckForUpdates?: () => void;
    isCheckingUpdates?: boolean;
    hasUpdateAvailable?: boolean;
}
export declare const HeaderBar: React.FC<HeaderBarProps>;
export {};
//# sourceMappingURL=HeaderBar.d.ts.map