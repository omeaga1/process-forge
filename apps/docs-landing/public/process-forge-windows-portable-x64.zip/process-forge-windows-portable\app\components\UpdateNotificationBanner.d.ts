import React from 'react';
export interface UpdateInfo {
    current_version: string;
    latest_version: string;
    should_update: boolean;
    release_notes: string;
    release_url: string;
}
export type UpdaterStatus = 'idle' | 'checking' | 'available' | 'up-to-date' | 'installing' | 'restarting' | 'error';
export interface UpdateBannerProps {
    status?: UpdaterStatus;
    updateInfo?: UpdateInfo | null;
    statusMessage?: string | null;
    onDismiss?: () => void;
    onCheckForUpdates?: () => Promise<void>;
    onRestartAndApply?: () => Promise<void>;
    onHardReload?: () => void;
}
export declare function isTauriEnvironment(): boolean;
export declare function invokeTauriCommand<T>(cmd: string, args?: Record<string, unknown>): Promise<T>;
export declare const UpdateNotificationBanner: React.FC<UpdateBannerProps>;
//# sourceMappingURL=UpdateNotificationBanner.d.ts.map