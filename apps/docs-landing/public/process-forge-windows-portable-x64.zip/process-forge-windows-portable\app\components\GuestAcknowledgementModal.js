import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { ShieldCheck, Download, ArrowRight, X, Cloud } from 'lucide-react';
import { useTheme } from '@process-forge/canvas-ui';
export const GuestAcknowledgementModal = ({ isOpen, onClose, onExportFile, onOpenAccountModal }) => {
    const { palette } = useTheme();
    const OsakaJadePalette = palette;
    if (!isOpen)
        return null;
    return (_jsx("div", { style: {
            position: 'fixed',
            inset: 0,
            backgroundColor: 'rgba(5, 10, 12, 0.85)',
            backdropFilter: 'blur(8px)',
            zIndex: 10000,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: 20
        }, children: _jsxs("div", { style: {
                width: 580,
                maxWidth: '100%',
                maxHeight: 'min(90vh, calc(100vh - 40px))',
                backgroundColor: OsakaJadePalette.background.surface,
                border: `1px solid ${OsakaJadePalette.border.default}`,
                borderRadius: 12,
                boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.8)',
                overflow: 'hidden',
                display: 'flex',
                flexDirection: 'column'
            }, children: [_jsxs("div", { style: {
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        padding: '16px 20px',
                        backgroundColor: OsakaJadePalette.background.canvas,
                        borderBottom: `1px solid ${OsakaJadePalette.border.subtle}`
                    }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 10 }, children: [_jsx("div", { style: {
                                        width: 32,
                                        height: 32,
                                        borderRadius: 8,
                                        backgroundColor: 'rgba(16, 185, 129, 0.15)',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        color: OsakaJadePalette.jade[500]
                                    }, children: _jsx(Cloud, { size: 18 }) }), _jsxs("div", { children: [_jsx("h3", { style: { margin: 0, fontSize: 16, fontWeight: 700, color: OsakaJadePalette.text.primary }, children: "ProcessForge Cloud & Storage" }), _jsx("span", { style: { fontSize: 12, color: OsakaJadePalette.text.secondary }, children: "Preserve your simulation digital twin" })] })] }), _jsx("button", { onClick: onClose, style: {
                                background: 'none',
                                border: 'none',
                                color: OsakaJadePalette.text.muted,
                                cursor: 'pointer',
                                padding: 4
                            }, children: _jsx(X, { size: 18 }) })] }), _jsxs("div", { style: { padding: 24, display: 'flex', flexDirection: 'column', gap: 16, overflowY: 'auto' }, children: [_jsx("p", { style: { margin: 0, fontSize: 14, lineHeight: 1.6, color: OsakaJadePalette.text.primary }, children: "Welcome to ProcessForge. You have full access to the digital twin flowsheet canvas, the deterministic fluid/discrete simulation engine, and Sub-Agent machine tools." }), _jsxs("div", { style: { display: 'flex', flexDirection: 'column', gap: 10 }, children: [_jsx("span", { style: { fontSize: 12, fontWeight: 600, textTransform: 'uppercase', color: OsakaJadePalette.text.muted }, children: "Cloud & Storage Options:" }), _jsxs("div", { style: {
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'space-between',
                                        padding: 14,
                                        backgroundColor: 'rgba(16, 185, 129, 0.08)',
                                        border: `1px solid ${OsakaJadePalette.jade[600]}`,
                                        borderRadius: 8
                                    }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 10 }, children: [_jsx(Cloud, { size: 20, color: OsakaJadePalette.jade[400] }), _jsxs("div", { children: [_jsxs("div", { style: { fontSize: 13, fontWeight: 700, color: OsakaJadePalette.text.primary, display: 'flex', alignItems: 'center', gap: 6 }, children: ["ProcessForge Cloud Storage", _jsx("span", { style: {
                                                                        fontSize: 9,
                                                                        fontWeight: 700,
                                                                        padding: '1px 6px',
                                                                        borderRadius: 10,
                                                                        backgroundColor: OsakaJadePalette.jade[500],
                                                                        color: OsakaJadePalette.text.inverse
                                                                    }, children: "RECOMMENDED" })] }), _jsx("div", { style: { fontSize: 11, color: OsakaJadePalette.text.secondary, marginTop: 2 }, children: "Sign in with GitHub, Google, or Email to automatically sync simulations across devices." })] })] }), _jsx("button", { onClick: () => {
                                                onClose();
                                                onOpenAccountModal?.();
                                            }, style: {
                                                padding: '7px 14px',
                                                backgroundColor: OsakaJadePalette.jade[500],
                                                border: 'none',
                                                borderRadius: 6,
                                                color: OsakaJadePalette.text.inverse,
                                                fontSize: 12,
                                                fontWeight: 700,
                                                cursor: 'pointer',
                                                whiteSpace: 'nowrap'
                                            }, children: "Sign In" })] }), _jsxs("div", { style: {
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'space-between',
                                        padding: 14,
                                        backgroundColor: OsakaJadePalette.background.canvas,
                                        border: `1px solid ${OsakaJadePalette.border.subtle}`,
                                        borderRadius: 8
                                    }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 10 }, children: [_jsx(Download, { size: 18, color: OsakaJadePalette.text.secondary }), _jsxs("div", { children: [_jsx("div", { style: { fontSize: 13, fontWeight: 600, color: OsakaJadePalette.text.primary }, children: "Download Project File (.pfg.json)" }), _jsx("div", { style: { fontSize: 11, color: OsakaJadePalette.text.secondary }, children: "Export a standalone digital twin JSON file to your disk anytime." })] })] }), _jsx("button", { onClick: () => {
                                                onExportFile();
                                                onClose();
                                            }, style: {
                                                padding: '6px 12px',
                                                backgroundColor: 'rgba(255, 255, 255, 0.06)',
                                                border: `1px solid ${OsakaJadePalette.border.default}`,
                                                borderRadius: 6,
                                                color: OsakaJadePalette.text.primary,
                                                fontSize: 12,
                                                fontWeight: 600,
                                                cursor: 'pointer',
                                                whiteSpace: 'nowrap'
                                            }, children: "Download File" })] })] })] }), _jsxs("div", { style: {
                        padding: '14px 20px',
                        backgroundColor: OsakaJadePalette.background.canvas,
                        borderTop: `1px solid ${OsakaJadePalette.border.subtle}`,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between'
                    }, children: [_jsxs("span", { style: { display: 'flex', alignItems: 'center', gap: 6, fontSize: 11, color: OsakaJadePalette.text.muted }, children: [_jsx(ShieldCheck, { size: 14, color: OsakaJadePalette.jade[500] }), "Zero Raw Keys Architecture"] }), _jsxs("button", { onClick: onClose, style: {
                                display: 'flex',
                                alignItems: 'center',
                                gap: 6,
                                padding: '8px 16px',
                                backgroundColor: OsakaJadePalette.background.surfaceElevated,
                                border: `1px solid ${OsakaJadePalette.border.default}`,
                                borderRadius: 6,
                                color: OsakaJadePalette.text.primary,
                                fontWeight: 600,
                                fontSize: 13,
                                cursor: 'pointer'
                            }, children: ["Continue", _jsx(ArrowRight, { size: 14 })] })] })] }) }));
};
//# sourceMappingURL=GuestAcknowledgementModal.js.map