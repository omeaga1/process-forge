import { UpdateInfo, UpdaterStatus } from '../components/UpdateNotificationBanner.js';
export interface UseAppUpdaterReturn {
    status: UpdaterStatus;
    updateInfo: UpdateInfo | null;
    statusMessage: string | null;
    isChecking: boolean;
    hasUpdate: boolean;
    checkForUpdates: (isManual?: boolean) => Promise<void>;
    restartAndApplyUpdate: () => Promise<void>;
    hardReloadApp: () => void;
    dismissNotification: () => void;
}
export declare function useAppUpdater(): UseAppUpdaterReturn;
//# sourceMappingURL=useAppUpdater.d.ts.map