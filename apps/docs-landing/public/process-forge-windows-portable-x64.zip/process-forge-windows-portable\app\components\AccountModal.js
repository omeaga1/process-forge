import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState, useEffect, useRef } from 'react';
import { User, LogOut, Cloud, X, Building2, Mail, Lock, Eye, EyeOff, ArrowRight, AlertCircle, KeyRound, CheckCircle2, ExternalLink, Copy, Sparkles } from 'lucide-react';
import { useTheme } from '@process-forge/canvas-ui';
import { useAccount } from '../auth/useAccount.js';
import { getInitials } from '../auth/accountManager.js';
export const AccountModal = ({ isOpen, onClose, onOpenCloudProjects }) => {
    const { palette } = useTheme();
    const OsakaJadePalette = palette;
    const { user, isAuthenticated, login, register, signInWithGoogleCredential, signOut } = useAccount();
    // Auth Mode: 'signin' | 'register'
    const [authMode, setAuthMode] = useState('signin');
    // Provider Tab: 'email' | 'google'
    const [activeTab, setActiveTab] = useState('email');
    // Form inputs
    const [emailInput, setEmailInput] = useState('');
    const [passwordInput, setPasswordInput] = useState('');
    const [confirmPasswordInput, setConfirmPasswordInput] = useState('');
    const [nameInput, setNameInput] = useState('');
    const [orgInput, setOrgInput] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    // Google inputs & client state
    const [googleCredentialInput, setGoogleCredentialInput] = useState('');
    const [googleClientId, setGoogleClientId] = useState(() => {
        return (import.meta.env?.VITE_GOOGLE_CLIENT_ID ||
            (typeof localStorage !== 'undefined' ? localStorage.getItem('pf_google_client_id') || '' : ''));
    });
    const [customClientIdInput, setCustomClientIdInput] = useState('');
    const [isEditingClientId, setIsEditingClientId] = useState(false);
    const [copiedOrigin, setCopiedOrigin] = useState(null);
    const [showAdvancedToken, setShowAdvancedToken] = useState(false);
    const googleButtonContainerRef = useRef(null);
    // Status state
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [errorMessage, setErrorMessage] = useState(null);
    const [successMessage, setSuccessMessage] = useState(null);
    // Initialize Google Identity Services (GIS) when Google tab is active and client ID is present
    useEffect(() => {
        if (!isOpen || activeTab !== 'google' || !googleClientId)
            return;
        const gis = window.google?.accounts?.id;
        if (!gis)
            return;
        try {
            gis.initialize({
                client_id: googleClientId,
                callback: async (response) => {
                    if (response.credential) {
                        setIsSubmitting(true);
                        try {
                            const session = await signInWithGoogleCredential(response.credential);
                            if (session) {
                                setSuccessMessage(`Welcome, ${session.name}! Signed in with Google.`);
                                setTimeout(() => {
                                    setIsSubmitting(false);
                                    onClose();
                                }, 800);
                            }
                        }
                        catch (err) {
                            setErrorMessage(err.message || 'Failed to authenticate Google credential.');
                            setIsSubmitting(false);
                        }
                    }
                },
                auto_select: false,
                cancel_on_tap_outside: true
            });
            if (googleButtonContainerRef.current) {
                googleButtonContainerRef.current.innerHTML = '';
                gis.renderButton(googleButtonContainerRef.current, {
                    theme: 'outline',
                    size: 'large',
                    type: 'standard',
                    text: 'continue_with',
                    shape: 'rectangular',
                    logo_alignment: 'left',
                    width: 320
                });
            }
            // Automatically prompt One Tap dialog
            gis.prompt();
        }
        catch (e) {
            console.warn('GIS initialization error:', e);
        }
    }, [isOpen, activeTab, googleClientId]);
    if (!isOpen)
        return null;
    const handleSaveClientId = (e) => {
        e.preventDefault();
        const cleaned = customClientIdInput.trim();
        if (!cleaned)
            return;
        if (typeof localStorage !== 'undefined') {
            localStorage.setItem('pf_google_client_id', cleaned);
        }
        setGoogleClientId(cleaned);
        setIsEditingClientId(false);
        setSuccessMessage('Google Client ID activated! Google Sign-In is ready.');
        setTimeout(() => setSuccessMessage(null), 3000);
    };
    const handleCopyOrigin = (origin) => {
        navigator.clipboard.writeText(origin);
        setCopiedOrigin(origin);
        setTimeout(() => setCopiedOrigin(null), 2000);
    };
    const handleEmailSubmit = async (e) => {
        e.preventDefault();
        setErrorMessage(null);
        setSuccessMessage(null);
        setIsSubmitting(true);
        if (authMode === 'register') {
            if (passwordInput !== confirmPasswordInput) {
                setErrorMessage('Passwords do not match.');
                setIsSubmitting(false);
                return;
            }
            try {
                await register({
                    email: emailInput.trim(),
                    password: passwordInput,
                    name: nameInput.trim() || undefined,
                    organization: orgInput.trim() || undefined
                });
                setSuccessMessage('Account created successfully! Welcome to ProcessForge.');
                setTimeout(() => {
                    setIsSubmitting(false);
                    onClose();
                }, 800);
            }
            catch (err) {
                setErrorMessage(err.message || 'Registration failed.');
                setIsSubmitting(false);
            }
        }
        else {
            try {
                await login({ email: emailInput.trim(), password: passwordInput });
                setSuccessMessage('Signed in successfully!');
                setTimeout(() => {
                    setIsSubmitting(false);
                    onClose();
                }, 800);
            }
            catch (err) {
                setErrorMessage(err.message || 'Invalid email or password.');
                setIsSubmitting(false);
            }
        }
    };
    const handleGoogleOneTap = () => {
        setErrorMessage(null);
        const gis = window.google?.accounts?.id;
        if (gis && googleClientId) {
            try {
                gis.prompt();
                return;
            }
            catch (e) {
                console.warn('Google One Tap prompt failed:', e);
            }
        }
        if (!googleClientId) {
            setIsEditingClientId(true);
            setErrorMessage('Please enter your Google Client ID below to enable Google One Tap.');
        }
    };
    const handleGoogleTokenSubmit = async (e) => {
        e.preventDefault();
        if (!googleCredentialInput.trim())
            return;
        setIsSubmitting(true);
        setErrorMessage(null);
        try {
            const session = await signInWithGoogleCredential(googleCredentialInput.trim());
            if (session) {
                setSuccessMessage('Authenticated with Google token!');
                setTimeout(() => {
                    setIsSubmitting(false);
                    onClose();
                }, 800);
            }
            else {
                setErrorMessage('Invalid Google OAuth token. Could not decode profile.');
                setIsSubmitting(false);
            }
        }
        catch (e) {
            setErrorMessage(e.message || 'Failed to sign in with Google token.');
            setIsSubmitting(false);
        }
    };
    return (_jsx("div", { style: {
            position: 'fixed',
            inset: 0,
            backgroundColor: 'rgba(5, 10, 12, 0.85)',
            backdropFilter: 'blur(8px)',
            zIndex: 10000,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: 16
        }, onClick: onClose, children: _jsxs("div", { style: {
                width: '100%',
                maxWidth: 520,
                backgroundColor: OsakaJadePalette.background.surface,
                border: `1px solid ${OsakaJadePalette.border.default}`,
                borderRadius: 12,
                boxShadow: '0 24px 48px rgba(0, 0, 0, 0.5)',
                display: 'flex',
                flexDirection: 'column',
                overflow: 'hidden',
                animation: 'fadeIn 0.15s ease-out'
            }, onClick: (e) => e.stopPropagation(), children: [_jsxs("div", { style: {
                        padding: '16px 20px',
                        backgroundColor: OsakaJadePalette.background.canvas,
                        borderBottom: `1px solid ${OsakaJadePalette.border.default}`,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between'
                    }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 10 }, children: [_jsx("div", { style: {
                                        width: 32,
                                        height: 32,
                                        borderRadius: 8,
                                        backgroundColor: OsakaJadePalette.jade.muted,
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        border: `1px solid ${OsakaJadePalette.jade[600]}`
                                    }, children: _jsx(User, { size: 18, color: OsakaJadePalette.jade[400] }) }), _jsxs("div", { children: [_jsx("div", { style: { fontSize: 15, fontWeight: 700, color: OsakaJadePalette.text.primary }, children: isAuthenticated ? 'Engineer Profile & Cloud Sync' : 'ProcessForge Account' }), _jsx("div", { style: { fontSize: 11, color: OsakaJadePalette.text.muted }, children: isAuthenticated ? 'Manage session & cloud storage quota' : 'Password-secured authentication for cloud digital twins' })] })] }), _jsx("button", { onClick: onClose, style: {
                                background: 'none',
                                border: 'none',
                                color: OsakaJadePalette.text.muted,
                                cursor: 'pointer',
                                padding: 4
                            }, children: _jsx(X, { size: 18 }) })] }), _jsx("div", { style: { padding: 20 }, children: isAuthenticated && user ? (
                    /* ── AUTHENTICATED PROFILE VIEW ── */
                    _jsxs("div", { style: { display: 'flex', flexDirection: 'column', gap: 18 }, children: [_jsxs("div", { style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: 16,
                                    padding: 16,
                                    backgroundColor: OsakaJadePalette.background.canvas,
                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                    borderRadius: 10
                                }, children: [_jsx("div", { style: {
                                            width: 56,
                                            height: 56,
                                            borderRadius: 28,
                                            overflow: 'hidden',
                                            backgroundColor: OsakaJadePalette.jade[600],
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            color: '#fff',
                                            fontWeight: 700,
                                            fontSize: 20,
                                            flexShrink: 0,
                                            border: `2px solid ${OsakaJadePalette.jade[400]}`
                                        }, children: user.avatarUrl && !user.avatarUrl.includes('images.unsplash.com') ? (_jsx("img", { src: user.avatarUrl, alt: user.name, style: { width: '100%', height: '100%', objectFit: 'cover' }, onError: (e) => {
                                                // Fallback to text initials if image fails
                                                e.currentTarget.style.display = 'none';
                                            } })) : (_jsx("span", { children: getInitials(user.name, user.email) })) }), _jsxs("div", { style: { flex: 1, minWidth: 0 }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 8 }, children: [_jsx("div", { style: { fontSize: 16, fontWeight: 700, color: OsakaJadePalette.text.primary, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }, children: user.name }), _jsx("span", { style: {
                                                            padding: '2px 8px',
                                                            borderRadius: 10,
                                                            backgroundColor: 'rgba(16, 185, 129, 0.15)',
                                                            border: `1px solid ${OsakaJadePalette.jade[600]}`,
                                                            color: OsakaJadePalette.text.accent,
                                                            fontSize: 10,
                                                            fontWeight: 700
                                                        }, children: user.plan })] }), _jsx("div", { style: { fontSize: 12, color: OsakaJadePalette.text.muted, marginTop: 2 }, children: user.email }), _jsxs("div", { style: { fontSize: 11, color: OsakaJadePalette.text.secondary, marginTop: 4, display: 'flex', alignItems: 'center', gap: 5 }, children: [_jsx(Building2, { size: 12 }), _jsx("span", { children: user.organization || 'Process Engineering' }), _jsx("span", { children: "\u2022" }), _jsxs("span", { style: { textTransform: 'capitalize' }, children: [user.provider, " Account"] })] })] })] }), _jsxs("div", { style: {
                                    padding: 14,
                                    backgroundColor: OsakaJadePalette.background.canvas,
                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                    borderRadius: 10
                                }, children: [_jsxs("div", { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, fontWeight: 600, color: OsakaJadePalette.text.primary }, children: [_jsx(Cloud, { size: 14, color: OsakaJadePalette.jade[400] }), _jsx("span", { children: "Cloud Storage Capacity" })] }), _jsxs("div", { style: { fontSize: 11, color: OsakaJadePalette.text.muted }, children: [user.cloudStorageQuota?.usedProjects || 0, " / ", user.cloudStorageQuota?.maxProjects || 50, " Simulations"] })] }), _jsx("div", { style: {
                                            width: '100%',
                                            height: 6,
                                            borderRadius: 3,
                                            backgroundColor: 'rgba(255, 255, 255, 0.08)',
                                            overflow: 'hidden'
                                        }, children: _jsx("div", { style: {
                                                width: `${Math.min(100, (((user.cloudStorageQuota?.usedProjects || 0)) / (user.cloudStorageQuota?.maxProjects || 50)) * 100)}%`,
                                                height: '100%',
                                                backgroundColor: OsakaJadePalette.jade[500],
                                                borderRadius: 3
                                            } }) })] }), _jsxs("div", { style: { display: 'flex', gap: 10 }, children: [onOpenCloudProjects && (_jsxs("button", { onClick: () => {
                                            onClose();
                                            onOpenCloudProjects();
                                        }, style: {
                                            flex: 1,
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            gap: 8,
                                            padding: '10px 14px',
                                            borderRadius: 8,
                                            backgroundColor: OsakaJadePalette.jade[600],
                                            border: 'none',
                                            color: '#fff',
                                            fontSize: 13,
                                            fontWeight: 600,
                                            cursor: 'pointer'
                                        }, children: [_jsx(Cloud, { size: 15 }), _jsx("span", { children: "Browse Cloud Projects" })] })), _jsxs("button", { onClick: signOut, style: {
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            gap: 6,
                                            padding: '10px 16px',
                                            borderRadius: 8,
                                            backgroundColor: 'rgba(239, 68, 68, 0.1)',
                                            border: '1px solid rgba(239, 68, 68, 0.3)',
                                            color: '#f87171',
                                            fontSize: 13,
                                            fontWeight: 600,
                                            cursor: 'pointer'
                                        }, children: [_jsx(LogOut, { size: 15 }), _jsx("span", { children: "Sign Out" })] })] })] })) : (
                    /* ── UNAUTHENTICATED SIGN IN / REGISTER VIEW ── */
                    _jsxs("div", { children: [_jsxs("div", { style: {
                                    display: 'flex',
                                    backgroundColor: OsakaJadePalette.background.canvas,
                                    borderRadius: 8,
                                    padding: 3,
                                    marginBottom: 16
                                }, children: [_jsxs("button", { onClick: () => {
                                            setActiveTab('email');
                                            setErrorMessage(null);
                                        }, style: {
                                            flex: 1,
                                            padding: '8px 12px',
                                            borderRadius: 6,
                                            border: 'none',
                                            backgroundColor: activeTab === 'email' ? OsakaJadePalette.background.surface : 'transparent',
                                            color: activeTab === 'email' ? OsakaJadePalette.text.primary : OsakaJadePalette.text.secondary,
                                            fontSize: 12,
                                            fontWeight: 600,
                                            cursor: 'pointer',
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            gap: 6
                                        }, children: [_jsx(Mail, { size: 14 }), _jsx("span", { children: "Email & Password" })] }), _jsxs("button", { onClick: () => {
                                            setActiveTab('google');
                                            setErrorMessage(null);
                                        }, style: {
                                            flex: 1,
                                            padding: '8px 12px',
                                            borderRadius: 6,
                                            border: 'none',
                                            backgroundColor: activeTab === 'google' ? OsakaJadePalette.background.surface : 'transparent',
                                            color: activeTab === 'google' ? OsakaJadePalette.text.primary : OsakaJadePalette.text.secondary,
                                            fontSize: 12,
                                            fontWeight: 600,
                                            cursor: 'pointer',
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            gap: 6
                                        }, children: [_jsx(KeyRound, { size: 14 }), _jsx("span", { children: "Google Account" })] })] }), errorMessage && (_jsxs("div", { style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: 8,
                                    padding: '10px 12px',
                                    borderRadius: 6,
                                    backgroundColor: 'rgba(239, 68, 68, 0.12)',
                                    border: '1px solid rgba(239, 68, 68, 0.3)',
                                    color: '#f87171',
                                    fontSize: 12,
                                    marginBottom: 14
                                }, children: [_jsx(AlertCircle, { size: 15, style: { flexShrink: 0 } }), _jsx("span", { children: errorMessage })] })), successMessage && (_jsxs("div", { style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: 8,
                                    padding: '10px 12px',
                                    borderRadius: 6,
                                    backgroundColor: 'rgba(16, 185, 129, 0.15)',
                                    border: `1px solid ${OsakaJadePalette.jade[600]}`,
                                    color: OsakaJadePalette.text.accent,
                                    fontSize: 12,
                                    marginBottom: 14
                                }, children: [_jsx(CheckCircle2, { size: 15, style: { flexShrink: 0 } }), _jsx("span", { children: successMessage })] })), activeTab === 'email' ? (
                            /* ── EMAIL & PASSWORD FORM ── */
                            _jsxs("div", { children: [_jsxs("div", { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }, children: [_jsx("span", { style: { fontSize: 13, fontWeight: 700, color: OsakaJadePalette.text.primary }, children: authMode === 'signin' ? 'Sign In to Your Account' : 'Create New Engineer Account' }), _jsx("button", { type: "button", onClick: () => {
                                                    setAuthMode(authMode === 'signin' ? 'register' : 'signin');
                                                    setErrorMessage(null);
                                                }, style: {
                                                    background: 'none',
                                                    border: 'none',
                                                    color: OsakaJadePalette.jade.glow,
                                                    fontSize: 11,
                                                    fontWeight: 600,
                                                    cursor: 'pointer'
                                                }, children: authMode === 'signin' ? 'Need an account? Register →' : 'Already registered? Sign In →' })] }), _jsxs("form", { onSubmit: handleEmailSubmit, style: { display: 'flex', flexDirection: 'column', gap: 12 }, children: [_jsxs("div", { children: [_jsx("label", { style: { display: 'block', fontSize: 11, fontWeight: 600, color: OsakaJadePalette.text.secondary, marginBottom: 4 }, children: "Work Email" }), _jsxs("div", { style: { position: 'relative' }, children: [_jsx(Mail, { size: 15, color: OsakaJadePalette.text.muted, style: { position: 'absolute', left: 10, top: 11 } }), _jsx("input", { type: "email", required: true, value: emailInput, onChange: (e) => setEmailInput(e.target.value), placeholder: "engineer@company.com", style: {
                                                                    width: '100%',
                                                                    boxSizing: 'border-box',
                                                                    backgroundColor: OsakaJadePalette.background.canvas,
                                                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                                                    borderRadius: 6,
                                                                    padding: '8px 10px 8px 34px',
                                                                    color: OsakaJadePalette.text.primary,
                                                                    fontSize: 13,
                                                                    outline: 'none'
                                                                } })] })] }), authMode === 'register' && (_jsxs("div", { style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }, children: [_jsxs("div", { children: [_jsx("label", { style: { display: 'block', fontSize: 11, fontWeight: 600, color: OsakaJadePalette.text.secondary, marginBottom: 4 }, children: "Full Name" }), _jsx("input", { type: "text", value: nameInput, onChange: (e) => setNameInput(e.target.value), placeholder: "Alex Vance", style: {
                                                                    width: '100%',
                                                                    boxSizing: 'border-box',
                                                                    backgroundColor: OsakaJadePalette.background.canvas,
                                                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                                                    borderRadius: 6,
                                                                    padding: '8px 10px',
                                                                    color: OsakaJadePalette.text.primary,
                                                                    fontSize: 13,
                                                                    outline: 'none'
                                                                } })] }), _jsxs("div", { children: [_jsx("label", { style: { display: 'block', fontSize: 11, fontWeight: 600, color: OsakaJadePalette.text.secondary, marginBottom: 4 }, children: "Organization" }), _jsx("input", { type: "text", value: orgInput, onChange: (e) => setOrgInput(e.target.value), placeholder: "Process Engineering", style: {
                                                                    width: '100%',
                                                                    boxSizing: 'border-box',
                                                                    backgroundColor: OsakaJadePalette.background.canvas,
                                                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                                                    borderRadius: 6,
                                                                    padding: '8px 10px',
                                                                    color: OsakaJadePalette.text.primary,
                                                                    fontSize: 13,
                                                                    outline: 'none'
                                                                } })] })] })), _jsxs("div", { children: [_jsxs("label", { style: { display: 'block', fontSize: 11, fontWeight: 600, color: OsakaJadePalette.text.secondary, marginBottom: 4 }, children: ["Password ", authMode === 'register' && '(minimum 8 characters)'] }), _jsxs("div", { style: { position: 'relative' }, children: [_jsx(Lock, { size: 15, color: OsakaJadePalette.text.muted, style: { position: 'absolute', left: 10, top: 11 } }), _jsx("input", { type: showPassword ? 'text' : 'password', required: true, value: passwordInput, onChange: (e) => setPasswordInput(e.target.value), placeholder: "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022", style: {
                                                                    width: '100%',
                                                                    boxSizing: 'border-box',
                                                                    backgroundColor: OsakaJadePalette.background.canvas,
                                                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                                                    borderRadius: 6,
                                                                    padding: '8px 36px 8px 34px',
                                                                    color: OsakaJadePalette.text.primary,
                                                                    fontSize: 13,
                                                                    outline: 'none'
                                                                } }), _jsx("button", { type: "button", onClick: () => setShowPassword(!showPassword), style: {
                                                                    position: 'absolute',
                                                                    right: 8,
                                                                    top: 8,
                                                                    background: 'none',
                                                                    border: 'none',
                                                                    color: OsakaJadePalette.text.muted,
                                                                    cursor: 'pointer',
                                                                    padding: 2
                                                                }, children: showPassword ? _jsx(EyeOff, { size: 15 }) : _jsx(Eye, { size: 15 }) })] })] }), authMode === 'register' && (_jsxs("div", { children: [_jsx("label", { style: { display: 'block', fontSize: 11, fontWeight: 600, color: OsakaJadePalette.text.secondary, marginBottom: 4 }, children: "Confirm Password" }), _jsxs("div", { style: { position: 'relative' }, children: [_jsx(Lock, { size: 15, color: OsakaJadePalette.text.muted, style: { position: 'absolute', left: 10, top: 11 } }), _jsx("input", { type: showPassword ? 'text' : 'password', required: true, value: confirmPasswordInput, onChange: (e) => setConfirmPasswordInput(e.target.value), placeholder: "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022", style: {
                                                                    width: '100%',
                                                                    boxSizing: 'border-box',
                                                                    backgroundColor: OsakaJadePalette.background.canvas,
                                                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                                                    borderRadius: 6,
                                                                    padding: '8px 10px 8px 34px',
                                                                    color: OsakaJadePalette.text.primary,
                                                                    fontSize: 13,
                                                                    outline: 'none'
                                                                } })] })] })), _jsxs("button", { type: "submit", disabled: isSubmitting, style: {
                                                    marginTop: 6,
                                                    padding: '10px 16px',
                                                    borderRadius: 6,
                                                    backgroundColor: OsakaJadePalette.jade[600],
                                                    border: 'none',
                                                    color: '#fff',
                                                    fontSize: 13,
                                                    fontWeight: 700,
                                                    cursor: isSubmitting ? 'not-allowed' : 'pointer',
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    justifyContent: 'center',
                                                    gap: 6
                                                }, children: [_jsx("span", { children: authMode === 'signin' ? 'Sign In to Account' : 'Create Account & Enable Cloud Sync' }), _jsx(ArrowRight, { size: 14 })] })] })] })) : (
                            /* ── GOOGLE SIGN-IN TAB ── */
                            _jsxs("div", { style: { display: 'flex', flexDirection: 'column', gap: 14 }, children: [googleClientId && !isEditingClientId ? (_jsxs("div", { children: [_jsx("p", { style: { fontSize: 12, color: OsakaJadePalette.text.secondary, margin: '0 0 12px 0', lineHeight: 1.5 }, children: "Select your Google account below to authenticate, sync cloud flowsheets, and load your Google profile photo." }), _jsx("div", { ref: googleButtonContainerRef, style: {
                                                    display: 'flex',
                                                    justifyContent: 'center',
                                                    minHeight: 44,
                                                    marginBottom: 12
                                                } }), _jsxs("button", { type: "button", onClick: handleGoogleOneTap, style: {
                                                    width: '100%',
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    justifyContent: 'center',
                                                    gap: 8,
                                                    padding: '10px 14px',
                                                    borderRadius: 6,
                                                    backgroundColor: 'rgba(255, 255, 255, 0.05)',
                                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                                    color: OsakaJadePalette.text.primary,
                                                    fontSize: 12,
                                                    fontWeight: 500,
                                                    cursor: 'pointer'
                                                }, children: [_jsx(Sparkles, { size: 14, color: OsakaJadePalette.jade.glow }), _jsx("span", { children: "Prompt Google One Tap Overlay" })] }), _jsxs("div", { style: {
                                                    marginTop: 14,
                                                    padding: '10px 12px',
                                                    borderRadius: 6,
                                                    backgroundColor: OsakaJadePalette.background.canvas,
                                                    border: `1px solid ${OsakaJadePalette.border.subtle}`,
                                                    fontSize: 11,
                                                    color: OsakaJadePalette.text.secondary,
                                                    display: 'flex',
                                                    flexDirection: 'column',
                                                    gap: 8
                                                }, children: [_jsxs("div", { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center' }, children: [_jsx("span", { style: { fontWeight: 600, color: OsakaJadePalette.text.primary }, children: "Seeing Error 400: origin_mismatch?" }), _jsx("button", { type: "button", onClick: () => {
                                                                    setIsEditingClientId(true);
                                                                    setCustomClientIdInput(googleClientId);
                                                                }, style: {
                                                                    background: 'none',
                                                                    border: 'none',
                                                                    color: OsakaJadePalette.jade.glow,
                                                                    fontSize: 11,
                                                                    fontWeight: 600,
                                                                    cursor: 'pointer',
                                                                    padding: 0
                                                                }, children: "Change Client ID \u2192" })] }), _jsxs("p", { style: { margin: 0, lineHeight: 1.4 }, children: ["Google requires this exact origin registered in Google Cloud Console under ", _jsx("strong", { children: "Authorized JavaScript origins" }), ":"] }), _jsxs("div", { style: {
                                                            display: 'flex',
                                                            alignItems: 'center',
                                                            justifyContent: 'space-between',
                                                            backgroundColor: OsakaJadePalette.background.surface,
                                                            padding: '6px 10px',
                                                            borderRadius: 4,
                                                            border: `1px solid ${OsakaJadePalette.border.default}`
                                                        }, children: [_jsx("code", { style: { color: OsakaJadePalette.jade.glow, fontSize: 11 }, children: typeof window !== 'undefined' ? window.location.origin : 'http://localhost:3000' }), _jsxs("button", { type: "button", onClick: () => handleCopyOrigin(typeof window !== 'undefined' ? window.location.origin : 'http://localhost:3000'), style: {
                                                                    background: 'none',
                                                                    border: 'none',
                                                                    color: copiedOrigin === (typeof window !== 'undefined' ? window.location.origin : 'http://localhost:3000')
                                                                        ? OsakaJadePalette.jade[400]
                                                                        : OsakaJadePalette.text.muted,
                                                                    cursor: 'pointer',
                                                                    display: 'flex',
                                                                    alignItems: 'center',
                                                                    gap: 4,
                                                                    fontSize: 11
                                                                }, children: [_jsx(Copy, { size: 12 }), _jsx("span", { children: copiedOrigin === (typeof window !== 'undefined' ? window.location.origin : 'http://localhost:3000') ? 'Copied!' : 'Copy Origin' })] })] })] })] })) : (
                                    /* ── GOOGLE CLIENT ID CONFIGURATION GUIDE ── */
                                    _jsxs("div", { style: {
                                            backgroundColor: OsakaJadePalette.background.canvas,
                                            border: `1px solid ${OsakaJadePalette.border.default}`,
                                            borderRadius: 8,
                                            padding: 14
                                        }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }, children: [_jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: 6 }, children: [_jsx(KeyRound, { size: 15, color: OsakaJadePalette.jade.glow }), _jsx("span", { style: { fontSize: 13, fontWeight: 700, color: OsakaJadePalette.text.primary }, children: "Google Sign-In Configuration" })] }), googleClientId && (_jsx("button", { type: "button", onClick: () => setIsEditingClientId(false), style: {
                                                            background: 'none',
                                                            border: 'none',
                                                            color: OsakaJadePalette.text.muted,
                                                            fontSize: 11,
                                                            cursor: 'pointer'
                                                        }, children: "Cancel" }))] }), _jsxs("p", { style: { fontSize: 11, color: OsakaJadePalette.text.secondary, margin: '0 0 10px 0', lineHeight: 1.5 }, children: ["Google requires a free ", _jsx("strong", { children: "OAuth Client ID" }), " from Google Cloud Console so your browser can securely authenticate with Google."] }), _jsxs("div", { style: {
                                                    backgroundColor: OsakaJadePalette.background.surface,
                                                    borderRadius: 6,
                                                    padding: 10,
                                                    marginBottom: 12,
                                                    fontSize: 11,
                                                    color: OsakaJadePalette.text.secondary,
                                                    display: 'flex',
                                                    flexDirection: 'column',
                                                    gap: 6
                                                }, children: [_jsx("span", { style: { fontWeight: 600, color: OsakaJadePalette.text.primary }, children: "Authorized JavaScript Origins to add in Google Console:" }), typeof window !== 'undefined' && window.location.origin && (_jsxs("div", { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingBottom: 4, borderBottom: `1px solid ${OsakaJadePalette.border.subtle}` }, children: [_jsxs("div", { children: [_jsx("span", { style: { fontSize: 10, color: OsakaJadePalette.jade.glow, display: 'block', fontWeight: 600 }, children: "Current Origin (This Tab):" }), _jsx("code", { style: { fontSize: 11, color: OsakaJadePalette.text.primary }, children: window.location.origin })] }), _jsxs("button", { type: "button", onClick: () => handleCopyOrigin(window.location.origin), style: {
                                                                    background: 'none',
                                                                    border: 'none',
                                                                    color: copiedOrigin === window.location.origin ? OsakaJadePalette.jade[400] : OsakaJadePalette.text.muted,
                                                                    cursor: 'pointer',
                                                                    display: 'flex',
                                                                    alignItems: 'center',
                                                                    gap: 4,
                                                                    fontSize: 10
                                                                }, children: [_jsx(Copy, { size: 12 }), _jsx("span", { children: copiedOrigin === window.location.origin ? 'Copied' : 'Copy' })] })] })), _jsxs("div", { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between' }, children: [_jsx("code", { style: { fontSize: 11, color: OsakaJadePalette.jade.glow }, children: "http://localhost:3000" }), _jsxs("button", { type: "button", onClick: () => handleCopyOrigin('http://localhost:3000'), style: {
                                                                    background: 'none',
                                                                    border: 'none',
                                                                    color: copiedOrigin === 'http://localhost:3000' ? OsakaJadePalette.jade[400] : OsakaJadePalette.text.muted,
                                                                    cursor: 'pointer',
                                                                    display: 'flex',
                                                                    alignItems: 'center',
                                                                    gap: 4,
                                                                    fontSize: 10
                                                                }, children: [_jsx(Copy, { size: 12 }), _jsx("span", { children: copiedOrigin === 'http://localhost:3000' ? 'Copied' : 'Copy' })] })] }), _jsxs("div", { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between' }, children: [_jsx("code", { style: { fontSize: 11, color: OsakaJadePalette.jade.glow }, children: "https://process-forge.pages.dev" }), _jsxs("button", { type: "button", onClick: () => handleCopyOrigin('https://process-forge.pages.dev'), style: {
                                                                    background: 'none',
                                                                    border: 'none',
                                                                    color: copiedOrigin === 'https://process-forge.pages.dev' ? OsakaJadePalette.jade[400] : OsakaJadePalette.text.muted,
                                                                    cursor: 'pointer',
                                                                    display: 'flex',
                                                                    alignItems: 'center',
                                                                    gap: 4,
                                                                    fontSize: 10
                                                                }, children: [_jsx(Copy, { size: 12 }), _jsx("span", { children: copiedOrigin === 'https://process-forge.pages.dev' ? 'Copied' : 'Copy' })] })] })] }), _jsxs("form", { onSubmit: handleSaveClientId, style: { display: 'flex', flexDirection: 'column', gap: 8 }, children: [_jsx("label", { style: { fontSize: 11, fontWeight: 600, color: OsakaJadePalette.text.secondary }, children: "Paste your Google OAuth Client ID:" }), _jsx("input", { type: "text", required: true, value: customClientIdInput, onChange: (e) => setCustomClientIdInput(e.target.value), placeholder: "xxxxxxxxxxxx.apps.googleusercontent.com", style: {
                                                            width: '100%',
                                                            boxSizing: 'border-box',
                                                            backgroundColor: OsakaJadePalette.background.surface,
                                                            border: `1px solid ${OsakaJadePalette.border.default}`,
                                                            borderRadius: 6,
                                                            padding: '8px 10px',
                                                            color: OsakaJadePalette.text.primary,
                                                            fontSize: 12,
                                                            outline: 'none'
                                                        } }), _jsxs("div", { style: { display: 'flex', gap: 8, marginTop: 4 }, children: [_jsx("button", { type: "submit", disabled: !customClientIdInput.trim(), style: {
                                                                    flex: 1,
                                                                    padding: '8px 12px',
                                                                    borderRadius: 6,
                                                                    backgroundColor: customClientIdInput.trim() ? OsakaJadePalette.jade[600] : 'rgba(255,255,255,0.05)',
                                                                    border: 'none',
                                                                    color: '#fff',
                                                                    fontSize: 12,
                                                                    fontWeight: 600,
                                                                    cursor: customClientIdInput.trim() ? 'pointer' : 'default'
                                                                }, children: "Save & Activate Google Sign-In" }), googleClientId && (_jsx("button", { type: "button", onClick: () => setIsEditingClientId(false), style: {
                                                                    padding: '8px 12px',
                                                                    borderRadius: 6,
                                                                    backgroundColor: 'transparent',
                                                                    border: `1px solid ${OsakaJadePalette.border.default}`,
                                                                    color: OsakaJadePalette.text.secondary,
                                                                    fontSize: 12,
                                                                    cursor: 'pointer'
                                                                }, children: "Cancel" }))] })] }), _jsx("div", { style: { marginTop: 10, textAlign: 'center' }, children: _jsxs("a", { href: "https://console.cloud.google.com/apis/credentials", target: "_blank", rel: "noopener noreferrer", style: {
                                                        fontSize: 11,
                                                        color: OsakaJadePalette.jade.glow,
                                                        textDecoration: 'none',
                                                        display: 'inline-flex',
                                                        alignItems: 'center',
                                                        gap: 4
                                                    }, children: [_jsx("span", { children: "Open Google Cloud Credentials Console" }), _jsx(ExternalLink, { size: 12 })] }) })] })), _jsxs("div", { style: { marginTop: 4 }, children: [_jsx("button", { type: "button", onClick: () => setShowAdvancedToken(!showAdvancedToken), style: {
                                                    background: 'none',
                                                    border: 'none',
                                                    color: OsakaJadePalette.text.muted,
                                                    fontSize: 11,
                                                    cursor: 'pointer',
                                                    padding: 0,
                                                    textDecoration: 'underline'
                                                }, children: showAdvancedToken ? 'Hide manual JWT token input' : 'Advanced: Paste raw Google JWT credential token' }), showAdvancedToken && (_jsxs("form", { onSubmit: handleGoogleTokenSubmit, style: { display: 'flex', flexDirection: 'column', gap: 8, marginTop: 8 }, children: [_jsx("input", { type: "text", value: googleCredentialInput, onChange: (e) => setGoogleCredentialInput(e.target.value), placeholder: "Paste Google JWT credential string (eyJhbGci...)", style: {
                                                            width: '100%',
                                                            boxSizing: 'border-box',
                                                            backgroundColor: OsakaJadePalette.background.canvas,
                                                            border: `1px solid ${OsakaJadePalette.border.default}`,
                                                            borderRadius: 6,
                                                            padding: '7px 10px',
                                                            color: OsakaJadePalette.text.primary,
                                                            fontSize: 11,
                                                            outline: 'none'
                                                        } }), _jsx("button", { type: "submit", disabled: !googleCredentialInput.trim() || isSubmitting, style: {
                                                            padding: '8px 12px',
                                                            borderRadius: 6,
                                                            backgroundColor: googleCredentialInput.trim() ? OsakaJadePalette.jade[600] : 'rgba(255,255,255,0.05)',
                                                            border: 'none',
                                                            color: '#fff',
                                                            fontSize: 11,
                                                            fontWeight: 600,
                                                            cursor: googleCredentialInput.trim() ? 'pointer' : 'default'
                                                        }, children: "Authenticate Google Token" })] }))] })] }))] })) })] }) }));
};
//# sourceMappingURL=AccountModal.js.map